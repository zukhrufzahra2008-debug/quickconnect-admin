# DELIVOO — Multi-Vendor Delivery Marketplace (Pakistan)

DELIVOO is a full-stack multi-vendor delivery marketplace combining Foodpanda-style local delivery dispatch with Daraz-style multi-category shopping, parent/shop-wise sub-order fulfillment, `Asia/Karachi` product availability scheduling, and real-time Leaflet GPS tracking.

## Key Capabilities

1. **Animated Custom Opening Experience**: Uses the supplied DELIVOO scooter mascot logo (`/public/assets/aistudio/Delivoo_Scooter_Delivery_Logo_73c58518.png`) with reduced-motion accessibility support, transitioning automatically into 4-role entry.
2. **Self-Registration + Mandatory Admin Approval Gate**:
   - **Customer**: Immediate registration, OTP password reset, multi-shop cart & checkout.
   - **Shopkeeper**: Self-registers shop & CNIC/NTN details (`approval_status = 'PENDING'`). Storefront and product/order tools unlock only after **Admin approval** (pushed live via WebSocket).
   - **Rider**: Self-registers CNIC, vehicle type, plate & capacity (`approval_status = 'PENDING'`). Online toggle and Smart Dispatch unlock only after **Admin approval**.
   - **Admin**: Protected administrative login (public admin registration is blocked on both frontend and backend).
3. **Multi-Shop Parent Order & Independent Sub-Orders**:
   - Checkout across multiple shops creates one Parent Order (`DEL-1001`) and independent Shop Sub-Orders (`DEL-1001-A`, `DEL-1001-B`, `DEL-1001-C`) inside an atomic SQLite `IMMEDIATE` transaction.
   - Independent cancellations, partial/full refunds, shop-owned riders vs. DELIVOO Smart Dispatch, and independent Leaflet OpenStreetMap tracking.
4. **5 Merchant Product Addition Methods**:
   - Manual Entry (with variants, batches, expiry dates, image upload)
   - CSV / Excel Template Upload with duplicate SKU/barcode validation & inline error fixing
   - Public Website URL Metadata Scraper (OpenGraph + Schema.org JSON-LD)
   - Camera Barcode Scanner + OpenFoodFacts / Internal Registry Lookup
   - Authorized Catalog JSON Feed Import
5. **Time-Based Scheduling (`Asia/Karachi`)**: Recurring weekday/time schedules and promotional prices enforced on the backend.

## Local Development & Production Commands

```bash
# Install dependencies
npm install

# Copy environment template
cp .env.example .env

# Start full-stack development server (Express + WebSockets + Vite on port 3000)
npm run dev

# Type-check codebase
npm run lint

# Build production frontend bundle
npm run build

# Start production server
NODE_ENV=production npm start
```

## Database Backup & Restore (SQLite WAL)

Automatic backups are created in `./data/backups/` prior to migrations on server startup.
Manual backup/restore:

```bash
# Backup
cp ./data/delivoo.db ./data/backups/manual-backup-$(date +%F).db

# Restore
cp ./data/backups/manual-backup-YYYY-MM-DD.db ./data/delivoo.db
```

## External Credentials Reference (Optional for Commercial Launch)

- **Maps**: Uses free OpenStreetMap tiles via Leaflet (no paid API key required).
- **Payments**: Supports Cash on Delivery out of the box plus HMAC-SHA256 webhook verification (`/api/marketplace/payments/webhook`). Set `EASYPAISA_STORE_ID`, `EASYPAISA_HASH_KEY`, `JAZZCASH_MERCHANT_ID`, `JAZZCASH_INTEGRITY_SALT`, and `PAYMENT_WEBHOOK_SECRET` in `.env` for live merchant gateways.
- **Email/SMS OTP**: Configure `SMTP_HOST`, `SMTP_USER`, `SMTP_PASS`, and `SMS_PROVIDER_API_KEY` in `.env`.
