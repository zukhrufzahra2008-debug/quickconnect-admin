import { db } from './db.ts';
import { createNotification, notifyAllAdmins, sendWsToRole, sendWsToUser } from './realtime.ts';

export interface KarachiClock {
  dayIndex: number; // 0 = Sunday .. 6 = Saturday
  timeHHMM: string; // "14:35"
  dateISO: string;  // "2026-11-10"
}

export function getKarachiClock(now = new Date()): KarachiClock {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Karachi',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(now);

  const map: Record<string, string> = {};
  for (const p of parts) {
    map[p.type] = p.value;
  }

  const weekdayMap: Record<string, number> = {
    Sun: 0,
    Mon: 1,
    Tue: 2,
    Wed: 3,
    Thu: 4,
    Fri: 5,
    Sat: 6,
  };

  const hour = map.hour === '24' ? '00' : map.hour || '00';
  const minute = map.minute || '00';

  return {
    dayIndex: weekdayMap[map.weekday || 'Mon'] ?? 1,
    timeHHMM: `${hour}:${minute}`,
    dateISO: `${map.year}-${map.month}-${map.day}`,
  };
}

export function isTimeInWindow(currentHHMM: string, startHHMM: string, endHHMM: string): boolean {
  if (startHHMM <= endHHMM) {
    return currentHHMM >= startHHMM && currentHHMM <= endHHMM;
  }
  // Overnight window (e.g., 20:00 -> 02:00)
  return currentHHMM >= startHHMM || currentHHMM <= endHHMM;
}

export function isShopCurrentlyOpen(shop: {
  opening_time: string;
  closing_time: string;
  is_open_override: string;
  approval_status: string;
}): boolean {
  if (shop.approval_status !== 'APPROVED') return false;
  if (shop.is_open_override === 'FORCE_CLOSED') return false;
  if (shop.is_open_override === 'FORCE_OPEN') return true;
  const clock = getKarachiClock();
  return isTimeInWindow(clock.timeHHMM, shop.opening_time || '00:00', shop.closing_time || '23:59');
}

export interface ProductAvailabilityResult {
  available: boolean;
  reason: string;
  effectivePrice: number;
  activeScheduleLabel: string | null;
}

export function evaluateProductAvailability(
  product: {
    id: number;
    selling_price: number;
    stock_quantity: number;
    expiry_date: string;
    is_active: number;
  },
  shopOpen: boolean
): ProductAvailabilityResult {
  if (!product.is_active) {
    return { available: false, reason: 'Inactive product', effectivePrice: product.selling_price, activeScheduleLabel: null };
  }
  if (!shopOpen) {
    return { available: false, reason: 'Shop currently closed', effectivePrice: product.selling_price, activeScheduleLabel: null };
  }
  const clock = getKarachiClock();
  if (product.expiry_date && product.expiry_date.trim() !== '' && product.expiry_date < clock.dateISO) {
    return { available: false, reason: 'Batch expired', effectivePrice: product.selling_price, activeScheduleLabel: null };
  }
  if (product.stock_quantity <= 0) {
    return { available: false, reason: 'Out of stock', effectivePrice: product.selling_price, activeScheduleLabel: null };
  }

  const schedules = db
    .prepare(`SELECT * FROM product_schedules WHERE product_id = ? AND is_paused = 0`)
    .all(product.id) as {
    id: number;
    label: string;
    start_time: string;
    end_time: string;
    days_of_week: string;
    promo_price: number | null;
    discount_percent: number | null;
  }[];

  if (schedules.length === 0) {
    return { available: true, reason: 'In stock', effectivePrice: product.selling_price, activeScheduleLabel: null };
  }

  // When a product has active schedules configured, at least one schedule must match current Asia/Karachi window
  for (const sch of schedules) {
    const days = sch.days_of_week
      .split(',')
      .map((d) => Number(d.trim()))
      .filter((n) => !Number.isNaN(n));
    const dayMatches = days.includes(clock.dayIndex);
    const timeMatches = isTimeInWindow(clock.timeHHMM, sch.start_time, sch.end_time);
    if (dayMatches && timeMatches) {
      let price = product.selling_price;
      if (sch.promo_price !== null && sch.promo_price !== undefined && sch.promo_price > 0) {
        price = sch.promo_price;
      } else if (sch.discount_percent && sch.discount_percent > 0 && sch.discount_percent < 100) {
        price = Math.round(product.selling_price * (1 - sch.discount_percent / 100));
      }
      return {
        available: true,
        reason: `Available (${sch.label})`,
        effectivePrice: price,
        activeScheduleLabel: `${sch.label} (${sch.start_time}–${sch.end_time} PKT)`,
      };
    }
  }

  const first = schedules[0];
  return {
    available: false,
    reason: `Scheduled ${first.start_time}–${first.end_time} PKT`,
    effectivePrice: product.selling_price,
    activeScheduleLabel: `${first.label} (${first.start_time}–${first.end_time} PKT)`,
  };
}

export function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function computeRiderPayout(distanceKm: number): number {
  const baseRow = db.prepare(`SELECT value FROM platform_settings WHERE key = 'rider_base_payout'`).get() as
    | { value: string }
    | undefined;
  const perKmRow = db.prepare(`SELECT value FROM platform_settings WHERE key = 'rider_per_km_payout'`).get() as
    | { value: string }
    | undefined;
  const base = Number(baseRow?.value || 95);
  const perKm = Number(perKmRow?.value || 18);
  return Math.round(base + Math.max(0.5, distanceKm) * perKm);
}

/**
 * Smart Rider Dispatch & Capacity Reservation (Section 13 & 16):
 * Runs inside an IMMEDIATE SQLite transaction to prevent double assignment or exceeding capacity.
 */
export function smartDispatchSubOrder(
  shopOrderId: number,
  excludedRiderIds: number[] = []
): { assigned: boolean; riderId: number | null; riderName: string | null; distanceKm: number | null } {
  const dispatchTx = db.transaction(() => {
    const sub = db
      .prepare(
        `SELECT so.*, s.lat as shop_lat, s.lng as shop_lng, s.city as shop_city, s.name as shop_name,
                po.delivery_lat, po.delivery_lng, po.customer_id
         FROM shop_orders so
         JOIN shops s ON s.id = so.shop_id
         JOIN parent_orders po ON po.id = so.parent_order_id
         WHERE so.id = ?`
      )
      .get(shopOrderId) as
      | {
          id: number;
          parent_order_id: number;
          sub_order_number: string;
          shop_lat: number;
          shop_lng: number;
          shop_city: string;
          shop_name: string;
          delivery_lat: number | null;
          delivery_lng: number | null;
          customer_id: number;
          rider_id: number | null;
          delivery_status: string;
        }
      | undefined;

    if (!sub) return { assigned: false, riderId: null, riderName: null, distanceKm: null, riderUserId: null };
    if (sub.rider_id && !['UNASSIGNED', 'PENDING_ASSIGNMENT'].includes(sub.delivery_status)) {
      return { assigned: true, riderId: sub.rider_id, riderName: null, distanceKm: null, riderUserId: null };
    }

    // Find all APPROVED, ACTIVE, online riders with spare capacity
    const candidates = db
      .prepare(
        `SELECT r.*, u.name as rider_name
         FROM riders r
         JOIN users u ON u.id = r.user_id
         WHERE r.approval_status = 'APPROVED'
           AND u.status = 'ACTIVE'
           AND r.is_online = 1
           AND r.active_deliveries < r.max_capacity`
      )
      .all() as {
      id: number;
      user_id: number;
      rider_name: string;
      city: string;
      active_deliveries: number;
      max_capacity: number;
      current_lat: number | null;
      current_lng: number | null;
    }[];

    const filtered = candidates.filter((c) => !excludedRiderIds.includes(c.id));
    if (filtered.length === 0) {
      db.prepare(
        `UPDATE shop_orders
         SET dispatch_mode = 'DELIVOO_RIDER', delivery_status = 'PENDING_ASSIGNMENT', rider_id = NULL, updated_at = datetime('now')
         WHERE id = ?`
      ).run(shopOrderId);
      db.prepare(
        `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
         VALUES (?, ?, 'SYSTEM', 'PENDING_ASSIGNMENT', 'No online rider with available capacity right now; queued for dispatch.')`
      ).run(sub.parent_order_id, shopOrderId);
      return { assigned: false, riderId: null, riderName: null, distanceKm: null, riderUserId: null, sub };
    }

    // Score by city match first, then Haversine distance to shop + workload penalty
    const scored = filtered
      .map((r) => {
        const rLat = r.current_lat ?? sub.shop_lat;
        const rLng = r.current_lng ?? sub.shop_lng;
        const distToShop = haversineKm(rLat, rLng, sub.shop_lat, sub.shop_lng);
        const cityPenalty = r.city.toLowerCase() === sub.shop_city.toLowerCase() ? 0 : 25;
        const workloadPenalty = r.active_deliveries * 1.5;
        return { rider: r, distToShop, score: distToShop + cityPenalty + workloadPenalty };
      })
      .sort((a, b) => a.score - b.score);

    const winner = scored[0];
    const dropDist =
      sub.delivery_lat && sub.delivery_lng
        ? haversineKm(sub.shop_lat, sub.shop_lng, sub.delivery_lat, sub.delivery_lng)
        : 3.2;
    const earning = computeRiderPayout(winner.distToShop + dropDist);

    // Reserve capacity safely
    const upd = db
      .prepare(
        `UPDATE riders
         SET active_deliveries = active_deliveries + 1
         WHERE id = ? AND active_deliveries < max_capacity`
      )
      .run(winner.rider.id);

    if (upd.changes === 0) {
      return { assigned: false, riderId: null, riderName: null, distanceKm: null, riderUserId: null, sub };
    }

    db.prepare(
      `UPDATE shop_orders
       SET dispatch_mode = 'DELIVOO_RIDER',
           rider_id = ?,
           delivery_status = 'ASSIGNED',
           updated_at = datetime('now')
       WHERE id = ?`
    ).run(winner.rider.id, shopOrderId);

    db.prepare(
      `INSERT INTO rider_assignments (shop_order_id, rider_id, status, distance_km, earning_amount)
       VALUES (?, ?, 'OFFERED', ?, ?)`
    ).run(shopOrderId, winner.rider.id, Number((winner.distToShop + dropDist).toFixed(2)), earning);

    db.prepare(
      `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
       VALUES (?, ?, 'SYSTEM', 'RIDER_ASSIGNED', ?)`
    ).run(
      sub.parent_order_id,
      shopOrderId,
      `Assigned rider ${winner.rider.rider_name} (${winner.distToShop.toFixed(1)} km from shop).`
    );

    return {
      assigned: true,
      riderId: winner.rider.id,
      riderName: winner.rider.rider_name,
      distanceKm: Number(winner.distToShop.toFixed(2)),
      riderUserId: winner.rider.user_id,
      sub,
    };
  });

  const result = dispatchTx.immediate();

  if (result.assigned && result.riderUserId && result.sub) {
    createNotification(
      result.riderUserId,
      `New Delivery Request: ${result.sub.sub_order_number}`,
      `Pickup from ${result.sub.shop_name}. Please review and accept in your Rider Dashboard.`,
      'DISPATCH_OFFER',
      result.sub.sub_order_number
    );
    createNotification(
      result.sub.customer_id,
      `Rider Assigned (${result.sub.sub_order_number})`,
      `${result.riderName} has been assigned to your order from ${result.sub.shop_name}.`,
      'ORDER_UPDATE',
      result.sub.sub_order_number
    );
    sendWsToUser(result.riderUserId, 'rider:dispatch_offer', { shopOrderId });
    sendWsToUser(result.sub.customer_id, 'suborder:updated', { shopOrderId });
    sendWsToRole('ADMIN', 'suborder:updated', { shopOrderId });
  } else if (!result.assigned && result.sub) {
    notifyAllAdmins(
      `Pending Rider Assignment: ${result.sub.sub_order_number}`,
      `No eligible online rider had free capacity for ${result.sub.shop_name}. Manual assignment available.`,
      'DISPATCH_ALERT',
      result.sub.sub_order_number
    );
  }

  return {
    assigned: result.assigned,
    riderId: result.riderId,
    riderName: result.riderName,
    distanceKm: result.distanceKm,
  };
}

export function recalculateParentOrderStatus(parentOrderId: number): void {
  const subs = db
    .prepare(`SELECT shop_status, delivery_status FROM shop_orders WHERE parent_order_id = ?`)
    .all(parentOrderId) as { shop_status: string; delivery_status: string }[];
  if (subs.length === 0) return;

  const total = subs.length;
  const delivered = subs.filter((s) => s.delivery_status === 'DELIVERED').length;
  const cancelled = subs.filter(
    (s) => s.shop_status === 'CANCELLED' || s.shop_status === 'REJECTED' || s.delivery_status === 'CANCELLED'
  ).length;

  let overall = 'IN_PROGRESS';
  if (delivered === total) {
    overall = 'COMPLETED';
  } else if (cancelled === total) {
    overall = 'CANCELLED';
  } else if (delivered > 0 && delivered + cancelled === total) {
    overall = 'PARTIALLY_DELIVERED';
  } else if (cancelled > 0 && delivered === 0 && subs.every((s) => s.shop_status === 'PENDING_SHOP' || s.shop_status === 'CANCELLED' || s.shop_status === 'REJECTED')) {
    overall = 'PARTIALLY_CANCELLED';
  } else if (subs.every((s) => s.shop_status === 'PENDING_SHOP')) {
    overall = 'PLACED';
  }

  db.prepare(`UPDATE parent_orders SET overall_status = ? WHERE id = ?`).run(overall, parentOrderId);
}
