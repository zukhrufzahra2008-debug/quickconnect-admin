import { Router } from 'express';
import { db } from '../db.ts';
import { notifyAllAdmins } from '../realtime.ts';
import { optionalAuth, type AuthenticatedRequest } from '../security.ts';

export const supportRouter = Router();

// Authorized Account-Aware Help Chatbot (Section 7)
// Strictly queries ONLY the logged-in user's real DB state; NEVER fabricates order statuses, payments, or rider GPS.
function generateAuthorizedBotReply(message: string, user?: { userId: number; role: string }): string {
  const q = message.toLowerCase();

  // Order / Tracking Queries
  if (q.includes('order') || q.includes('track') || q.includes('where') || q.includes('status') || q.includes('del-')) {
    if (!user) {
      return 'To check real-time order statuses or live delivery tracking, please sign in to your Customer, Shopkeeper, or Rider account first.';
    }
    if (user.role === 'CUSTOMER') {
      const latest = db
        .prepare(`SELECT * FROM parent_orders WHERE customer_id = ? ORDER BY id DESC LIMIT 1`)
        .get(user.userId) as any;
      if (!latest) {
        return 'You do not have any orders placed on DELIVOO yet. Browse approved shops on your Customer dashboard to place an order.';
      }
      const subs = db
        .prepare(
          `SELECT so.sub_order_number, so.shop_status, so.delivery_status, s.name as shop_name
           FROM shop_orders so
           JOIN shops s ON s.id = so.shop_id
           WHERE so.parent_order_id = ?`
        )
        .all(latest.id) as any[];
      const breakdown = subs
        .map(
          (s) =>
            `${s.sub_order_number} (${s.shop_name}): Shop=${s.shop_status.replace(/_/g, ' ')}, Delivery=${s.delivery_status.replace(/_/g, ' ')}`
        )
        .join(' | ');
      return `Your most recent parent order is ${latest.order_number} (Overall: ${latest.overall_status}, Payment: ${latest.payment_status} via ${latest.payment_method}). Sub-orders: ${breakdown}. Open "My Orders" for the live tracking map.`;
    }
    if (user.role === 'SHOPKEEPER') {
      const shop = db.prepare(`SELECT * FROM shops WHERE owner_id = ?`).get(user.userId) as any;
      if (!shop) return 'No shop profile is linked to your account.';
      if (shop.approval_status !== 'APPROVED') {
        return `Your shop "${shop.name}" currently has status: ${shop.approval_status}. Once an Admin approves your registration, your shop will go live and receive sub-orders.`;
      }
      const pending = (
        db
          .prepare(
            `SELECT COUNT(*) as c FROM shop_orders WHERE shop_id = ? AND shop_status IN ('PENDING_SHOP', 'ACCEPTED', 'PREPARING')`
          )
          .get(shop.id) as { c: number }
      ).c;
      return `Shop "${shop.name}" is APPROVED. You currently have ${pending} active sub-order(s) awaiting preparation or pickup in your Sub-Orders tab.`;
    }
    if (user.role === 'RIDER') {
      const rider = db.prepare(`SELECT * FROM riders WHERE user_id = ?`).get(user.userId) as any;
      if (!rider) return 'No rider profile found.';
      if (rider.approval_status !== 'APPROVED') {
        return `Your Rider registration status is currently ${rider.approval_status}. Once approved by Admin, you can toggle Online and receive delivery requests.`;
      }
      return `Your Rider profile is APPROVED (${rider.is_online ? 'Online' : 'Offline'}). Active deliveries: ${rider.active_deliveries}/${rider.max_capacity}. Total verified earnings: PKR ${rider.total_earnings}.`;
    }
  }

  // Approval / Registration Questions
  if (q.includes('approv') || q.includes('register') || q.includes('pending') || q.includes('verify')) {
    if (user?.role === 'SHOPKEEPER') {
      const shop = db.prepare(`SELECT name, approval_status, rejection_reason FROM shops WHERE owner_id = ?`).get(user.userId) as any;
      return shop
        ? `Your shop "${shop.name}" registration status is ${shop.approval_status}.${shop.rejection_reason ? ` Admin note: ${shop.rejection_reason}` : ''}`
        : 'No shop registration record found.';
    }
    if (user?.role === 'RIDER') {
      const rider = db.prepare(`SELECT vehicle_plate, approval_status, rejection_reason FROM riders WHERE user_id = ?`).get(user.userId) as any;
      return rider
        ? `Your rider registration (${rider.vehicle_plate}) status is ${rider.approval_status}.${rider.rejection_reason ? ` Admin note: ${rider.rejection_reason}` : ''}`
        : 'No rider registration record found.';
    }
    return 'Shopkeepers and Riders register themselves directly from the Role Selection screen. Every new Shopkeeper and Rider application starts in PENDING status and becomes active in DELIVOO as soon as the Admin approves it.';
  }

  // Payment / Refund Questions
  if (q.includes('refund') || q.includes('payment') || q.includes('easypaisa') || q.includes('jazzcash') || q.includes('cancel')) {
    if (user?.role === 'CUSTOMER') {
      const rf = db
        .prepare(
          `SELECT rf.amount, rf.status, so.sub_order_number
           FROM refunds rf
           JOIN shop_orders so ON so.id = rf.shop_order_id
           WHERE rf.customer_id = ?
           ORDER BY rf.id DESC LIMIT 1`
        )
        .get(user.userId) as any;
      const rfInfo = rf
        ? ` Your latest refund request (${rf.sub_order_number}, PKR ${rf.amount}) has status: ${rf.status}.`
        : ' You have no pending refund requests.';
      return `DELIVOO supports Cash on Delivery, Easypaisa, JazzCash, and Card payments verified on the backend. Each shop sub-order can be cancelled or refunded independently in "My Orders".${rfInfo}`;
    }
    return 'DELIVOO supports Cash on Delivery (COD), Easypaisa, JazzCash, and Card payments. Refunds are tracked per shop sub-order so cancelling one shop never disrupts other shops in a multi-vendor parent order.';
  }

  // Product / Schedule / Import Questions
  if (q.includes('import') || q.includes('csv') || q.includes('barcode') || q.includes('schedule')) {
    return 'Approved Shopkeepers can add products via 5 methods: Manual Entry, CSV/Excel Template Import, Public Website URL Metadata Import, Camera Barcode Lookup, and Catalog JSON Sync, plus configure recurring Asia/Karachi (PKT) availability schedules.';
  }

  // Human Escalation
  if (q.includes('human') || q.includes('agent') || q.includes('helpline') || q.includes('call')) {
    const phone =
      (db.prepare(`SELECT value FROM platform_settings WHERE key = 'helpline_phone'`).get() as any)?.value ||
      '+92-42-111-335-486';
    return `You can submit a direct Support Ticket using the "Request Human Support" button right below in this chat, or reach the DELIVOO Helpline at ${phone}.`;
  }

  return 'Hello! I am the DELIVOO Support Assistant. Ask me about your real-time orders (e.g., "Where is my order?"), Shopkeeper/Rider admin approval status, payments & sub-order refunds, product imports, or click "Request Human Support" to open an official ticket.';
}

supportRouter.get('/chatbot/history', optionalAuth, (req: AuthenticatedRequest, res) => {
  const sessionKey = String(req.query.sessionKey || 'guest-default');
  const conv = req.user
    ? (db
        .prepare(`SELECT * FROM chatbot_conversations WHERE user_id = ? ORDER BY id DESC LIMIT 1`)
        .get(req.user.userId) as any)
    : (db
        .prepare(`SELECT * FROM chatbot_conversations WHERE session_key = ? AND user_id IS NULL ORDER BY id DESC LIMIT 1`)
        .get(sessionKey) as any);

  if (!conv) {
    res.json({ messages: [] });
    return;
  }

  const messages = db
    .prepare(`SELECT * FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC LIMIT 60`)
    .all(conv.id);
  res.json({ messages });
});

supportRouter.post('/chatbot/message', optionalAuth, (req: AuthenticatedRequest, res) => {
  const text = String(req.body?.message || '').trim();
  const sessionKey = String(req.body?.sessionKey || 'guest-default');

  if (!text) {
    res.status(400).json({ error: 'Message cannot be empty.' });
    return;
  }

  let conv = req.user
    ? (db
        .prepare(`SELECT * FROM chatbot_conversations WHERE user_id = ? ORDER BY id DESC LIMIT 1`)
        .get(req.user.userId) as any)
    : (db
        .prepare(`SELECT * FROM chatbot_conversations WHERE session_key = ? AND user_id IS NULL ORDER BY id DESC LIMIT 1`)
        .get(sessionKey) as any);

  if (!conv) {
    const cRes = db
      .prepare(`INSERT INTO chatbot_conversations (user_id, session_key) VALUES (?, ?)`)
      .run(req.user?.userId ?? null, sessionKey);
    conv = { id: Number(cRes.lastInsertRowid) };
  }

  db.prepare(`INSERT INTO chatbot_messages (conversation_id, sender, message) VALUES (?, 'USER', ?)`).run(
    conv.id,
    text
  );

  const botReply = generateAuthorizedBotReply(text, req.user);
  db.prepare(`INSERT INTO chatbot_messages (conversation_id, sender, message) VALUES (?, 'BOT', ?)`).run(
    conv.id,
    botReply
  );

  const messages = db
    .prepare(`SELECT * FROM chatbot_messages WHERE conversation_id = ? ORDER BY id ASC LIMIT 60`)
    .all(conv.id);

  res.json({ reply: botReply, messages });
});

// Feedback, Complaints & Human Support Escalation
supportRouter.post('/tickets', optionalAuth, (req: AuthenticatedRequest, res) => {
  const { type = 'SUPPORT', subject, message, guestName = 'Visitor' } = req.body || {};
  if (!subject || String(subject).trim().length < 3 || !message || String(message).trim().length < 5) {
    res.status(400).json({ error: 'Please provide both a subject and detailed message.' });
    return;
  }

  let userName = String(guestName).trim();
  let role = 'GUEST';
  if (req.user) {
    const u = db.prepare(`SELECT name, role FROM users WHERE id = ?`).get(req.user.userId) as any;
    if (u) {
      userName = u.name;
      role = u.role;
    }
  }

  const validType = ['SUPPORT', 'FEEDBACK', 'COMPLAINT', 'BUG'].includes(type) ? type : 'SUPPORT';
  const info = db
    .prepare(
      `INSERT INTO support_tickets (user_id, user_name, role, type, subject, message, status)
       VALUES (?, ?, ?, ?, ?, ?, 'OPEN')`
    )
    .run(
      req.user?.userId ?? null,
      userName,
      role,
      validType,
      String(subject).trim(),
      String(message).trim()
    );

  notifyAllAdmins(
    `New ${validType}: ${String(subject).trim()}`,
    `Submitted by ${userName} (${role}).`,
    'SUPPORT_TICKET',
    String(info.lastInsertRowid)
  );

  res.status(201).json({
    ticketId: Number(info.lastInsertRowid),
    message: 'Your request has been logged with DELIVOO Support.',
  });
});

// Public Helpline & Legal Policy Metadata
supportRouter.get('/legal-helpline', (_req, res) => {
  const rows = db
    .prepare(`SELECT key, value FROM platform_settings WHERE key IN ('helpline_phone', 'helpline_email')`)
    .all() as { key: string; value: string }[];
  const map: Record<string, string> = {};
  for (const r of rows) map[r.key] = r.value;

  res.json({
    helplinePhone: map.helpline_phone || '+92-42-111-335-486',
    helplineEmail: map.helpline_email || 'support@delivoo.pk',
    operatingHours: '24/7 Customer, Merchant & Rider Dispatch Desk (Pakistan Standard Time)',
  });
});
