import { Router } from 'express';
import { createCatalogArtwork } from '../artwork.ts';
import {
  evaluateProductAvailability,
  getKarachiClock,
  isShopCurrentlyOpen,
  recalculateParentOrderStatus,
  smartDispatchSubOrder,
} from '../availability.ts';
import { db } from '../db.ts';
import {
  broadcastCatalogRefresh,
  createNotification,
  notifyAllAdmins,
  sendWsToRole,
  sendWsToUser,
} from '../realtime.ts';
import {
  requireAuth,
  requireRole,
  writeAuditLog,
  type AuthenticatedRequest,
} from '../security.ts';

export const shopkeeperRouter = Router();

shopkeeperRouter.use(requireAuth, requireRole('SHOPKEEPER'));

function getOwnedShop(userId: number): any {
  return db.prepare(`SELECT * FROM shops WHERE owner_id = ?`).get(userId);
}

shopkeeperRouter.get('/dashboard', (req: AuthenticatedRequest, res) => {
  const shop = getOwnedShop(req.user!.userId);
  if (!shop) {
    res.status(404).json({ error: 'Shop profile not found.' });
    return;
  }

  const clock = getKarachiClock();
  const isOpen = isShopCurrentlyOpen(shop);

  const products = (
    db.prepare(`SELECT * FROM products WHERE shop_id = ? ORDER BY id DESC`).all(shop.id) as any[]
  ).map((p) => {
    const variants = db.prepare(`SELECT * FROM product_variants WHERE product_id = ?`).all(p.id);
    const avail = evaluateProductAvailability(p, isOpen);
    return {
      ...p,
      variants,
      availableNow: avail.available,
      availabilityReason: avail.reason,
      effectivePrice: avail.effectivePrice,
      activeScheduleLabel: avail.activeScheduleLabel,
    };
  });

  const schedules = db
    .prepare(
      `SELECT ps.*, p.name as product_name, p.selling_price
       FROM product_schedules ps
       JOIN products p ON p.id = ps.product_id
       WHERE ps.shop_id = ?
       ORDER BY ps.id DESC`
    )
    .all(shop.id);

  const inventoryLogs = db
    .prepare(
      `SELECT i.*, p.name as product_name, p.sku
       FROM inventory i
       JOIN products p ON p.id = i.product_id
       WHERE i.shop_id = ?
       ORDER BY i.id DESC LIMIT 50`
    )
    .all(shop.id);

  const batches = db
    .prepare(
      `SELECT b.*, p.name as product_name, p.sku
       FROM inventory_batches b
       JOIN products p ON p.id = b.product_id
       WHERE b.shop_id = ?
       ORDER BY b.expiry_date ASC, b.id DESC`
    )
    .all(shop.id);

  const importJobs = db
    .prepare(`SELECT * FROM import_jobs WHERE shop_id = ? ORDER BY id DESC LIMIT 20`)
    .all(shop.id);

  const subOrders = (
    db
      .prepare(
        `SELECT so.*, po.order_number, po.delivery_address, po.delivery_city, po.contact_phone,
                po.delivery_instructions, po.payment_method, po.payment_status,
                cu.name as customer_name, ru.name as rider_name, ru.phone as rider_phone, r.vehicle_plate
         FROM shop_orders so
         JOIN parent_orders po ON po.id = so.parent_order_id
         JOIN users cu ON cu.id = po.customer_id
         LEFT JOIN riders r ON r.id = so.rider_id
         LEFT JOIN users ru ON ru.id = r.user_id
         WHERE so.shop_id = ?
         ORDER BY so.id DESC`
      )
      .all(shop.id) as any[]
  ).map((so) => ({
    ...so,
    items: db.prepare(`SELECT * FROM order_items WHERE shop_order_id = ?`).all(so.id),
  }));

  const categories = db
    .prepare(`SELECT * FROM shop_categories WHERE is_active = 1 ORDER BY sort_order ASC`)
    .all();

  const earningsRow = db
    .prepare(
      `SELECT COALESCE(SUM(subtotal - commission_amount), 0) as netEarnings,
              COALESCE(SUM(subtotal), 0) as grossSales,
              COUNT(*) as deliveredCount
       FROM shop_orders
       WHERE shop_id = ? AND delivery_status = 'DELIVERED'`
    )
    .get(shop.id) as { netEarnings: number; grossSales: number; deliveredCount: number };

  res.json({
    karachiClock: clock,
    shop: { ...shop, isOpen },
    categories,
    products,
    schedules,
    inventoryLogs,
    batches,
    importJobs,
    subOrders,
    earnings: earningsRow,
  });
});

// Update / Resubmit Shop Registration Details (available even while PENDING or REJECTED)
shopkeeperRouter.put('/application', (req: AuthenticatedRequest, res) => {
  const shop = getOwnedShop(req.user!.userId);
  if (!shop) {
    res.status(404).json({ error: 'Shop not found.' });
    return;
  }

  const {
    name,
    categoryName,
    description,
    address,
    city,
    lat,
    lng,
    cnicNtn,
    openingTime,
    closingTime,
    isOpenOverride,
    deliveryFee,
    prepTimeMins,
    ownRiderEnabled,
    ownRiderName,
    ownRiderPhone,
    logoUrl,
    coverUrl,
    resubmitForApproval,
  } = req.body || {};

  const nextStatus =
    resubmitForApproval && shop.approval_status === 'REJECTED' ? 'PENDING' : shop.approval_status;

  db.prepare(
    `UPDATE shops SET
       name = COALESCE(?, name),
       category_name = COALESCE(?, category_name),
       description = COALESCE(?, description),
       address = COALESCE(?, address),
       city = COALESCE(?, city),
       lat = COALESCE(?, lat),
       lng = COALESCE(?, lng),
       cnic_ntn = COALESCE(?, cnic_ntn),
       opening_time = COALESCE(?, opening_time),
       closing_time = COALESCE(?, closing_time),
       is_open_override = COALESCE(?, is_open_override),
       delivery_fee = COALESCE(?, delivery_fee),
       prep_time_mins = COALESCE(?, prep_time_mins),
       own_rider_enabled = COALESCE(?, own_rider_enabled),
       own_rider_name = COALESCE(?, own_rider_name),
       own_rider_phone = COALESCE(?, own_rider_phone),
       logo_url = COALESCE(?, logo_url),
       cover_url = COALESCE(?, cover_url),
       approval_status = ?
     WHERE id = ?`
  ).run(
    name ? String(name).trim() : null,
    categoryName ? String(categoryName).trim() : null,
    description !== undefined ? String(description).trim() : null,
    address ? String(address).trim() : null,
    city ? String(city).trim() : null,
    typeof lat === 'number' ? lat : null,
    typeof lng === 'number' ? lng : null,
    cnicNtn !== undefined ? String(cnicNtn).trim() : null,
    openingTime || null,
    closingTime || null,
    isOpenOverride || null,
    deliveryFee !== undefined ? Math.max(0, Number(deliveryFee)) : null,
    prepTimeMins !== undefined ? Math.max(5, Number(prepTimeMins)) : null,
    ownRiderEnabled !== undefined ? (ownRiderEnabled ? 1 : 0) : null,
    ownRiderName !== undefined ? String(ownRiderName).trim() : null,
    ownRiderPhone !== undefined ? String(ownRiderPhone).trim() : null,
    logoUrl || null,
    coverUrl || null,
    nextStatus,
    shop.id
  );

  if (resubmitForApproval && shop.approval_status === 'REJECTED') {
    notifyAllAdmins(
      `Shop Application Resubmitted: ${name || shop.name}`,
      `Shopkeeper updated registration details and requested Admin re-evaluation.`,
      'APPROVAL_REQUIRED',
      String(shop.id)
    );
  }

  broadcastCatalogRefresh();
  res.json({ message: 'Shop details saved.', shop: getOwnedShop(req.user!.userId) });
});

function requireApprovedShop(userId: number): any {
  const shop = getOwnedShop(userId);
  if (!shop) throw new Error('Shop record not found.');
  if (shop.approval_status !== 'APPROVED') {
    throw new Error(
      `Your shop status is currently "${shop.approval_status}". Admin approval is required before managing live marketplace inventory or orders.`
    );
  }
  return shop;
}

// METHOD 1: Manual Product Creation & Update
shopkeeperRouter.post('/products', (req: AuthenticatedRequest, res) => {
  try {
    const shop = requireApprovedShop(req.user!.userId);
    const {
      name,
      categoryName,
      description = '',
      sellingPrice,
      originalPrice,
      sku,
      barcode = '',
      brand = '',
      stockQuantity = 0,
      lowStockThreshold = 5,
      mfgDate = '',
      expiryDate = '',
      freshnessInfo = '',
      imageUrl = '',
      variants = [],
    } = req.body || {};

    const cleanName = String(name || '').trim();
    const cleanSku = String(sku || '').toUpperCase().trim();
    const price = Number(sellingPrice);
    const orig = originalPrice !== undefined && originalPrice !== '' ? Number(originalPrice) : price;
    const stock = Math.max(0, Math.floor(Number(stockQuantity || 0)));

    if (cleanName.length < 2 || !cleanSku || Number.isNaN(price) || price < 0) {
      res.status(400).json({ error: 'Product name, valid SKU, and non-negative selling price are required.' });
      return;
    }

    const dupSku = db
      .prepare(`SELECT id FROM products WHERE shop_id = ? AND sku = ?`)
      .get(shop.id, cleanSku);
    if (dupSku) {
      res.status(409).json({ error: `SKU "${cleanSku}" already exists in your shop.` });
      return;
    }

    const finalImage =
      imageUrl && String(imageUrl).trim() !== ''
        ? String(imageUrl).trim()
        : createCatalogArtwork(cleanName.slice(0, 26), `${brand || shop.name}`, '#059669', '#ecfdf5', 'grocery');

    const prodId = db.transaction(() => {
      const result = db
        .prepare(
          `INSERT INTO products (
             shop_id, category_name, name, description, selling_price, original_price,
             sku, barcode, brand, stock_quantity, low_stock_threshold,
             mfg_date, expiry_date, freshness_info, image_url, is_active
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`
        )
        .run(
          shop.id,
          String(categoryName || shop.category_name).trim(),
          cleanName,
          String(description).trim(),
          price,
          Math.max(price, orig),
          cleanSku,
          String(barcode).trim(),
          String(brand).trim(),
          stock,
          Math.max(1, Number(lowStockThreshold || 5)),
          String(mfgDate).trim(),
          String(expiryDate).trim(),
          String(freshnessInfo).trim(),
          finalImage
        );

      const id = Number(result.lastInsertRowid);

      db.prepare(
        `INSERT INTO inventory (product_id, shop_id, change_amount, new_quantity, reason, actor_id)
         VALUES (?, ?, ?, ?, 'Initial manual entry', ?)`
      ).run(id, shop.id, stock, stock, req.user!.userId);

      if (stock > 0) {
        db.prepare(
          `INSERT INTO inventory_batches (product_id, shop_id, batch_code, quantity, mfg_date, expiry_date)
           VALUES (?, ?, ?, ?, ?, ?)`
        ).run(id, shop.id, `BATCH-${cleanSku}-INIT`, stock, String(mfgDate).trim(), String(expiryDate).trim());
      }

      if (Array.isArray(variants)) {
        const insVar = db.prepare(
          `INSERT INTO product_variants (product_id, name, price_delta, stock_quantity, sku)
           VALUES (?, ?, ?, ?, ?)`
        );
        for (const v of variants) {
          if (v && v.name) {
            insVar.run(
              id,
              String(v.name).trim(),
              Number(v.priceDelta || 0),
              Math.max(0, Number(v.stockQuantity ?? stock)),
              `${cleanSku}-${String(v.name).slice(0, 3).toUpperCase()}`
            );
          }
        }
      }

      return id;
    })();

    broadcastCatalogRefresh();
    res.status(201).json({ message: 'Product added to your shop.', productId: prodId });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Could not create product.' });
  }
});

shopkeeperRouter.put('/products/:id', (req: AuthenticatedRequest, res) => {
  try {
    const shop = requireApprovedShop(req.user!.userId);
    const prodId = Number(req.params.id);
    const existing = db
      .prepare(`SELECT * FROM products WHERE id = ? AND shop_id = ?`)
      .get(prodId, shop.id) as any;

    if (!existing) {
      res.status(404).json({ error: 'Product not found in your shop.' });
      return;
    }

    const {
      name,
      categoryName,
      description,
      sellingPrice,
      originalPrice,
      barcode,
      brand,
      expiryDate,
      freshnessInfo,
      imageUrl,
      isActive,
    } = req.body || {};

    db.prepare(
      `UPDATE products SET
         name = COALESCE(?, name),
         category_name = COALESCE(?, category_name),
         description = COALESCE(?, description),
         selling_price = COALESCE(?, selling_price),
         original_price = COALESCE(?, original_price),
         barcode = COALESCE(?, barcode),
         brand = COALESCE(?, brand),
         expiry_date = COALESCE(?, expiry_date),
         freshness_info = COALESCE(?, freshness_info),
         image_url = COALESCE(?, image_url),
         is_active = COALESCE(?, is_active)
       WHERE id = ? AND shop_id = ?`
    ).run(
      name ? String(name).trim() : null,
      categoryName ? String(categoryName).trim() : null,
      description !== undefined ? String(description).trim() : null,
      sellingPrice !== undefined ? Math.max(0, Number(sellingPrice)) : null,
      originalPrice !== undefined ? Math.max(0, Number(originalPrice)) : null,
      barcode !== undefined ? String(barcode).trim() : null,
      brand !== undefined ? String(brand).trim() : null,
      expiryDate !== undefined ? String(expiryDate).trim() : null,
      freshnessInfo !== undefined ? String(freshnessInfo).trim() : null,
      imageUrl || null,
      isActive !== undefined ? (isActive ? 1 : 0) : null,
      prodId,
      shop.id
    );

    broadcastCatalogRefresh();
    res.json({ message: 'Product updated.' });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Update failed.' });
  }
});

// METHOD 2 & METHOD 5: CSV / Excel / Catalog Import Validation & Commit
shopkeeperRouter.get('/import/template', (_req, res) => {
  const csv = [
    'name,category,selling_price,original_price,sku,barcode,quantity,brand,expiry_date,description',
    '"Himalayan Pink Salt 800g","Grocery",190,220,"SALT-PK-800","8969001100111",45,"Khewra Pure","2028-12-31","Fine food-grade pink rock salt"',
    '"Cardamom Green Elaichi 100g","Grocery",680,750,"SPICE-EL-100","8969001100228",30,"Aroma Pak","2027-09-30","Whole aromatic green cardamom pods"',
  ].join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="delivoo_product_import_template.csv"');
  res.send(csv);
});

shopkeeperRouter.post('/import/validate-rows', (req: AuthenticatedRequest, res) => {
  try {
    const shop = requireApprovedShop(req.user!.userId);
    const rows = Array.isArray(req.body?.rows) ? req.body.rows : [];

    const existingSkus = new Set(
      (db.prepare(`SELECT sku FROM products WHERE shop_id = ?`).all(shop.id) as { sku: string }[]).map((r) =>
        r.sku.toUpperCase()
      )
    );
    const existingBarcodes = new Set(
      (
        db
          .prepare(`SELECT barcode FROM products WHERE shop_id = ? AND barcode != ''`)
          .all(shop.id) as { barcode: string }[]
      ).map((r) => r.barcode)
    );

    const seenSkusInBatch = new Set<string>();
    const seenBarcodesInBatch = new Set<string>();

    const validated = rows.map((r: any, idx: number) => {
      const errors: string[] = [];
      const name = String(r.name || '').trim();
      const sku = String(r.sku || '').toUpperCase().trim();
      const barcode = String(r.barcode || '').trim();
      const sellingPrice = Number(r.selling_price ?? r.sellingPrice);
      const originalPrice =
        r.original_price !== undefined && r.original_price !== ''
          ? Number(r.original_price)
          : sellingPrice;
      const quantity = Math.floor(Number(r.quantity ?? r.stockQuantity ?? 0));
      const category = String(r.category || shop.category_name).trim();
      const brand = String(r.brand || '').trim();
      const expiryDate = String(r.expiry_date || r.expiryDate || '').trim();
      const description = String(r.description || '').trim();

      if (name.length < 2) errors.push('Product name too short');
      if (!sku) errors.push('Missing SKU');
      if (Number.isNaN(sellingPrice) || sellingPrice <= 0) errors.push('Invalid selling price');
      if (Number.isNaN(quantity) || quantity < 0) errors.push('Invalid quantity');

      if (sku) {
        if (existingSkus.has(sku)) errors.push(`Duplicate SKU "${sku}" already in shop`);
        if (seenSkusInBatch.has(sku)) errors.push(`Duplicate SKU "${sku}" repeated in file`);
        seenSkusInBatch.add(sku);
      }
      if (barcode) {
        if (existingBarcodes.has(barcode)) errors.push(`Duplicate barcode "${barcode}" in shop`);
        if (seenBarcodesInBatch.has(barcode)) errors.push(`Duplicate barcode "${barcode}" in file`);
        seenBarcodesInBatch.add(barcode);
      }

      return {
        rowNumber: idx + 1,
        name,
        category,
        sellingPrice: Number.isNaN(sellingPrice) ? 0 : sellingPrice,
        originalPrice: Number.isNaN(originalPrice) ? sellingPrice : Math.max(sellingPrice, originalPrice),
        sku,
        barcode,
        quantity: Number.isNaN(quantity) ? 0 : quantity,
        brand,
        expiryDate,
        description,
        valid: errors.length === 0,
        errors,
      };
    });

    res.json({ rows: validated });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Validation failed.' });
  }
});

shopkeeperRouter.post('/import/commit', (req: AuthenticatedRequest, res) => {
  try {
    const shop = requireApprovedShop(req.user!.userId);
    const { method = 'CSV_EXCEL', rows = [] } = req.body || {};
    if (!Array.isArray(rows) || rows.length === 0) {
      res.status(400).json({ error: 'No rows provided to import.' });
      return;
    }

    const result = db.transaction(() => {
      let validCount = 0;
      let errorCount = 0;

      const jobRes = db
        .prepare(
          `INSERT INTO import_jobs (shop_id, method, total_rows, valid_rows, error_rows, status)
           VALUES (?, ?, ?, 0, 0, 'COMPLETED')`
        )
        .run(shop.id, String(method), rows.length);
      const jobId = Number(jobRes.lastInsertRowid);

      const insRowLog = db.prepare(
        `INSERT INTO import_job_rows (import_job_id, row_number, sku, product_name, status, error_message)
         VALUES (?, ?, ?, ?, ?, ?)`
      );
      const insProd = db.prepare(
        `INSERT INTO products (
           shop_id, category_name, name, description, selling_price, original_price,
           sku, barcode, brand, stock_quantity, expiry_date, image_url, is_active
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`
      );

      rows.forEach((r: any, i: number) => {
        const name = String(r.name || '').trim();
        const sku = String(r.sku || '').toUpperCase().trim();
        const price = Number(r.sellingPrice ?? r.selling_price ?? 0);
        const qty = Math.max(0, Math.floor(Number(r.quantity ?? 0)));

        const dup = db
          .prepare(`SELECT id FROM products WHERE shop_id = ? AND sku = ?`)
          .get(shop.id, sku);

        if (!name || !sku || price <= 0 || dup) {
          errorCount += 1;
          insRowLog.run(
            jobId,
            i + 1,
            sku,
            name,
            'ERROR',
            dup ? `Duplicate SKU ${sku}` : 'Missing required fields or invalid price'
          );
          return;
        }

        const art = createCatalogArtwork(
          name.slice(0, 26),
          `${r.brand || shop.name}`,
          '#059669',
          '#ecfdf5',
          'grocery'
        );
        const orig = Math.max(price, Number(r.originalPrice ?? r.original_price ?? price));
        const pRes = insProd.run(
          shop.id,
          String(r.category || shop.category_name).trim(),
          name,
          String(r.description || '').trim(),
          price,
          orig,
          sku,
          String(r.barcode || '').trim(),
          String(r.brand || '').trim(),
          qty,
          String(r.expiryDate || r.expiry_date || '').trim(),
          art
        );
        const pid = Number(pRes.lastInsertRowid);

        db.prepare(
          `INSERT INTO inventory (product_id, shop_id, change_amount, new_quantity, reason, actor_id)
           VALUES (?, ?, ?, ?, ?, ?)`
        ).run(pid, shop.id, qty, qty, `Imported via ${method}`, req.user!.userId);

        validCount += 1;
        insRowLog.run(jobId, i + 1, sku, name, 'IMPORTED', '');
      });

      db.prepare(`UPDATE import_jobs SET valid_rows = ?, error_rows = ? WHERE id = ?`).run(
        validCount,
        errorCount,
        jobId
      );

      return { jobId, validCount, errorCount };
    })();

    broadcastCatalogRefresh();
    res.json({
      message: `Imported ${result.validCount} product(s) (${result.errorCount} skipped).`,
      ...result,
    });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Import commit failed.' });
  }
});

// METHOD 3: Website URL Metadata / Schema.org Product Scraper (never invents missing details!)
shopkeeperRouter.post('/import/url-scrape', async (req: AuthenticatedRequest, res) => {
  try {
    requireApprovedShop(req.user!.userId);
    const rawUrl = String(req.body?.url || '').trim();
    if (!/^https?:\/\//i.test(rawUrl)) {
      res.status(400).json({ error: 'Please enter a valid http:// or https:// product URL.' });
      return;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6500);
    let html = '';
    try {
      const response = await fetch(rawUrl, {
        signal: controller.signal,
        headers: {
          'User-Agent': 'DelivooMerchantCatalogBot/1.0 (+https://delivoo.pk)',
          Accept: 'text/html,application/xhtml+xml',
        },
      });
      if (!response.ok) {
        res.status(422).json({
          error: `Target website returned HTTP ${response.status}. Access restricted or page not found.`,
        });
        return;
      }
      html = await response.text();
    } finally {
      clearTimeout(timeout);
    }

    const extractMeta = (prop: string): string => {
      const reg1 = new RegExp(
        `<meta[^>]+(?:property|name)=["']${prop}["'][^>]+content=["']([^"']+)["']`,
        'i'
      );
      const reg2 = new RegExp(
        `<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${prop}["']`,
        'i'
      );
      return (html.match(reg1)?.[1] || html.match(reg2)?.[1] || '').trim();
    };

    let ldProduct: any = null;
    const ldMatches = html.match(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi);
    if (ldMatches) {
      for (const block of ldMatches) {
        const inner = block.replace(/^<script[^>]*>|<\/script>$/gi, '').trim();
        try {
          const parsed = JSON.parse(inner);
          const candidates = Array.isArray(parsed)
            ? parsed
            : parsed['@graph'] && Array.isArray(parsed['@graph'])
            ? parsed['@graph']
            : [parsed];
          const found = candidates.find(
            (c: any) => c && (c['@type'] === 'Product' || (Array.isArray(c['@type']) && c['@type'].includes('Product')))
          );
          if (found) {
            ldProduct = found;
            break;
          }
        } catch {
          // Ignore malformed JSON-LD block
        }
      }
    }

    const titleTag = html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1]?.trim() || '';
    const extractedName = ldProduct?.name || extractMeta('og:title') || titleTag || '';
    const extractedDesc = ldProduct?.description || extractMeta('og:description') || extractMeta('description') || '';
    const extractedImage =
      (typeof ldProduct?.image === 'string'
        ? ldProduct.image
        : Array.isArray(ldProduct?.image)
        ? ldProduct.image[0]
        : '') || extractMeta('og:image');
    const offer = Array.isArray(ldProduct?.offers) ? ldProduct.offers[0] : ldProduct?.offers;
    const rawPrice =
      offer?.price ||
      extractMeta('product:price:amount') ||
      extractMeta('og:price:amount') ||
      '';
    const extractedBrand =
      (typeof ldProduct?.brand === 'string' ? ldProduct.brand : ldProduct?.brand?.name) ||
      extractMeta('product:brand') ||
      '';
    const extractedSku = ldProduct?.sku || '';

    if (!extractedName && !extractedDesc && !rawPrice) {
      res.status(422).json({
        error: 'No public structured product metadata found at that URL. Please enter details manually.',
      });
      return;
    }

    res.json({
      extracted: {
        name: extractedName,
        description: extractedDesc,
        sellingPrice: rawPrice && !Number.isNaN(Number(rawPrice)) ? Number(rawPrice) : null,
        imageUrl: extractedImage || '',
        brand: extractedBrand,
        sku: extractedSku,
        sourceUrl: rawUrl,
      },
      notice:
        'Only publicly available metadata retrieved from the page is shown below. Please review, complete any missing fields, and confirm before saving.',
    });
  } catch (err) {
    res.status(422).json({
      error:
        err instanceof Error
          ? `Could not fetch URL metadata (${err.message}). Website may restrict automated requests.`
          : 'URL metadata lookup failed.',
    });
  }
});

// METHOD 4: Legitimate Barcode Lookup (Internal Registry + OpenFoodFacts Public Database)
shopkeeperRouter.get('/import/barcode/:code', async (req: AuthenticatedRequest, res) => {
  try {
    requireApprovedShop(req.user!.userId);
    const code = String(req.params.code || '').trim();
    if (code.length < 6) {
      res.status(400).json({ error: 'Enter or scan a valid barcode (minimum 6 digits).' });
      return;
    }

    // Check known verified products in DELIVOO catalog first
    const localMatch = db
      .prepare(`SELECT name, category_name, brand, description, selling_price FROM products WHERE barcode = ? LIMIT 1`)
      .get(code) as any;

    if (localMatch) {
      res.json({
        found: true,
        source: 'DELIVOO Verified Barcode Registry',
        product: {
          barcode: code,
          name: localMatch.name,
          brand: localMatch.brand || '',
          category: localMatch.category_name || '',
          description: localMatch.description || '',
          suggestedPrice: localMatch.selling_price || null,
        },
      });
      return;
    }

    // Query legitimate public OpenFoodFacts API
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 5000);
      const offRes = await fetch(
        `https://world.openfoodfacts.org/api/v0/product/${encodeURIComponent(code)}.json`,
        { signal: controller.signal }
      );
      clearTimeout(timer);
      if (offRes.ok) {
        const data = (await offRes.json()) as any;
        if (data && data.status === 1 && data.product?.product_name) {
          res.json({
            found: true,
            source: 'OpenFoodFacts Public Registry',
            product: {
              barcode: code,
              name: String(data.product.product_name).trim(),
              brand: String(data.product.brands || '').trim(),
              category: 'Grocery',
              description: String(data.product.generic_name || data.product.quantity || '').trim(),
              suggestedPrice: null,
            },
          });
          return;
        }
      }
    } catch {
      // Network offline or timeout — report honestly below
    }

    res.json({
      found: false,
      barcode: code,
      message: `No public barcode record found for "${code}". You can complete the product fields manually below.`,
    });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Barcode lookup failed.' });
  }
});

// TIME-BASED PRODUCT SCHEDULING (Asia/Karachi PKT)
shopkeeperRouter.post('/schedules', (req: AuthenticatedRequest, res) => {
  try {
    const shop = requireApprovedShop(req.user!.userId);
    const {
      productId,
      label = 'Fresh Batch Window',
      startTime,
      endTime,
      daysOfWeek = '0,1,2,3,4,5,6',
      promoPrice,
      discountPercent,
    } = req.body || {};

    const prod = db
      .prepare(`SELECT id FROM products WHERE id = ? AND shop_id = ?`)
      .get(Number(productId), shop.id);
    if (!prod) {
      res.status(404).json({ error: 'Product not found in your shop.' });
      return;
    }
    if (!/^\d{2}:\d{2}$/.test(String(startTime || '')) || !/^\d{2}:\d{2}$/.test(String(endTime || ''))) {
      res.status(400).json({ error: 'Start and end times must be in HH:MM 24-hour format.' });
      return;
    }

    db.prepare(
      `INSERT INTO product_schedules (
         product_id, shop_id, label, start_time, end_time, days_of_week, promo_price, discount_percent, is_paused
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)`
    ).run(
      Number(productId),
      shop.id,
      String(label).trim(),
      String(startTime),
      String(endTime),
      String(daysOfWeek),
      promoPrice ? Number(promoPrice) : null,
      discountPercent ? Number(discountPercent) : null
    );

    broadcastCatalogRefresh();
    res.status(201).json({ message: 'Product availability schedule active (Asia/Karachi timezone).' });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Could not save schedule.' });
  }
});

shopkeeperRouter.put('/schedules/:id', (req: AuthenticatedRequest, res) => {
  try {
    const shop = requireApprovedShop(req.user!.userId);
    const schId = Number(req.params.id);
    const { isPaused, startTime, endTime, daysOfWeek, promoPrice, label } = req.body || {};

    db.prepare(
      `UPDATE product_schedules SET
         label = COALESCE(?, label),
         start_time = COALESCE(?, start_time),
         end_time = COALESCE(?, end_time),
         days_of_week = COALESCE(?, days_of_week),
         promo_price = COALESCE(?, promo_price),
         is_paused = COALESCE(?, is_paused)
       WHERE id = ? AND shop_id = ?`
    ).run(
      label || null,
      startTime || null,
      endTime || null,
      daysOfWeek || null,
      promoPrice !== undefined ? (promoPrice ? Number(promoPrice) : null) : null,
      isPaused !== undefined ? (isPaused ? 1 : 0) : null,
      schId,
      shop.id
    );

    broadcastCatalogRefresh();
    res.json({ message: 'Schedule updated.' });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Update failed.' });
  }
});

shopkeeperRouter.delete('/schedules/:id', (req: AuthenticatedRequest, res) => {
  try {
    const shop = requireApprovedShop(req.user!.userId);
    db.prepare(`DELETE FROM product_schedules WHERE id = ? AND shop_id = ?`).run(
      Number(req.params.id),
      shop.id
    );
    broadcastCatalogRefresh();
    res.json({ message: 'Schedule cancelled.' });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Delete failed.' });
  }
});

// INVENTORY & BATCH MANAGEMENT
shopkeeperRouter.post('/inventory/adjust', (req: AuthenticatedRequest, res) => {
  try {
    const shop = requireApprovedShop(req.user!.userId);
    const { productId, changeAmount, reason = 'Manual stock adjustment' } = req.body || {};
    const delta = Math.floor(Number(changeAmount || 0));
    if (delta === 0) {
      res.status(400).json({ error: 'Adjustment quantity cannot be zero.' });
      return;
    }

    db.transaction(() => {
      const prod = db
        .prepare(`SELECT id, stock_quantity FROM products WHERE id = ? AND shop_id = ?`)
        .get(Number(productId), shop.id) as { id: number; stock_quantity: number } | undefined;

      if (!prod) throw new Error('Product not found in your shop.');
      const nextQty = Math.max(0, prod.stock_quantity + delta);

      db.prepare(`UPDATE products SET stock_quantity = ? WHERE id = ?`).run(nextQty, prod.id);
      db.prepare(
        `INSERT INTO inventory (product_id, shop_id, change_amount, new_quantity, reason, actor_id)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(prod.id, shop.id, delta, nextQty, String(reason).trim(), req.user!.userId);
    })();

    broadcastCatalogRefresh();
    res.json({ message: 'Inventory updated safely.' });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Stock adjustment failed.' });
  }
});

shopkeeperRouter.post('/inventory/batches', (req: AuthenticatedRequest, res) => {
  try {
    const shop = requireApprovedShop(req.user!.userId);
    const { productId, batchCode, quantity, mfgDate = '', expiryDate = '' } = req.body || {};
    const qty = Math.floor(Number(quantity || 0));
    if (qty <= 0 || !batchCode) {
      res.status(400).json({ error: 'Batch code and positive quantity are required.' });
      return;
    }

    db.transaction(() => {
      const prod = db
        .prepare(`SELECT id, stock_quantity FROM products WHERE id = ? AND shop_id = ?`)
        .get(Number(productId), shop.id) as { id: number; stock_quantity: number } | undefined;
      if (!prod) throw new Error('Product not found.');

      const nextQty = prod.stock_quantity + qty;
      db.prepare(
        `UPDATE products SET stock_quantity = ?, expiry_date = CASE WHEN ? != '' THEN ? ELSE expiry_date END WHERE id = ?`
      ).run(nextQty, String(expiryDate).trim(), String(expiryDate).trim(), prod.id);

      db.prepare(
        `INSERT INTO inventory_batches (product_id, shop_id, batch_code, quantity, mfg_date, expiry_date)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(prod.id, shop.id, String(batchCode).trim(), qty, String(mfgDate).trim(), String(expiryDate).trim());

      db.prepare(
        `INSERT INTO inventory (product_id, shop_id, change_amount, new_quantity, reason, actor_id)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(prod.id, shop.id, qty, nextQty, `Batch received: ${batchCode}`, req.user!.userId);
    })();

    broadcastCatalogRefresh();
    res.status(201).json({ message: 'Batch logged and stock incremented.' });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Batch creation failed.' });
  }
});

// SHOP-WISE SUB-ORDER PROCESSING & DISPATCH
shopkeeperRouter.post('/suborders/:id/status', (req: AuthenticatedRequest, res) => {
  try {
    const shop = requireApprovedShop(req.user!.userId);
    const subId = Number(req.params.id);
    const { action, prepTimeMins, rejectionReason = '' } = req.body || {};

    const sub = db
      .prepare(
        `SELECT so.*, po.customer_id, po.payment_status
         FROM shop_orders so
         JOIN parent_orders po ON po.id = so.parent_order_id
         WHERE so.id = ? AND so.shop_id = ?`
      )
      .get(subId, shop.id) as any;

    if (!sub) {
      res.status(404).json({ error: 'Sub-order not found for your shop.' });
      return;
    }

    if (action === 'ACCEPT') {
      const prep = Math.max(5, Number(prepTimeMins || shop.prep_time_mins || 25));
      db.transaction(() => {
        db.prepare(
          `UPDATE shop_orders
           SET shop_status = 'ACCEPTED', prep_time_mins = ?, updated_at = datetime('now')
           WHERE id = ?`
        ).run(prep, subId);
        db.prepare(
          `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
           VALUES (?, ?, 'SHOPKEEPER', 'SHOP_ACCEPTED', ?)`
        ).run(sub.parent_order_id, subId, `${shop.name} accepted order (Est. prep ${prep} mins).`);
        recalculateParentOrderStatus(sub.parent_order_id);
      })();

      createNotification(
        sub.customer_id,
        `${shop.name} Accepted ${sub.sub_order_number}`,
        `Preparation started (approx. ${prep} mins).`,
        'ORDER_UPDATE',
        sub.sub_order_number
      );
    } else if (action === 'PREPARING' || action === 'READY_FOR_PICKUP') {
      db.transaction(() => {
        db.prepare(
          `UPDATE shop_orders SET shop_status = ?, updated_at = datetime('now') WHERE id = ?`
        ).run(action, subId);
        db.prepare(
          `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
           VALUES (?, ?, 'SHOPKEEPER', ?, ?)`
        ).run(
          sub.parent_order_id,
          subId,
          action,
          `${shop.name} marked sub-order as ${action.replace(/_/g, ' ')}.`
        );
      })();

      createNotification(
        sub.customer_id,
        `Order Update (${sub.sub_order_number})`,
        `${shop.name}: ${action === 'READY_FOR_PICKUP' ? 'Packed and ready for rider pickup!' : 'Preparing your items.'}`,
        'ORDER_UPDATE',
        sub.sub_order_number
      );
    } else if (action === 'REJECT') {
      const reason = String(rejectionReason || 'Item unavailable at shop').trim();
      db.transaction(() => {
        db.prepare(
          `UPDATE shop_orders
           SET shop_status = 'REJECTED', delivery_status = 'CANCELLED', rejection_reason = ?, updated_at = datetime('now')
           WHERE id = ?`
        ).run(reason, subId);

        const items = db.prepare(`SELECT * FROM order_items WHERE shop_order_id = ?`).all(subId) as any[];
        for (const it of items) {
          db.prepare(`UPDATE products SET stock_quantity = stock_quantity + ? WHERE id = ?`).run(
            it.quantity,
            it.product_id
          );
        }

        if (sub.payment_status === 'PAID') {
          db.prepare(
            `INSERT INTO refunds (parent_order_id, shop_order_id, customer_id, amount, reason, status)
             VALUES (?, ?, ?, ?, ?, 'REQUESTED')`
          ).run(sub.parent_order_id, subId, sub.customer_id, sub.payable_amount, `Shop rejected: ${reason}`);
          db.prepare(`UPDATE shop_orders SET refund_status = 'REQUESTED' WHERE id = ?`).run(subId);
        }

        db.prepare(
          `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
           VALUES (?, ?, 'SHOPKEEPER', 'SHOP_REJECTED', ?)`
        ).run(sub.parent_order_id, subId, `${shop.name} rejected sub-order: ${reason}`);

        recalculateParentOrderStatus(sub.parent_order_id);
      })();

      createNotification(
        sub.customer_id,
        `Sub-Order Rejected (${sub.sub_order_number})`,
        `${shop.name} could not fulfill ${sub.sub_order_number}: ${reason}. Other shops in your order continue normally.`,
        'ORDER_CANCELLED',
        sub.sub_order_number
      );
    } else {
      res.status(400).json({ error: 'Unsupported action.' });
      return;
    }

    sendWsToUser(sub.customer_id, 'suborder:updated', { shopOrderId: subId });
    sendWsToRole('ADMIN', 'suborder:updated', { shopOrderId: subId });
    res.json({ message: `Sub-order updated (${action}).` });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Could not update sub-order.' });
  }
});

// Dispatch Rider for Sub-Order: DELIVOO Smart Dispatch OR Shop's Own Rider
shopkeeperRouter.post('/suborders/:id/dispatch', (req: AuthenticatedRequest, res) => {
  try {
    const shop = requireApprovedShop(req.user!.userId);
    const subId = Number(req.params.id);
    const { mode = 'DELIVOO_RIDER', ownRiderName, ownRiderPhone, shopRiderDeliveryStatus } = req.body || {};

    const sub = db
      .prepare(
        `SELECT so.*, po.customer_id
         FROM shop_orders so
         JOIN parent_orders po ON po.id = so.parent_order_id
         WHERE so.id = ? AND so.shop_id = ?`
      )
      .get(subId, shop.id) as any;

    if (!sub) {
      res.status(404).json({ error: 'Sub-order not found.' });
      return;
    }

    if (mode === 'SHOP_RIDER') {
      const rName = String(ownRiderName || shop.own_rider_name || `${shop.name} Rider`).trim();
      const rPhone = String(ownRiderPhone || shop.own_rider_phone || shop.phone || '').trim();
      const nextDelivStatus = shopRiderDeliveryStatus || 'ON_THE_WAY';

      db.transaction(() => {
        db.prepare(
          `UPDATE shop_orders
           SET dispatch_mode = 'SHOP_RIDER',
               own_rider_info = ?,
               delivery_status = ?,
               updated_at = datetime('now')
           WHERE id = ?`
        ).run(`${rName} (${rPhone})`, nextDelivStatus, subId);

        db.prepare(
          `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
           VALUES (?, ?, 'SHOPKEEPER', 'SHOP_OWN_RIDER', ?)`
        ).run(sub.parent_order_id, subId, `Shop dispatched own rider ${rName} — Status: ${nextDelivStatus}.`);

        recalculateParentOrderStatus(sub.parent_order_id);
      })();

      createNotification(
        sub.customer_id,
        `Delivery Update (${sub.sub_order_number})`,
        `${shop.name}'s own rider (${rName}) is handling your delivery (${nextDelivStatus.replace(/_/g, ' ')}).`,
        'ORDER_UPDATE',
        sub.sub_order_number
      );
      sendWsToUser(sub.customer_id, 'suborder:updated', { shopOrderId: subId });
      res.json({ assigned: true, mode: 'SHOP_RIDER', ownRider: `${rName} (${rPhone})` });
      return;
    }

    // DELIVOO Shared Fleet Smart Dispatch
    const dispatchRes = smartDispatchSubOrder(subId);
    res.json({
      ...dispatchRes,
      mode: 'DELIVOO_RIDER',
      message: dispatchRes.assigned
        ? `Assigned DELIVOO rider ${dispatchRes.riderName} (${dispatchRes.distanceKm} km away).`
        : 'No online DELIVOO rider currently has free capacity. Queued for automatic/admin assignment.',
    });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Dispatch failed.' });
  }
});
