import bcrypt from 'bcryptjs';
import { Router } from 'express';
import { createCatalogArtwork } from '../artwork.ts';
import { db } from '../db.ts';
import { notifyAllAdmins, sendWsToRole } from '../realtime.ts';
import {
  checkLoginRateLimit,
  clearLoginRateLimit,
  extractBearerToken,
  requireAuth,
  revokeAuthToken,
  signAuthToken,
  writeAuditLog,
  type AuthenticatedRequest,
  type UserRole,
} from '../security.ts';

export const authRouter = Router();

function buildSessionProfile(userId: number) {
  const user = db
    .prepare(
      `SELECT id, name, email, phone, role, status, is_verified, created_at
       FROM users WHERE id = ?`
    )
    .get(userId) as
    | {
        id: number;
        name: string;
        email: string;
        phone: string;
        role: UserRole;
        status: string;
        is_verified: number;
        created_at: string;
      }
    | undefined;

  if (!user) return null;

  let shop = null;
  if (user.role === 'SHOPKEEPER') {
    shop = db.prepare(`SELECT * FROM shops WHERE owner_id = ?`).get(user.id) || null;
  }

  let rider = null;
  if (user.role === 'RIDER') {
    rider = db.prepare(`SELECT * FROM riders WHERE user_id = ?`).get(user.id) || null;
  }

  const addresses = db
    .prepare(`SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, id DESC`)
    .all(user.id);

  const unreadNotifications = (
    db
      .prepare(`SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0`)
      .get(user.id) as { c: number }
  ).c;

  return {
    user,
    shop,
    rider,
    addresses,
    unreadNotifications,
  };
}

// Public Registration (Customer, Shopkeeper -> PENDING approval, Rider -> PENDING approval)
authRouter.post('/register', (req, res) => {
  try {
    const {
      role,
      name,
      email,
      phone,
      password,
      // Customer optional address
      addressLine,
      city = 'Lahore',
      // Shopkeeper fields
      shopName,
      categoryName = 'Grocery',
      shopAddress,
      shopDescription = '',
      cnicNtn = '',
      deliveryFee = 120,
      openingTime = '08:00',
      closingTime = '23:00',
      lat,
      lng,
      // Rider fields
      cnic,
      vehicleType = 'Motorcycle',
      vehiclePlate,
      maxCapacity = 3,
    } = req.body || {};

    if (role === 'ADMIN') {
      res.status(403).json({ error: 'Public registration as Administrator is strictly prohibited.' });
      return;
    }

    if (!['CUSTOMER', 'SHOPKEEPER', 'RIDER'].includes(role)) {
      res.status(400).json({ error: 'Invalid account role selected.' });
      return;
    }

    const cleanName = String(name || '').trim();
    const cleanEmail = String(email || '').toLowerCase().trim();
    const cleanPhone = String(phone || '').trim();
    const rawPassword = String(password || '');

    if (cleanName.length < 2) {
      res.status(400).json({ error: 'Full name must be at least 2 characters.' });
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      res.status(400).json({ error: 'Please provide a valid email address.' });
      return;
    }
    if (cleanPhone.length < 10) {
      res.status(400).json({ error: 'Please provide a valid phone number.' });
      return;
    }
    if (rawPassword.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters.' });
      return;
    }

    const existing = db.prepare(`SELECT id FROM users WHERE email = ?`).get(cleanEmail);
    if (existing) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    if (role === 'SHOPKEEPER') {
      if (!shopName || String(shopName).trim().length < 2) {
        res.status(400).json({ error: 'Shop name is required for Shopkeeper registration.' });
        return;
      }
      if (!shopAddress || String(shopAddress).trim().length < 4) {
        res.status(400).json({ error: 'Shop street address is required.' });
        return;
      }
      if (!cnicNtn || String(cnicNtn).trim().length < 8) {
        res.status(400).json({ error: 'Valid CNIC or NTN number is required for merchant verification.' });
        return;
      }
    }

    if (role === 'RIDER') {
      if (!cnic || String(cnic).trim().length < 11) {
        res.status(400).json({ error: 'Valid CNIC number is required for Rider identity verification.' });
        return;
      }
      if (!vehiclePlate || String(vehiclePlate).trim().length < 3) {
        res.status(400).json({ error: 'Vehicle registration plate number is required.' });
        return;
      }
    }

    const otp = String(Math.floor(100000 + Math.random() * 900000));
    const passHash = bcrypt.hashSync(rawPassword, 10);

    const createdUserId = db.transaction(() => {
      const userRes = db
        .prepare(
          `INSERT INTO users (name, email, phone, password_hash, role, status, is_verified, verification_otp)
           VALUES (?, ?, ?, ?, ?, 'ACTIVE', 1, ?)`
        )
        .run(cleanName, cleanEmail, cleanPhone, passHash, role, otp);

      const userId = Number(userRes.lastInsertRowid);

      if (role === 'CUSTOMER' && addressLine) {
        db.prepare(
          `INSERT INTO addresses (user_id, label, address_line, city, lat, lng, is_default)
           VALUES (?, 'Home', ?, ?, ?, ?, 1)`
        ).run(userId, String(addressLine).trim(), String(city).trim(), lat ?? 31.512, lng ?? 74.345);
      }

      if (role === 'SHOPKEEPER') {
        const cleanShopName = String(shopName).trim();
        const baseSlug = cleanShopName
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/^-|-$/g, '');
        const uniqueSlug = `${baseSlug || 'shop'}-${userId}`;
        const catRow = db
          .prepare(`SELECT id, name FROM shop_categories WHERE name = ?`)
          .get(String(categoryName)) as { id: number; name: string } | undefined;
        const resolvedCat = catRow?.name || 'Grocery';
        const cover = createCatalogArtwork(cleanShopName, `${resolvedCat} · ${city}`, '#059669', '#ecfdf5', 'grocery');

        // CRITICAL REQUIREMENT: Shopkeeper registration starts as PENDING until Admin approves!
        db.prepare(
          `INSERT INTO shops (
             owner_id, name, slug, category_id, category_name, description,
             logo_url, cover_url, address, city, lat, lng,
             opening_time, closing_time, delivery_fee, cnic_ntn, approval_status
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING')`
        ).run(
          userId,
          cleanShopName,
          uniqueSlug,
          catRow?.id ?? null,
          resolvedCat,
          String(shopDescription).trim(),
          cover,
          cover,
          String(shopAddress).trim(),
          String(city).trim(),
          typeof lat === 'number' ? lat : 31.5105,
          typeof lng === 'number' ? lng : 74.344,
          openingTime,
          closingTime,
          Math.max(0, Number(deliveryFee) || 120),
          String(cnicNtn).trim()
        );

        writeAuditLog(userId, 'SHOPKEEPER', 'SHOP_REGISTERED_PENDING', 'SHOP', cleanShopName, `Registered shop ${cleanShopName} awaiting admin approval`);
      }

      if (role === 'RIDER') {
        // CRITICAL REQUIREMENT: Rider registration starts as PENDING until Admin approves!
        db.prepare(
          `INSERT INTO riders (
             user_id, cnic, vehicle_type, vehicle_plate, city,
             approval_status, is_online, max_capacity, current_lat, current_lng
           ) VALUES (?, ?, ?, ?, ?, 'PENDING', 0, ?, ?, ?)`
        ).run(
          userId,
          String(cnic).trim(),
          String(vehicleType).trim(),
          String(vehiclePlate).trim().toUpperCase(),
          String(city).trim(),
          Math.min(10, Math.max(1, Number(maxCapacity) || 3)),
          typeof lat === 'number' ? lat : 31.51,
          typeof lng === 'number' ? lng : 74.345
        );

        writeAuditLog(userId, 'RIDER', 'RIDER_REGISTERED_PENDING', 'RIDER', cleanName, `Registered rider ${cleanName} (${vehiclePlate}) awaiting admin approval`);
      }

      return userId;
    })();

    if (role === 'SHOPKEEPER') {
      notifyAllAdmins(
        'New Shopkeeper Registration Pending Approval',
        `${cleanName} registered shop "${String(shopName).trim()}" (${city}). Review and approve to publish on DELIVOO.`,
        'APPROVAL_REQUIRED',
        String(createdUserId)
      );
      sendWsToRole('ADMIN', 'approvals:updated', { role: 'SHOPKEEPER', userId: createdUserId });
    } else if (role === 'RIDER') {
      notifyAllAdmins(
        'New Rider Registration Pending Approval',
        `${cleanName} (${String(vehiclePlate).toUpperCase()}) submitted Rider KYC for Admin approval.`,
        'APPROVAL_REQUIRED',
        String(createdUserId)
      );
      sendWsToRole('ADMIN', 'approvals:updated', { role: 'RIDER', userId: createdUserId });
    }

    const token = signAuthToken({ userId: createdUserId, role: role as UserRole, email: cleanEmail });
    const session = buildSessionProfile(createdUserId);

    res.status(201).json({
      token,
      ...session,
      message:
        role === 'CUSTOMER'
          ? 'Welcome to DELIVOO! Your customer account is ready.'
          : 'Registration submitted! Your account is now awaiting Admin approval before going live in DELIVOO.',
    });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Registration failed.' });
  }
});

authRouter.post('/login', (req, res) => {
  const { email, password, expectedRole } = req.body || {};
  const cleanEmail = String(email || '').toLowerCase().trim();
  const rateKey = `${req.ip}:${cleanEmail}`;

  const limit = checkLoginRateLimit(rateKey);
  if (!limit.allowed) {
    res.status(429).json({
      error: `Too many login attempts. Please wait ${limit.retryAfterSec} seconds before trying again.`,
    });
    return;
  }

  const user = db
    .prepare(`SELECT * FROM users WHERE email = ?`)
    .get(cleanEmail) as
    | {
        id: number;
        name: string;
        email: string;
        password_hash: string;
        role: UserRole;
        status: string;
      }
    | undefined;

  if (!user || !bcrypt.compareSync(String(password || ''), user.password_hash)) {
    res.status(401).json({ error: 'Invalid email or password.' });
    return;
  }

  if (expectedRole && user.role !== expectedRole) {
    res.status(403).json({
      error: `This account belongs to the ${user.role} portal. Please select ${user.role} to sign in.`,
    });
    return;
  }

  if (user.status !== 'ACTIVE') {
    res.status(403).json({ error: 'Your account is currently suspended. Contact DELIVOO Helpline.' });
    return;
  }

  clearLoginRateLimit(rateKey);
  const token = signAuthToken({ userId: user.id, role: user.role, email: user.email });
  const session = buildSessionProfile(user.id);

  res.json({ token, ...session });
});

authRouter.get('/me', requireAuth, (req: AuthenticatedRequest, res) => {
  const session = buildSessionProfile(req.user!.userId);
  if (!session) {
    res.status(404).json({ error: 'Account not found.' });
    return;
  }
  res.json(session);
});

authRouter.put('/profile', requireAuth, (req: AuthenticatedRequest, res) => {
  const { name, phone, addressLine, city, lat, lng } = req.body || {};
  const userId = req.user!.userId;
  if (name && String(name).trim().length >= 2) {
    db.prepare(`UPDATE users SET name = ? WHERE id = ?`).run(String(name).trim(), userId);
  }
  if (phone && String(phone).trim().length >= 10) {
    db.prepare(`UPDATE users SET phone = ? WHERE id = ?`).run(String(phone).trim(), userId);
  }
  if (addressLine && String(addressLine).trim().length >= 4) {
    const existing = db
      .prepare(`SELECT id FROM addresses WHERE user_id = ? AND is_default = 1`)
      .get(userId) as { id: number } | undefined;
    if (existing) {
      db.prepare(
        `UPDATE addresses SET address_line = ?, city = COALESCE(?, city), lat = COALESCE(?, lat), lng = COALESCE(?, lng) WHERE id = ?`
      ).run(String(addressLine).trim(), city || null, lat ?? null, lng ?? null, existing.id);
    } else {
      db.prepare(
        `INSERT INTO addresses (user_id, label, address_line, city, lat, lng, is_default)
         VALUES (?, 'Home', ?, ?, ?, ?, 1)`
      ).run(userId, String(addressLine).trim(), city || 'Lahore', lat ?? null, lng ?? null);
    }
  }
  res.json(buildSessionProfile(userId));
});

authRouter.post('/forgot-password', (req, res) => {
  const cleanEmail = String(req.body?.email || '').toLowerCase().trim();
  const user = db.prepare(`SELECT id, email FROM users WHERE email = ?`).get(cleanEmail) as
    | { id: number; email: string }
    | undefined;

  if (!user) {
    res.status(404).json({ error: 'No registered account found with that email.' });
    return;
  }

  const otp = String(Math.floor(100000 + Math.random() * 900000));
  const otpHash = bcrypt.hashSync(otp, 8);
  const expires = new Date(Date.now() + 15 * 60 * 1000).toISOString();

  db.prepare(`UPDATE users SET reset_otp = ?, reset_otp_expires = ? WHERE id = ?`).run(
    otpHash,
    expires,
    user.id
  );

  const smtpConfigured = Boolean(process.env.SMTP_HOST && process.env.SMTP_USER);
  res.json({
    message: smtpConfigured
      ? 'A 6-digit password reset code has been dispatched to your registered email.'
      : 'Reset OTP generated (local development mode — no external SMTP configured).',
    devOtpPreview: process.env.NODE_ENV !== 'production' ? otp : undefined,
  });
});

authRouter.post('/reset-password', (req, res) => {
  const { email, otp, newPassword } = req.body || {};
  const cleanEmail = String(email || '').toLowerCase().trim();

  if (!newPassword || String(newPassword).length < 6) {
    res.status(400).json({ error: 'New password must be at least 6 characters.' });
    return;
  }

  const user = db
    .prepare(`SELECT id, reset_otp, reset_otp_expires FROM users WHERE email = ?`)
    .get(cleanEmail) as
    | { id: number; reset_otp: string | null; reset_otp_expires: string | null }
    | undefined;

  if (!user || !user.reset_otp || !user.reset_otp_expires) {
    res.status(400).json({ error: 'No active password reset request found.' });
    return;
  }

  if (new Date(user.reset_otp_expires).getTime() < Date.now()) {
    res.status(400).json({ error: 'Reset code has expired. Please request a new code.' });
    return;
  }

  if (!bcrypt.compareSync(String(otp || '').trim(), user.reset_otp)) {
    res.status(400).json({ error: 'Invalid 6-digit reset OTP.' });
    return;
  }

  const newHash = bcrypt.hashSync(String(newPassword), 10);
  db.prepare(
    `UPDATE users SET password_hash = ?, reset_otp = NULL, reset_otp_expires = NULL WHERE id = ?`
  ).run(newHash, user.id);

  res.json({ message: 'Password reset successful. You may now sign in.' });
});

authRouter.post('/logout', requireAuth, (req: AuthenticatedRequest, res) => {
  const token = extractBearerToken(req);
  if (token) revokeAuthToken(token);
  res.json({ message: 'Logged out securely.' });
});

authRouter.get('/notifications', requireAuth, (req: AuthenticatedRequest, res) => {
  const list = db
    .prepare(`SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 40`)
    .all(req.user!.userId);
  res.json({ notifications: list });
});

authRouter.post('/notifications/read', requireAuth, (req: AuthenticatedRequest, res) => {
  db.prepare(`UPDATE notifications SET is_read = 1 WHERE user_id = ?`).run(req.user!.userId);
  res.json({ ok: true });
});

// Development/Sandbox helper (disabled in commercial production via ENABLE_SANDBOX_ACCOUNTS=false)
authRouter.get('/sandbox-accounts', (_req, res) => {
  if (process.env.ENABLE_SANDBOX_ACCOUNTS === 'false') {
    res.json({ enabled: false, accounts: [] });
    return;
  }
  res.json({
    enabled: true,
    accounts: [
      { role: 'CUSTOMER', label: 'Ayesha (Customer)', email: 'customer@delivoo.pk', password: 'Customer@Delivoo2026' },
      { role: 'SHOPKEEPER', label: 'Fresh Mart (Approved Shop)', email: 'freshmart@delivoo.pk', password: 'Shop@Delivoo2026' },
      { role: 'SHOPKEEPER', label: 'Lahore Spice (Pending Approval)', email: 'spicebazaar@delivoo.pk', password: 'Shop@Delivoo2026' },
      { role: 'RIDER', label: 'Ali Raza (Approved Rider)', email: 'ali.rider@delivoo.pk', password: 'Rider@Delivoo2026' },
      { role: 'RIDER', label: 'Usman (Pending Rider)', email: 'usman.rider@delivoo.pk', password: 'Rider@Delivoo2026' },
      {
        role: 'ADMIN',
        label: 'Operations Admin',
        email: process.env.ADMIN_EMAIL || 'admin@delivoo.pk',
        password: process.env.ADMIN_INITIAL_PASSWORD || 'Admin@Delivoo2026',
      },
    ],
  });
});
