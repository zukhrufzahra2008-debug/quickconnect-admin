import { Router } from 'express';
import { recalculateParentOrderStatus, smartDispatchSubOrder } from '../availability.ts';
import { db } from '../db.ts';
import { createNotification, notifyAllAdmins, sendWsToRole, sendWsToUser } from '../realtime.ts';
import { requireAuth, requireRole, type AuthenticatedRequest } from '../security.ts';

export const riderRouter = Router();

riderRouter.use(requireAuth, requireRole('RIDER'));

function getRiderProfile(userId: number): any {
  return db.prepare(`SELECT * FROM riders WHERE user_id = ?`).get(userId);
}

function requireApprovedRider(userId: number): any {
  const rider = getRiderProfile(userId);
  if (!rider) throw new Error('Rider profile not found.');
  if (rider.approval_status !== 'APPROVED') {
    throw new Error(
      `Your Rider account status is "${rider.approval_status}". Admin approval is required before going online or accepting deliveries.`
    );
  }
  return rider;
}

riderRouter.get('/dashboard', (req: AuthenticatedRequest, res) => {
  const rider = getRiderProfile(req.user!.userId);
  if (!rider) {
    res.status(404).json({ error: 'Rider profile not found.' });
    return;
  }

  const activeDeliveries = (
    db
      .prepare(
        `SELECT so.*, s.name as shop_name, s.address as shop_address, s.lat as shop_lat, s.lng as shop_lng,
                po.order_number, po.delivery_address, po.delivery_city, po.delivery_lat, po.delivery_lng,
                po.contact_phone, po.delivery_instructions, po.payment_method,
                cu.name as customer_name,
                ra.id as assignment_id, ra.status as assignment_status, ra.earning_amount, ra.distance_km
         FROM shop_orders so
         JOIN shops s ON s.id = so.shop_id
         JOIN parent_orders po ON po.id = so.parent_order_id
         JOIN users cu ON cu.id = po.customer_id
         LEFT JOIN rider_assignments ra ON ra.shop_order_id = so.id AND ra.rider_id = ? AND ra.status IN ('OFFERED', 'ACCEPTED')
         WHERE so.rider_id = ? AND so.delivery_status NOT IN ('DELIVERED', 'CANCELLED')
         ORDER BY so.id DESC`
      )
      .all(rider.id, rider.id) as any[]
  ).map((so) => ({
    ...so,
    items: db.prepare(`SELECT * FROM order_items WHERE shop_order_id = ?`).all(so.id),
  }));

  const deliveryHistory = db
    .prepare(
      `SELECT so.id, so.sub_order_number, so.delivery_status, so.updated_at,
              s.name as shop_name, po.delivery_address,
              COALESCE(ra.earning_amount, 110) as earning_amount, ra.distance_km
       FROM shop_orders so
       JOIN shops s ON s.id = so.shop_id
       JOIN parent_orders po ON po.id = so.parent_order_id
       LEFT JOIN rider_assignments ra ON ra.shop_order_id = so.id AND ra.rider_id = ?
       WHERE so.rider_id = ? AND so.delivery_status = 'DELIVERED'
       ORDER BY so.id DESC LIMIT 30`
    )
    .all(rider.id, rider.id);

  res.json({
    rider,
    activeDeliveries,
    deliveryHistory,
  });
});

// Update / Resubmit Rider KYC & Vehicle Details (available while PENDING or REJECTED)
riderRouter.put('/application', (req: AuthenticatedRequest, res) => {
  const rider = getRiderProfile(req.user!.userId);
  if (!rider) {
    res.status(404).json({ error: 'Rider record not found.' });
    return;
  }

  const { cnic, vehicleType, vehiclePlate, city, maxCapacity, resubmitForApproval } = req.body || {};
  const nextStatus =
    resubmitForApproval && rider.approval_status === 'REJECTED' ? 'PENDING' : rider.approval_status;

  db.prepare(
    `UPDATE riders SET
       cnic = COALESCE(?, cnic),
       vehicle_type = COALESCE(?, vehicle_type),
       vehicle_plate = COALESCE(?, vehicle_plate),
       city = COALESCE(?, city),
       max_capacity = COALESCE(?, max_capacity),
       approval_status = ?
     WHERE id = ?`
  ).run(
    cnic ? String(cnic).trim() : null,
    vehicleType ? String(vehicleType).trim() : null,
    vehiclePlate ? String(vehiclePlate).toUpperCase().trim() : null,
    city ? String(city).trim() : null,
    maxCapacity !== undefined ? Math.min(10, Math.max(1, Number(maxCapacity))) : null,
    nextStatus,
    rider.id
  );

  if (resubmitForApproval && rider.approval_status === 'REJECTED') {
    notifyAllAdmins(
      `Rider Application Resubmitted`,
      `Rider (${vehiclePlate || rider.vehicle_plate}) updated KYC details and requested Admin approval.`,
      'APPROVAL_REQUIRED',
      String(rider.id)
    );
  }

  res.json({ message: 'Rider details updated.', rider: getRiderProfile(req.user!.userId) });
});

riderRouter.post('/online', (req: AuthenticatedRequest, res) => {
  try {
    const rider = requireApprovedRider(req.user!.userId);
    const isOnline = req.body?.isOnline ? 1 : 0;

    db.prepare(`UPDATE riders SET is_online = ? WHERE id = ?`).run(isOnline, rider.id);

    // If rider just came online and has spare capacity, check if any sub-order is PENDING_ASSIGNMENT
    if (isOnline === 1) {
      const waiting = db
        .prepare(`SELECT id FROM shop_orders WHERE delivery_status = 'PENDING_ASSIGNMENT' ORDER BY id ASC LIMIT 3`)
        .all() as { id: number }[];
      for (const w of waiting) {
        smartDispatchSubOrder(w.id);
      }
    }

    res.json({ isOnline: Boolean(isOnline), rider: getRiderProfile(req.user!.userId) });
  } catch (err) {
    res.status(403).json({ error: err instanceof Error ? err.message : 'Cannot change online state.' });
  }
});

// Real Device GPS Location Update (Section 12 & 14)
riderRouter.post('/location', (req: AuthenticatedRequest, res) => {
  try {
    const rider = requireApprovedRider(req.user!.userId);
    const lat = Number(req.body?.lat);
    const lng = Number(req.body?.lng);

    if (Number.isNaN(lat) || Number.isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      res.status(400).json({ error: 'Valid GPS coordinates are required.' });
      return;
    }

    const nowIso = new Date().toISOString();
    db.transaction(() => {
      db.prepare(
        `UPDATE riders SET current_lat = ?, current_lng = ?, last_gps_at = ? WHERE id = ?`
      ).run(lat, lng, nowIso, rider.id);

      const activeSubs = db
        .prepare(
          `SELECT so.id, po.customer_id
           FROM shop_orders so
           JOIN parent_orders po ON po.id = so.parent_order_id
           WHERE so.rider_id = ? AND so.delivery_status NOT IN ('DELIVERED', 'CANCELLED')`
        )
        .all(rider.id) as { id: number; customer_id: number }[];

      for (const s of activeSubs) {
        db.prepare(
          `INSERT INTO rider_locations (rider_id, shop_order_id, lat, lng, recorded_at)
           VALUES (?, ?, ?, ?, ?)`
        ).run(rider.id, s.id, lat, lng, nowIso);

        sendWsToUser(s.customer_id, 'rider:location', {
          shopOrderId: s.id,
          riderId: rider.id,
          lat,
          lng,
          recordedAt: nowIso,
        });
      }

      sendWsToRole('ADMIN', 'rider:location', { riderId: rider.id, lat, lng, recordedAt: nowIso });
    })();

    res.json({ ok: true, lat, lng, recordedAt: nowIso });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'GPS update failed.' });
  }
});

// Accept or Reject Dispatch Request
riderRouter.post('/assignments/:shopOrderId/respond', (req: AuthenticatedRequest, res) => {
  try {
    const rider = requireApprovedRider(req.user!.userId);
    const subId = Number(req.params.shopOrderId);
    const decision = String(req.body?.decision || '').toUpperCase(); // ACCEPT | REJECT

    const sub = db
      .prepare(
        `SELECT so.*, po.customer_id, s.owner_id, s.name as shop_name
         FROM shop_orders so
         JOIN parent_orders po ON po.id = so.parent_order_id
         JOIN shops s ON s.id = so.shop_id
         WHERE so.id = ? AND so.rider_id = ?`
      )
      .get(subId, rider.id) as any;

    if (!sub) {
      res.status(404).json({ error: 'Delivery assignment not found.' });
      return;
    }

    if (decision === 'ACCEPT') {
      db.transaction(() => {
        db.prepare(
          `UPDATE shop_orders SET delivery_status = 'ACCEPTED', updated_at = datetime('now') WHERE id = ?`
        ).run(subId);
        db.prepare(
          `UPDATE rider_assignments SET status = 'ACCEPTED', responded_at = datetime('now')
           WHERE shop_order_id = ? AND rider_id = ? AND status = 'OFFERED'`
        ).run(subId, rider.id);
        db.prepare(
          `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
           VALUES (?, ?, 'RIDER', 'RIDER_ACCEPTED', 'Rider accepted the delivery assignment.')`
        ).run(sub.parent_order_id, subId);
      })();

      createNotification(
        sub.customer_id,
        `Rider Accepted (${sub.sub_order_number})`,
        `Your rider is heading to ${sub.shop_name} for pickup.`,
        'ORDER_UPDATE',
        sub.sub_order_number
      );
      sendWsToUser(sub.customer_id, 'suborder:updated', { shopOrderId: subId });
      res.json({ message: 'Delivery request accepted!' });
      return;
    }

    if (decision === 'REJECT') {
      db.transaction(() => {
        db.prepare(
          `UPDATE rider_assignments SET status = 'REJECTED', responded_at = datetime('now')
           WHERE shop_order_id = ? AND rider_id = ? AND status = 'OFFERED'`
        ).run(subId, rider.id);
        db.prepare(
          `UPDATE riders SET active_deliveries = MAX(0, active_deliveries - 1) WHERE id = ?`
        ).run(rider.id);
        db.prepare(
          `UPDATE shop_orders SET rider_id = NULL, delivery_status = 'PENDING_ASSIGNMENT', updated_at = datetime('now')
           WHERE id = ?`
        ).run(subId);
        db.prepare(
          `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
           VALUES (?, ?, 'RIDER', 'RIDER_REJECTED', 'Assigned rider declined; searching for next available rider.')`
        ).run(sub.parent_order_id, subId);
      })();

      // Automatically attempt next available rider excluding this rider
      const prevRejected = (
        db
          .prepare(`SELECT rider_id FROM rider_assignments WHERE shop_order_id = ? AND status = 'REJECTED'`)
          .all(subId) as { rider_id: number }[]
      ).map((r) => r.rider_id);

      smartDispatchSubOrder(subId, prevRejected);
      res.json({ message: 'Request declined and reassigned.' });
      return;
    }

    res.status(400).json({ error: 'Decision must be ACCEPT or REJECT.' });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Could not process response.' });
  }
});

// 7-Stage Delivery Progression:
// ASSIGNED -> ACCEPTED -> ARRIVED_AT_SHOP -> PICKED_UP -> ON_THE_WAY -> ARRIVED_AT_CUSTOMER -> DELIVERED
const VALID_PROGRESSION: Record<string, string[]> = {
  ASSIGNED: ['ACCEPTED'],
  ACCEPTED: ['ARRIVED_AT_SHOP'],
  ARRIVED_AT_SHOP: ['PICKED_UP'],
  PICKED_UP: ['ON_THE_WAY'],
  ON_THE_WAY: ['ARRIVED_AT_CUSTOMER'],
  ARRIVED_AT_CUSTOMER: ['DELIVERED'],
};

riderRouter.post('/suborders/:id/status', (req: AuthenticatedRequest, res) => {
  try {
    const rider = requireApprovedRider(req.user!.userId);
    const subId = Number(req.params.id);
    const nextStatus = String(req.body?.status || '').toUpperCase();

    const sub = db
      .prepare(
        `SELECT so.*, po.customer_id, po.payment_method, s.owner_id, s.name as shop_name
         FROM shop_orders so
         JOIN parent_orders po ON po.id = so.parent_order_id
         JOIN shops s ON s.id = so.shop_id
         WHERE so.id = ? AND so.rider_id = ?`
      )
      .get(subId, rider.id) as any;

    if (!sub) {
      res.status(404).json({ error: 'Active delivery not found.' });
      return;
    }

    const allowed = VALID_PROGRESSION[sub.delivery_status] || [];
    if (!allowed.includes(nextStatus)) {
      res.status(400).json({
        error: `Cannot transition directly from ${sub.delivery_status} to ${nextStatus}.`,
      });
      return;
    }

    db.transaction(() => {
      db.prepare(
        `UPDATE shop_orders SET delivery_status = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(nextStatus, subId);

      db.prepare(
        `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
         VALUES (?, ?, 'RIDER', ?, ?)`
      ).run(
        sub.parent_order_id,
        subId,
        nextStatus,
        `Delivery status updated to ${nextStatus.replace(/_/g, ' ')}.`
      );

      if (nextStatus === 'DELIVERED') {
        const assign = db
          .prepare(
            `SELECT id, earning_amount FROM rider_assignments
             WHERE shop_order_id = ? AND rider_id = ? ORDER BY id DESC LIMIT 1`
          )
          .get(subId, rider.id) as { id: number; earning_amount: number } | undefined;

        const payout = Number(assign?.earning_amount || 110);

        if (assign) {
          db.prepare(`UPDATE rider_assignments SET status = 'COMPLETED' WHERE id = ?`).run(assign.id);
        }

        db.prepare(
          `UPDATE riders
           SET active_deliveries = MAX(0, active_deliveries - 1),
               total_earnings = total_earnings + ?
           WHERE id = ?`
        ).run(payout, rider.id);

        // Credit merchant settlement
        const netMerchant = Math.max(0, Number(sub.subtotal) - Number(sub.commission_amount));
        db.prepare(
          `INSERT INTO settlements (shop_id, shop_order_id, amount, status)
           VALUES (?, ?, ?, 'CREDITED')`
        ).run(sub.shop_id, subId, netMerchant);

        recalculateParentOrderStatus(sub.parent_order_id);

        // If all sub-orders of a COD parent order are now DELIVERED, mark payment PAID
        const parentCheck = db
          .prepare(`SELECT overall_status, payment_method FROM parent_orders WHERE id = ?`)
          .get(sub.parent_order_id) as { overall_status: string; payment_method: string };
        if (parentCheck.overall_status === 'COMPLETED' && parentCheck.payment_method === 'COD') {
          db.prepare(`UPDATE parent_orders SET payment_status = 'PAID' WHERE id = ?`).run(sub.parent_order_id);
          db.prepare(`UPDATE payments SET status = 'PAID', verified_at = datetime('now') WHERE parent_order_id = ?`).run(
            sub.parent_order_id
          );
        }
      }
    })();

    createNotification(
      sub.customer_id,
      `Delivery ${nextStatus.replace(/_/g, ' ')} (${sub.sub_order_number})`,
      nextStatus === 'DELIVERED'
        ? `Your order from ${sub.shop_name} has been delivered! You can now rate your experience.`
        : `Rider update for ${sub.shop_name}: ${nextStatus.replace(/_/g, ' ')}.`,
      'DELIVERY_STATUS',
      sub.sub_order_number
    );

    sendWsToUser(sub.customer_id, 'suborder:updated', { shopOrderId: subId, status: nextStatus });
    sendWsToUser(sub.owner_id, 'suborder:updated', { shopOrderId: subId, status: nextStatus });
    sendWsToRole('ADMIN', 'suborder:updated', { shopOrderId: subId, status: nextStatus });

    res.json({ message: `Status updated to ${nextStatus.replace(/_/g, ' ')}.` });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Status update failed.' });
  }
});
