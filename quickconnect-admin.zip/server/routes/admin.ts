import { Router } from 'express';
import { computeRiderPayout, haversineKm, recalculateParentOrderStatus } from '../availability.ts';
import { db } from '../db.ts';
import { broadcastCatalogRefresh, createNotification, sendWsToUser } from '../realtime.ts';
import {
  requireAuth,
  requireRole,
  writeAuditLog,
  type AuthenticatedRequest,
} from '../security.ts';

export const adminRouter = Router();

adminRouter.use(requireAuth, requireRole('ADMIN'));

// Analytics & Marketplace Overview (Section 15 — All 13 metrics + Date Filter)
adminRouter.get('/analytics', (req, res) => {
  const range = String(req.query.range || 'ALL'); // ALL | 7D | TODAY
  let dateClause = '';
  if (range === 'TODAY') {
    dateClause = `AND date(created_at) = date('now')`;
  } else if (range === '7D') {
    dateClause = `AND datetime(created_at) >= datetime('now', '-7 days')`;
  }

  const totalCustomers = (
    db.prepare(`SELECT COUNT(*) as c FROM users WHERE role = 'CUSTOMER'`).get() as { c: number }
  ).c;
  const totalShops = (db.prepare(`SELECT COUNT(*) as c FROM shops`).get() as { c: number }).c;
  const approvedShops = (
    db.prepare(`SELECT COUNT(*) as c FROM shops WHERE approval_status = 'APPROVED'`).get() as { c: number }
  ).c;
  const pendingShopApprovals = (
    db.prepare(`SELECT COUNT(*) as c FROM shops WHERE approval_status = 'PENDING'`).get() as { c: number }
  ).c;
  const activeRiders = (
    db
      .prepare(`SELECT COUNT(*) as c FROM riders WHERE approval_status = 'APPROVED'`)
      .get() as { c: number }
  ).c;
  const onlineRiders = (
    db
      .prepare(`SELECT COUNT(*) as c FROM riders WHERE approval_status = 'APPROVED' AND is_online = 1`)
      .get() as { c: number }
  ).c;
  const pendingRiderApprovals = (
    db.prepare(`SELECT COUNT(*) as c FROM riders WHERE approval_status = 'PENDING'`).get() as { c: number }
  ).c;

  const totalOrders = (
    db.prepare(`SELECT COUNT(*) as c FROM parent_orders WHERE 1=1 ${dateClause}`).get() as { c: number }
  ).c;
  const activeOrders = (
    db
      .prepare(
        `SELECT COUNT(*) as c FROM parent_orders WHERE overall_status IN ('PLACED', 'IN_PROGRESS', 'PARTIALLY_DELIVERED') ${dateClause}`
      )
      .get() as { c: number }
  ).c;
  const deliveredOrders = (
    db
      .prepare(`SELECT COUNT(*) as c FROM parent_orders WHERE overall_status = 'COMPLETED' ${dateClause}`)
      .get() as { c: number }
  ).c;
  const cancelledOrders = (
    db
      .prepare(
        `SELECT COUNT(*) as c FROM parent_orders WHERE overall_status IN ('CANCELLED', 'PARTIALLY_CANCELLED') ${dateClause}`
      )
      .get() as { c: number }
  ).c;

  const financials = db
    .prepare(
      `SELECT COALESCE(SUM(subtotal), 0) as grossOrderValue,
              COALESCE(SUM(commission_amount), 0) as platformCommissions,
              COALESCE(SUM(delivery_fee), 0) as deliveryRevenue
       FROM shop_orders
       WHERE shop_status NOT IN ('CANCELLED', 'REJECTED') ${dateClause}`
    )
    .get() as {
    grossOrderValue: number;
    platformCommissions: number;
    deliveryRevenue: number;
  };

  const categorySales = db
    .prepare(
      `SELECT s.category_name as category,
              COUNT(so.id) as subOrdersCount,
              COALESCE(SUM(so.subtotal), 0) as revenue
       FROM shops s
       LEFT JOIN shop_orders so ON so.shop_id = s.id AND so.shop_status NOT IN ('CANCELLED', 'REJECTED')
       GROUP BY s.category_name
       ORDER BY revenue DESC`
    )
    .all();

  res.json({
    metrics: {
      totalCustomers,
      totalShops,
      approvedShops,
      pendingShopApprovals,
      activeRiders,
      onlineRiders,
      pendingRiderApprovals,
      totalOrders,
      activeOrders,
      deliveredOrders,
      cancelledOrders,
      grossOrderValue: financials.grossOrderValue,
      platformCommissions: financials.platformCommissions,
      deliveryRevenue: financials.deliveryRevenue,
    },
    categorySales,
  });
});

// Pending & All Shopkeeper + Rider Registrations Queue
adminRouter.get('/approvals', (_req, res) => {
  const shops = db
    .prepare(
      `SELECT s.*, u.name as owner_name, u.email as owner_email, u.phone as owner_phone, u.status as user_status
       FROM shops s
       JOIN users u ON u.id = s.owner_id
       ORDER BY CASE s.approval_status WHEN 'PENDING' THEN 0 WHEN 'REJECTED' THEN 1 ELSE 2 END, s.id DESC`
    )
    .all();

  const riders = db
    .prepare(
      `SELECT r.*, u.name as rider_name, u.email as rider_email, u.phone as rider_phone, u.status as user_status
       FROM riders r
       JOIN users u ON u.id = r.user_id
       ORDER BY CASE r.approval_status WHEN 'PENDING' THEN 0 WHEN 'REJECTED' THEN 1 ELSE 2 END, r.id DESC`
    )
    .all();

  res.json({ shops, riders });
});

// Approve / Reject / Suspend Shopkeeper Registration
adminRouter.post('/shops/:id/approval', (req: AuthenticatedRequest, res) => {
  const shopId = Number(req.params.id);
  const { status, reason = '', commissionRate } = req.body || {};

  if (!['APPROVED', 'REJECTED', 'SUSPENDED', 'PENDING'].includes(status)) {
    res.status(400).json({ error: 'Invalid approval status.' });
    return;
  }

  const shop = db.prepare(`SELECT * FROM shops WHERE id = ?`).get(shopId) as any;
  if (!shop) {
    res.status(404).json({ error: 'Shop not found.' });
    return;
  }

  db.prepare(
    `UPDATE shops SET
       approval_status = ?,
       rejection_reason = ?,
       commission_rate = COALESCE(?, commission_rate)
     WHERE id = ?`
  ).run(
    status,
    status === 'REJECTED' || status === 'SUSPENDED' ? String(reason).trim() : '',
    commissionRate !== undefined ? Math.max(0, Math.min(50, Number(commissionRate))) : null,
    shopId
  );

  writeAuditLog(
    req.user!.userId,
    'ADMIN',
    `SHOP_${status}`,
    'SHOP',
    shopId,
    `Updated shop "${shop.name}" to ${status}${reason ? ` (${reason})` : ''}`
  );

  createNotification(
    shop.owner_id,
    status === 'APPROVED'
      ? `Congratulations! "${shop.name}" is Approved`
      : `Shop Application Update: ${status}`,
    status === 'APPROVED'
      ? `Admin approved your shop! Your shop is now live on DELIVOO and ready to publish products and accept orders.`
      : `Your shop status was updated to ${status}.${reason ? ` Reason: ${reason}` : ''}`,
    'APPROVAL_UPDATE',
    String(shopId)
  );

  // Real-time push so open Shopkeeper session immediately unlocks!
  sendWsToUser(shop.owner_id, 'approval:updated', { role: 'SHOPKEEPER', shopId, status });
  broadcastCatalogRefresh();

  res.json({ message: `Shop "${shop.name}" marked as ${status}.` });
});

// Approve / Reject / Suspend Rider Registration
adminRouter.post('/riders/:id/approval', (req: AuthenticatedRequest, res) => {
  const riderId = Number(req.params.id);
  const { status, reason = '' } = req.body || {};

  if (!['APPROVED', 'REJECTED', 'SUSPENDED', 'PENDING'].includes(status)) {
    res.status(400).json({ error: 'Invalid approval status.' });
    return;
  }

  const rider = db
    .prepare(
      `SELECT r.*, u.name as rider_name
       FROM riders r
       JOIN users u ON u.id = r.user_id
       WHERE r.id = ?`
    )
    .get(riderId) as any;

  if (!rider) {
    res.status(404).json({ error: 'Rider not found.' });
    return;
  }

  db.prepare(
    `UPDATE riders SET
       approval_status = ?,
       rejection_reason = ?,
       is_online = CASE WHEN ? != 'APPROVED' THEN 0 ELSE is_online END
     WHERE id = ?`
  ).run(
    status,
    status === 'REJECTED' || status === 'SUSPENDED' ? String(reason).trim() : '',
    status,
    riderId
  );

  writeAuditLog(
    req.user!.userId,
    'ADMIN',
    `RIDER_${status}`,
    'RIDER',
    riderId,
    `Updated rider "${rider.rider_name}" (${rider.vehicle_plate}) to ${status}${reason ? ` (${reason})` : ''}`
  );

  createNotification(
    rider.user_id,
    status === 'APPROVED'
      ? `Rider Account Approved!`
      : `Rider Verification Update: ${status}`,
    status === 'APPROVED'
      ? `Admin verified your identity and vehicle (${rider.vehicle_plate}). You can now go Online and accept deliveries!`
      : `Your rider status was updated to ${status}.${reason ? ` Reason: ${reason}` : ''}`,
    'APPROVAL_UPDATE',
    String(riderId)
  );

  // Real-time push so open Rider session immediately unlocks!
  sendWsToUser(rider.user_id, 'approval:updated', { role: 'RIDER', riderId, status });

  res.json({ message: `Rider "${rider.rider_name}" marked as ${status}.` });
});

// Manage Users & Suspend/Activate Accounts
adminRouter.get('/users', (_req, res) => {
  const users = db
    .prepare(
      `SELECT id, name, email, phone, role, status, created_at
       FROM users
       ORDER BY id DESC`
    )
    .all();
  const categories = db.prepare(`SELECT * FROM shop_categories ORDER BY sort_order ASC`).all();
  const products = db
    .prepare(
      `SELECT p.*, s.name as shop_name
       FROM products p
       JOIN shops s ON s.id = p.shop_id
       ORDER BY p.id DESC LIMIT 100`
    )
    .all();
  res.json({ users, categories, products });
});

adminRouter.post('/users/:id/status', (req: AuthenticatedRequest, res) => {
  const targetId = Number(req.params.id);
  const status = req.body?.status === 'SUSPENDED' ? 'SUSPENDED' : 'ACTIVE';

  if (targetId === req.user!.userId) {
    res.status(400).json({ error: 'Cannot suspend your own active Admin account.' });
    return;
  }

  db.prepare(`UPDATE users SET status = ? WHERE id = ?`).run(status, targetId);
  writeAuditLog(req.user!.userId, 'ADMIN', `USER_${status}`, 'USER', targetId, `Set user #${targetId} status to ${status}`);
  broadcastCatalogRefresh();
  res.json({ message: `User status updated to ${status}.` });
});

adminRouter.post('/categories', (req: AuthenticatedRequest, res) => {
  const name = String(req.body?.name || '').trim();
  const desc = String(req.body?.description || '').trim();
  if (name.length < 2) {
    res.status(400).json({ error: 'Category name is required.' });
    return;
  }
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  db.prepare(
    `INSERT OR IGNORE INTO shop_categories (name, slug, description, sort_order) VALUES (?, ?, ?, 99)`
  ).run(name, slug, desc);
  writeAuditLog(req.user!.userId, 'ADMIN', 'CATEGORY_ADDED', 'CATEGORY', name, `Created category ${name}`);
  broadcastCatalogRefresh();
  res.status(201).json({ message: `Category "${name}" added.` });
});

// Parent Orders, Sub-Orders & Manual Admin Rider Assignment/Reassignment
adminRouter.get('/orders', (_req, res) => {
  const parentOrders = (
    db
      .prepare(
        `SELECT po.*, u.name as customer_name, u.email as customer_email
         FROM parent_orders po
         JOIN users u ON u.id = po.customer_id
         ORDER BY po.id DESC LIMIT 60`
      )
      .all() as any[]
  ).map((po) => {
    const subOrders = db
      .prepare(
        `SELECT so.*, s.name as shop_name, s.lat as shop_lat, s.lng as shop_lng,
                ru.name as rider_name, r.vehicle_plate, r.current_lat as rider_lat, r.current_lng as rider_lng, r.last_gps_at
         FROM shop_orders so
         JOIN shops s ON s.id = so.shop_id
         LEFT JOIN riders r ON r.id = so.rider_id
         LEFT JOIN users ru ON ru.id = r.user_id
         WHERE so.parent_order_id = ?
         ORDER BY so.id ASC`
      )
      .all(po.id);
    return { ...po, subOrders };
  });

  const eligibleRiders = db
    .prepare(
      `SELECT r.*, u.name as rider_name, u.phone as rider_phone
       FROM riders r
       JOIN users u ON u.id = r.user_id
       WHERE r.approval_status = 'APPROVED' AND u.status = 'ACTIVE'
       ORDER BY r.is_online DESC, r.active_deliveries ASC`
    )
    .all();

  res.json({ parentOrders, eligibleRiders });
});

adminRouter.post('/suborders/:id/assign-rider', (req: AuthenticatedRequest, res) => {
  try {
    const subId = Number(req.params.id);
    const riderId = Number(req.body?.riderId);

    const sub = db
      .prepare(
        `SELECT so.*, s.lat as shop_lat, s.lng as shop_lng, s.name as shop_name,
                po.delivery_lat, po.delivery_lng, po.customer_id
         FROM shop_orders so
         JOIN shops s ON s.id = so.shop_id
         JOIN parent_orders po ON po.id = so.parent_order_id
         WHERE so.id = ?`
      )
      .get(subId) as any;

    if (!sub) {
      res.status(404).json({ error: 'Sub-order not found.' });
      return;
    }

    const rider = db
      .prepare(
        `SELECT r.*, u.name as rider_name
         FROM riders r
         JOIN users u ON u.id = r.user_id
         WHERE r.id = ? AND r.approval_status = 'APPROVED'`
      )
      .get(riderId) as any;

    if (!rider) {
      res.status(400).json({ error: 'Selected rider is not approved.' });
      return;
    }

    if (rider.active_deliveries >= rider.max_capacity && sub.rider_id !== rider.id) {
      res.status(400).json({
        error: `${rider.rider_name} is already at maximum capacity (${rider.active_deliveries}/${rider.max_capacity}).`,
      });
      return;
    }

    db.transaction(() => {
      if (sub.rider_id && sub.rider_id !== rider.id) {
        db.prepare(`UPDATE riders SET active_deliveries = MAX(0, active_deliveries - 1) WHERE id = ?`).run(
          sub.rider_id
        );
        db.prepare(
          `UPDATE rider_assignments SET status = 'REASSIGNED' WHERE shop_order_id = ? AND rider_id = ?`
        ).run(subId, sub.rider_id);
      }

      if (sub.rider_id !== rider.id) {
        db.prepare(`UPDATE riders SET active_deliveries = active_deliveries + 1 WHERE id = ?`).run(rider.id);
      }

      const dist =
        rider.current_lat && rider.current_lng
          ? haversineKm(rider.current_lat, rider.current_lng, sub.shop_lat, sub.shop_lng)
          : 2.0;
      const earning = computeRiderPayout(dist + 2.5);

      db.prepare(
        `UPDATE shop_orders
         SET dispatch_mode = 'DELIVOO_RIDER', rider_id = ?, delivery_status = 'ASSIGNED', updated_at = datetime('now')
         WHERE id = ?`
      ).run(rider.id, subId);

      db.prepare(
        `INSERT INTO rider_assignments (shop_order_id, rider_id, status, distance_km, earning_amount)
         VALUES (?, ?, 'OFFERED', ?, ?)`
      ).run(subId, rider.id, Number(dist.toFixed(2)), earning);

      db.prepare(
        `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
         VALUES (?, ?, 'ADMIN', 'ADMIN_ASSIGNED_RIDER', ?)`
      ).run(sub.parent_order_id, subId, `Admin assigned rider ${rider.rider_name}.`);
    })();

    writeAuditLog(
      req.user!.userId,
      'ADMIN',
      'ASSIGN_RIDER',
      'SUBORDER',
      sub.sub_order_number,
      `Assigned ${rider.rider_name} to ${sub.sub_order_number}`
    );

    createNotification(
      rider.user_id,
      `Admin Assigned Delivery: ${sub.sub_order_number}`,
      `Pickup from ${sub.shop_name}. Open Rider Dashboard to accept.`,
      'DISPATCH_OFFER',
      sub.sub_order_number
    );
    sendWsToUser(rider.user_id, 'rider:dispatch_offer', { shopOrderId: subId });
    sendWsToUser(sub.customer_id, 'suborder:updated', { shopOrderId: subId });

    res.json({ message: `Assigned ${rider.rider_name} to ${sub.sub_order_number}.` });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Assignment failed.' });
  }
});

// Coupons, Platform Settings, Refunds, Support Tickets & Audit Logs
adminRouter.get('/operations', (_req, res) => {
  const coupons = db.prepare(`SELECT * FROM coupons ORDER BY id DESC`).all();
  const refunds = db
    .prepare(
      `SELECT rf.*, po.order_number, po.payment_method, so.sub_order_number, u.name as customer_name, s.name as shop_name
       FROM refunds rf
       JOIN parent_orders po ON po.id = rf.parent_order_id
       JOIN shop_orders so ON so.id = rf.shop_order_id
       JOIN users u ON u.id = rf.customer_id
       JOIN shops s ON s.id = so.shop_id
       ORDER BY rf.id DESC`
    )
    .all();
  const tickets = db.prepare(`SELECT * FROM support_tickets ORDER BY id DESC LIMIT 60`).all();
  const settingsRows = db.prepare(`SELECT * FROM platform_settings`).all() as {
    key: string;
    value: string;
  }[];
  const settings: Record<string, string> = {};
  for (const r of settingsRows) settings[r.key] = r.value;

  const auditLogs = db.prepare(`SELECT * FROM audit_logs ORDER BY id DESC LIMIT 80`).all();

  res.json({ coupons, refunds, tickets, settings, auditLogs });
});

adminRouter.post('/coupons', (req: AuthenticatedRequest, res) => {
  const {
    code,
    discountType = 'PERCENTAGE',
    discountValue,
    minOrderAmount = 500,
    maxDiscount,
    usageLimit = 200,
    eligibleCategory = '',
    expiresAt = '2028-12-31T23:59:59Z',
  } = req.body || {};

  const cleanCode = String(code || '').toUpperCase().trim();
  const val = Number(discountValue);
  if (cleanCode.length < 3 || Number.isNaN(val) || val <= 0) {
    res.status(400).json({ error: 'Valid coupon code and positive discount value are required.' });
    return;
  }

  db.prepare(
    `INSERT INTO coupons (code, discount_type, discount_value, min_order_amount, max_discount, usage_limit, eligible_category, expires_at, is_active)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)`
  ).run(
    cleanCode,
    discountType === 'FIXED' ? 'FIXED' : 'PERCENTAGE',
    val,
    Math.max(0, Number(minOrderAmount || 0)),
    maxDiscount ? Number(maxDiscount) : null,
    Math.max(1, Number(usageLimit || 100)),
    String(eligibleCategory || '').trim(),
    String(expiresAt)
  );

  writeAuditLog(req.user!.userId, 'ADMIN', 'COUPON_CREATED', 'COUPON', cleanCode, `Created coupon ${cleanCode}`);
  broadcastCatalogRefresh();
  res.status(201).json({ message: `Coupon ${cleanCode} created.` });
});

adminRouter.post('/coupons/:id/toggle', (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  db.prepare(`UPDATE coupons SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = ?`).run(id);
  broadcastCatalogRefresh();
  res.json({ message: 'Coupon status toggled.' });
});

adminRouter.post('/refunds/:id/resolve', (req: AuthenticatedRequest, res) => {
  const refundId = Number(req.params.id);
  const { status, adminNote = '' } = req.body || {}; // APPROVED | REJECTED

  if (!['APPROVED', 'REJECTED'].includes(status)) {
    res.status(400).json({ error: 'Status must be APPROVED or REJECTED.' });
    return;
  }

  const rf = db
    .prepare(
      `SELECT rf.*, so.sub_order_number, po.total_amount
       FROM refunds rf
       JOIN shop_orders so ON so.id = rf.shop_order_id
       JOIN parent_orders po ON po.id = rf.parent_order_id
       WHERE rf.id = ?`
    )
    .get(refundId) as any;

  if (!rf) {
    res.status(404).json({ error: 'Refund record not found.' });
    return;
  }

  db.transaction(() => {
    db.prepare(
      `UPDATE refunds SET status = ?, admin_note = ?, resolved_at = datetime('now') WHERE id = ?`
    ).run(status, String(adminNote).trim(), refundId);

    db.prepare(`UPDATE shop_orders SET refund_status = ? WHERE id = ?`).run(status, rf.shop_order_id);

    if (status === 'APPROVED') {
      const totalApproved = (
        db
          .prepare(
            `SELECT COALESCE(SUM(amount), 0) as s FROM refunds WHERE parent_order_id = ? AND status = 'APPROVED'`
          )
          .get(rf.parent_order_id) as { s: number }
      ).s;
      const pStatus = totalApproved >= Number(rf.total_amount) ? 'REFUNDED' : 'PARTIALLY_REFUNDED';
      db.prepare(`UPDATE parent_orders SET payment_status = ? WHERE id = ?`).run(pStatus, rf.parent_order_id);
      db.prepare(`UPDATE payments SET status = ? WHERE parent_order_id = ?`).run(pStatus, rf.parent_order_id);
    }

    recalculateParentOrderStatus(rf.parent_order_id);
  })();

  writeAuditLog(
    req.user!.userId,
    'ADMIN',
    `REFUND_${status}`,
    'REFUND',
    refundId,
    `${status} refund of PKR ${rf.amount} for ${rf.sub_order_number}`
  );

  createNotification(
    rf.customer_id,
    `Refund ${status} (${rf.sub_order_number})`,
    `Your refund request of PKR ${rf.amount} was ${status}.${adminNote ? ` Note: ${adminNote}` : ''}`,
    'REFUND_UPDATE',
    rf.sub_order_number
  );
  sendWsToUser(rf.customer_id, 'order:updated', { parentOrderId: rf.parent_order_id });

  res.json({ message: `Refund marked as ${status}.` });
});

adminRouter.put('/settings', (req: AuthenticatedRequest, res) => {
  const updates = req.body || {};
  const upsert = db.prepare(
    `INSERT INTO platform_settings (key, value, updated_at)
     VALUES (?, ?, datetime('now'))
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`
  );

  db.transaction(() => {
    for (const [k, v] of Object.entries(updates)) {
      if (typeof v === 'string' || typeof v === 'number') {
        upsert.run(k, String(v));
      }
    }
  })();

  writeAuditLog(req.user!.userId, 'ADMIN', 'SETTINGS_UPDATED', 'SETTINGS', 'GLOBAL', JSON.stringify(updates));
  res.json({ message: 'Platform configuration saved.' });
});

adminRouter.post('/tickets/:id/reply', (req: AuthenticatedRequest, res) => {
  const ticketId = Number(req.params.id);
  const { reply, status = 'RESOLVED' } = req.body || {};

  const ticket = db.prepare(`SELECT * FROM support_tickets WHERE id = ?`).get(ticketId) as any;
  if (!ticket) {
    res.status(404).json({ error: 'Support ticket not found.' });
    return;
  }

  db.prepare(`UPDATE support_tickets SET admin_reply = ?, status = ? WHERE id = ?`).run(
    String(reply || '').trim(),
    status,
    ticketId
  );

  if (ticket.user_id) {
    createNotification(
      ticket.user_id,
      `Support Reply: ${ticket.subject}`,
      String(reply || '').trim(),
      'SUPPORT_REPLY',
      String(ticketId)
    );
  }

  res.json({ message: 'Support response sent.' });
});
