import crypto from 'crypto';
import { Router } from 'express';
import {
  evaluateProductAvailability,
  getKarachiClock,
  haversineKm,
  isShopCurrentlyOpen,
  recalculateParentOrderStatus,
} from '../availability.ts';
import { db } from '../db.ts';
import { createNotification, notifyAllAdmins, sendWsToRole, sendWsToUser } from '../realtime.ts';
import {
  computePaymentSignature,
  requireAuth,
  requireRole,
  type AuthenticatedRequest,
} from '../security.ts';

export const marketplaceRouter = Router();

interface CartItemInput {
  productId: number;
  variantId?: number | null;
  quantity: number;
}

function validateAndComputeCart(items: CartItemInput[], couponCode?: string) {
  if (!Array.isArray(items) || items.length === 0) {
    throw new Error('Your cart is empty.');
  }

  const shopGroups = new Map<
    number,
    {
      shop: {
        id: number;
        owner_id: number;
        name: string;
        category_name: string;
        delivery_fee: number;
        prep_time_mins: number;
        commission_rate: number;
        opening_time: string;
        closing_time: string;
        is_open_override: string;
        approval_status: string;
      };
      items: {
        productId: number;
        variantId: number | null;
        productName: string;
        variantName: string;
        unitPrice: number;
        quantity: number;
        lineTotal: number;
        availableStock: number;
      }[];
      subtotal: number;
    }
  >();

  for (const raw of items) {
    const qty = Math.floor(Number(raw.quantity || 0));
    if (qty <= 0) continue;

    const prod = db
      .prepare(
        `SELECT p.*, s.owner_id, s.name as shop_name, s.category_name as shop_cat, s.delivery_fee,
                s.prep_time_mins, s.commission_rate, s.opening_time, s.closing_time,
                s.is_open_override, s.approval_status, u.status as owner_status
         FROM products p
         JOIN shops s ON s.id = p.shop_id
         JOIN users u ON u.id = s.owner_id
         WHERE p.id = ?`
      )
      .get(Number(raw.productId)) as any;

    if (!prod || prod.approval_status !== 'APPROVED' || prod.owner_status !== 'ACTIVE') {
      throw new Error(`Product #${raw.productId} belongs to an unapproved or unavailable shop.`);
    }

    const shopOpen = isShopCurrentlyOpen(prod);
    const avail = evaluateProductAvailability(prod, shopOpen);
    if (!avail.available) {
      throw new Error(`"${prod.name}" from ${prod.shop_name} is currently unavailable (${avail.reason}).`);
    }

    let unitPrice = avail.effectivePrice;
    let variantName = '';
    let variantId: number | null = null;
    let availableStock = Number(prod.stock_quantity);

    if (raw.variantId) {
      const variant = db
        .prepare(`SELECT * FROM product_variants WHERE id = ? AND product_id = ?`)
        .get(Number(raw.variantId), prod.id) as
        | { id: number; name: string; price_delta: number; stock_quantity: number }
        | undefined;
      if (!variant) {
        throw new Error(`Selected variant for "${prod.name}" does not exist.`);
      }
      variantId = variant.id;
      variantName = variant.name;
      unitPrice = Math.max(0, unitPrice + Number(variant.price_delta || 0));
      availableStock = Math.min(availableStock, Number(variant.stock_quantity));
    }

    if (qty > availableStock) {
      throw new Error(
        `Insufficient stock for "${prod.name}"${variantName ? ` (${variantName})` : ''}. Available: ${availableStock}.`
      );
    }

    let group = shopGroups.get(prod.shop_id);
    if (!group) {
      group = {
        shop: {
          id: prod.shop_id,
          owner_id: prod.owner_id,
          name: prod.shop_name,
          category_name: prod.shop_cat,
          delivery_fee: Number(prod.delivery_fee),
          prep_time_mins: Number(prod.prep_time_mins),
          commission_rate: Number(prod.commission_rate || 12),
          opening_time: prod.opening_time,
          closing_time: prod.closing_time,
          is_open_override: prod.is_open_override,
          approval_status: prod.approval_status,
        },
        items: [],
        subtotal: 0,
      };
      shopGroups.set(prod.shop_id, group);
    }

    const lineTotal = Math.round(unitPrice * qty);
    group.items.push({
      productId: prod.id,
      variantId,
      productName: prod.name,
      variantName,
      unitPrice,
      quantity: qty,
      lineTotal,
      availableStock,
    });
    group.subtotal += lineTotal;
  }

  if (shopGroups.size === 0) {
    throw new Error('No valid items in cart.');
  }

  const groupsArray = Array.from(shopGroups.values());
  const subtotalAmount = groupsArray.reduce((sum, g) => sum + g.subtotal, 0);
  const deliveryTotal = groupsArray.reduce((sum, g) => sum + g.shop.delivery_fee, 0);

  const taxSetting = db
    .prepare(`SELECT value FROM platform_settings WHERE key = 'tax_rate_percent'`)
    .get() as { value: string } | undefined;
  const taxRate = Number(taxSetting?.value ?? 5);
  const taxAmount = Math.round((subtotalAmount * taxRate) / 100);

  // Coupon validation
  let discountAmount = 0;
  let appliedCoupon: { code: string; description: string } | null = null;
  const cleanCoupon = String(couponCode || '').toUpperCase().trim();

  if (cleanCoupon) {
    const coupon = db
      .prepare(`SELECT * FROM coupons WHERE code = ? AND is_active = 1`)
      .get(cleanCoupon) as any;

    if (!coupon) {
      throw new Error(`Coupon "${cleanCoupon}" is invalid or inactive.`);
    }
    if (new Date(coupon.expires_at).getTime() < Date.now()) {
      throw new Error(`Coupon "${cleanCoupon}" has expired.`);
    }
    if (coupon.used_count >= coupon.usage_limit) {
      throw new Error(`Coupon "${cleanCoupon}" has reached its usage limit.`);
    }

    let eligibleSubtotal = subtotalAmount;
    if (coupon.shop_id) {
      const targetGroup = groupsArray.find((g) => g.shop.id === coupon.shop_id);
      eligibleSubtotal = targetGroup ? targetGroup.subtotal : 0;
    } else if (coupon.eligible_category) {
      eligibleSubtotal = groupsArray
        .filter((g) => g.shop.category_name.toLowerCase() === String(coupon.eligible_category).toLowerCase())
        .reduce((s, g) => s + g.subtotal, 0);
    }

    if (eligibleSubtotal <= 0) {
      throw new Error(`Coupon "${cleanCoupon}" does not apply to the shops/categories in your cart.`);
    }
    if (subtotalAmount < Number(coupon.min_order_amount)) {
      throw new Error(
        `Coupon "${cleanCoupon}" requires a minimum subtotal of PKR ${coupon.min_order_amount}.`
      );
    }

    if (coupon.discount_type === 'PERCENTAGE') {
      discountAmount = Math.round((eligibleSubtotal * Number(coupon.discount_value)) / 100);
      if (coupon.max_discount) {
        discountAmount = Math.min(discountAmount, Number(coupon.max_discount));
      }
    } else {
      discountAmount = Math.min(eligibleSubtotal, Math.round(Number(coupon.discount_value)));
    }

    appliedCoupon = {
      code: cleanCoupon,
      description:
        coupon.discount_type === 'PERCENTAGE'
          ? `${coupon.discount_value}% off`
          : `PKR ${coupon.discount_value} off`,
    };
  }

  const totalAmount = Math.max(0, subtotalAmount + deliveryTotal + taxAmount - discountAmount);

  return {
    groups: groupsArray,
    subtotalAmount,
    deliveryTotal,
    taxRate,
    taxAmount,
    discountAmount,
    totalAmount,
    appliedCoupon,
  };
}

// Public Marketplace Discovery (ONLY APPROVED & ACTIVE shops!)
marketplaceRouter.get('/catalog', (req, res) => {
  const lat = req.query.lat ? Number(req.query.lat) : null;
  const lng = req.query.lng ? Number(req.query.lng) : null;
  const clock = getKarachiClock();

  const categories = db
    .prepare(`SELECT * FROM shop_categories WHERE is_active = 1 ORDER BY sort_order ASC`)
    .all();

  const rawShops = db
    .prepare(
      `SELECT s.*
       FROM shops s
       JOIN users u ON u.id = s.owner_id
       WHERE s.approval_status = 'APPROVED' AND u.status = 'ACTIVE'
       ORDER BY s.rating_avg DESC, s.id ASC`
    )
    .all() as any[];

  const shops = rawShops.map((s) => {
    const isOpen = isShopCurrentlyOpen(s);
    const distanceKm =
      lat !== null && lng !== null && !Number.isNaN(lat) && !Number.isNaN(lng)
        ? Number(haversineKm(lat, lng, s.lat, s.lng).toFixed(1))
        : null;
    const estMinutes = s.prep_time_mins + (distanceKm !== null ? Math.round(distanceKm * 4 + 8) : 15);
    return {
      ...s,
      isOpen,
      distanceKm,
      estimatedDeliveryMins: estMinutes,
    };
  });

  const shopMap = new Map(shops.map((s) => [s.id, s]));

  const rawProducts = db
    .prepare(
      `SELECT p.*
       FROM products p
       JOIN shops s ON s.id = p.shop_id
       JOIN users u ON u.id = s.owner_id
       WHERE p.is_active = 1 AND s.approval_status = 'APPROVED' AND u.status = 'ACTIVE'
       ORDER BY p.id DESC`
    )
    .all() as any[];

  const allVariants = db.prepare(`SELECT * FROM product_variants`).all() as any[];
  const variantsByProd = new Map<number, any[]>();
  for (const v of allVariants) {
    const arr = variantsByProd.get(v.product_id) || [];
    arr.push(v);
    variantsByProd.set(v.product_id, arr);
  }

  const products = rawProducts.map((p) => {
    const shop = shopMap.get(p.shop_id);
    const avail = evaluateProductAvailability(p, Boolean(shop?.isOpen));
    return {
      ...p,
      shopName: shop?.name || '',
      shopDeliveryFee: shop?.delivery_fee ?? 120,
      shopIsOpen: Boolean(shop?.isOpen),
      available: avail.available,
      availabilityReason: avail.reason,
      effectivePrice: avail.effectivePrice,
      activeScheduleLabel: avail.activeScheduleLabel,
      variants: variantsByProd.get(p.id) || [],
    };
  });

  const coupons = db
    .prepare(
      `SELECT code, discount_type, discount_value, min_order_amount, max_discount, eligible_category, expires_at
       FROM coupons
       WHERE is_active = 1 AND used_count < usage_limit`
    )
    .all();

  res.json({
    karachiClock: clock,
    categories,
    shops,
    products,
    coupons,
  });
});

marketplaceRouter.get('/products/:id', (req, res) => {
  const prod = db
    .prepare(
      `SELECT p.*, s.name as shop_name, s.opening_time, s.closing_time, s.is_open_override, s.approval_status
       FROM products p
       JOIN shops s ON s.id = p.shop_id
       WHERE p.id = ? AND s.approval_status = 'APPROVED'`
    )
    .get(Number(req.params.id)) as any;

  if (!prod) {
    res.status(404).json({ error: 'Product not found.' });
    return;
  }

  const shopOpen = isShopCurrentlyOpen(prod);
  const avail = evaluateProductAvailability(prod, shopOpen);
  const variants = db.prepare(`SELECT * FROM product_variants WHERE product_id = ?`).all(prod.id);
  const reviews = db
    .prepare(
      `SELECT r.*, u.name as customer_name
       FROM reviews r
       JOIN users u ON u.id = r.customer_id
       WHERE r.product_id = ? AND r.target_type = 'PRODUCT'
       ORDER BY r.id DESC LIMIT 20`
    )
    .all(prod.id);

  res.json({
    ...prod,
    available: avail.available,
    availabilityReason: avail.reason,
    effectivePrice: avail.effectivePrice,
    activeScheduleLabel: avail.activeScheduleLabel,
    variants,
    reviews,
  });
});

marketplaceRouter.post('/validate-cart', (req, res) => {
  try {
    const summary = validateAndComputeCart(req.body?.items || [], req.body?.couponCode);
    res.json(summary);
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'Cart validation failed.' });
  }
});

// Atomic Multi-Shop Parent-Order & Sub-Order Checkout (Sections 8, 9, 16)
marketplaceRouter.post(
  '/checkout',
  requireAuth,
  requireRole('CUSTOMER'),
  (req: AuthenticatedRequest, res) => {
    try {
      const {
        items,
        couponCode,
        deliveryAddress,
        deliveryCity = 'Lahore',
        deliveryLat,
        deliveryLng,
        contactPhone,
        deliveryInstructions = '',
        paymentMethod = 'COD',
        idempotencyKey,
      } = req.body || {};

      if (!deliveryAddress || String(deliveryAddress).trim().length < 5) {
        res.status(400).json({ error: 'Please provide a complete delivery street address.' });
        return;
      }
      if (!contactPhone || String(contactPhone).trim().length < 10) {
        res.status(400).json({ error: 'Please provide a valid contact phone number.' });
        return;
      }
      if (!['COD', 'EASYPAISA', 'JAZZCASH', 'CARD'].includes(paymentMethod)) {
        res.status(400).json({ error: 'Unsupported payment method.' });
        return;
      }

      const customerId = req.user!.userId;

      if (idempotencyKey) {
        const dup = db
          .prepare(`SELECT id, order_number FROM parent_orders WHERE idempotency_key = ?`)
          .get(String(idempotencyKey)) as { id: number; order_number: string } | undefined;
        if (dup) {
          res.json({ duplicatePrevented: true, parentOrderId: dup.id, orderNumber: dup.order_number });
          return;
        }
      }

      const checkoutTx = db.transaction(() => {
        const summary = validateAndComputeCart(items, couponCode);

        // Generate Parent Order Number DEL-1001, DEL-1002...
        const lastRow = db.prepare(`SELECT MAX(id) as maxId FROM parent_orders`).get() as {
          maxId: number | null;
        };
        const seq = 1001 + (lastRow?.maxId || 0);
        const orderNumber = `DEL-${seq}`;

        const initialPaymentStatus = paymentMethod === 'COD' ? 'PENDING' : 'PENDING_VERIFICATION';

        const parentInsert = db
          .prepare(
            `INSERT INTO parent_orders (
               order_number, customer_id, subtotal_amount, delivery_total, tax_amount,
               discount_amount, total_amount, coupon_code, payment_method, payment_status,
               overall_status, delivery_address, delivery_city, delivery_lat, delivery_lng,
               contact_phone, delivery_instructions, idempotency_key
             ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PLACED', ?, ?, ?, ?, ?, ?, ?)`
          )
          .run(
            orderNumber,
            customerId,
            summary.subtotalAmount,
            summary.deliveryTotal,
            summary.taxAmount,
            summary.discountAmount,
            summary.totalAmount,
            summary.appliedCoupon?.code || '',
            paymentMethod,
            initialPaymentStatus,
            String(deliveryAddress).trim(),
            String(deliveryCity).trim(),
            typeof deliveryLat === 'number' ? deliveryLat : null,
            typeof deliveryLng === 'number' ? deliveryLng : null,
            String(contactPhone).trim(),
            String(deliveryInstructions).trim(),
            idempotencyKey ? String(idempotencyKey) : null
          );

        const parentOrderId = Number(parentInsert.lastInsertRowid);

        if (summary.appliedCoupon) {
          db.prepare(
            `UPDATE coupons SET used_count = used_count + 1 WHERE code = ? AND used_count < usage_limit`
          ).run(summary.appliedCoupon.code);
        }

        const createdSubOrders: {
          id: number;
          subOrderNumber: string;
          shopId: number;
          ownerId: number;
          shopName: string;
        }[] = [];

        // Create independent Shop-Wise Sub-Orders: DEL-1001-A, DEL-1001-B, DEL-1001-C...
        summary.groups.forEach((group, idx) => {
          const suffix = String.fromCharCode(65 + idx);
          const subOrderNumber = `${orderNumber}-${suffix}`;
          const discountShare =
            summary.subtotalAmount > 0
              ? Math.round((group.subtotal / summary.subtotalAmount) * summary.discountAmount)
              : 0;
          const commissionAmount = Math.round((group.subtotal * group.shop.commission_rate) / 100);
          const payableAmount = Math.max(0, group.subtotal + group.shop.delivery_fee - discountShare);

          const subRes = db
            .prepare(
              `INSERT INTO shop_orders (
                 parent_order_id, sub_order_number, shop_id, subtotal, delivery_fee,
                 commission_amount, allocated_discount, payable_amount, prep_time_mins,
                 shop_status, dispatch_mode, delivery_status
               ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING_SHOP', 'UNASSIGNED', 'UNASSIGNED')`
            )
            .run(
              parentOrderId,
              subOrderNumber,
              group.shop.id,
              group.subtotal,
              group.shop.delivery_fee,
              commissionAmount,
              discountShare,
              payableAmount,
              group.shop.prep_time_mins
            );

          const shopOrderId = Number(subRes.lastInsertRowid);

          db.prepare(
            `INSERT INTO commissions (shop_order_id, shop_id, gross_amount, commission_rate, commission_amount, net_merchant_amount)
             VALUES (?, ?, ?, ?, ?, ?)`
          ).run(
            shopOrderId,
            group.shop.id,
            group.subtotal,
            group.shop.commission_rate,
            commissionAmount,
            Math.max(0, group.subtotal - commissionAmount)
          );

          for (const item of group.items) {
            // Safe atomic stock deduction
            const upd = db
              .prepare(
                `UPDATE products
                 SET stock_quantity = stock_quantity - ?
                 WHERE id = ? AND stock_quantity >= ?`
              )
              .run(item.quantity, item.productId, item.quantity);

            if (upd.changes === 0) {
              throw new Error(`Concurrent stock conflict for "${item.productName}". Please retry.`);
            }

            if (item.variantId) {
              const vUpd = db
                .prepare(
                  `UPDATE product_variants
                   SET stock_quantity = stock_quantity - ?
                   WHERE id = ? AND stock_quantity >= ?`
                )
                .run(item.quantity, item.variantId, item.quantity);
              if (vUpd.changes === 0) {
                throw new Error(`Selected variant for "${item.productName}" just sold out.`);
              }
            }

            const newProdRow = db
              .prepare(`SELECT stock_quantity, low_stock_threshold FROM products WHERE id = ?`)
              .get(item.productId) as { stock_quantity: number; low_stock_threshold: number };

            db.prepare(
              `INSERT INTO inventory (product_id, shop_id, change_amount, new_quantity, reason, actor_id)
               VALUES (?, ?, ?, ?, ?, ?)`
            ).run(
              item.productId,
              group.shop.id,
              -item.quantity,
              newProdRow.stock_quantity,
              `Order ${subOrderNumber}`,
              customerId
            );

            db.prepare(
              `INSERT INTO order_items (
                 shop_order_id, product_id, variant_id, product_name, variant_name,
                 unit_price, quantity, line_total
               ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
            ).run(
              shopOrderId,
              item.productId,
              item.variantId,
              item.productName,
              item.variantName,
              item.unitPrice,
              item.quantity,
              item.lineTotal
            );

            if (newProdRow.stock_quantity <= newProdRow.low_stock_threshold) {
              createNotification(
                group.shop.owner_id,
                `Low Stock Alert: ${item.productName}`,
                `Remaining stock is ${newProdRow.stock_quantity} units after order ${subOrderNumber}.`,
                'STOCK_ALERT',
                String(item.productId)
              );
            }
          }

          db.prepare(
            `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
             VALUES (?, ?, 'CUSTOMER', 'SUBORDER_CREATED', ?)`
          ).run(
            parentOrderId,
            shopOrderId,
            `Sub-order ${subOrderNumber} created for ${group.shop.name}.`
          );

          createdSubOrders.push({
            id: shopOrderId,
            subOrderNumber,
            shopId: group.shop.id,
            ownerId: group.shop.owner_id,
            shopName: group.shop.name,
          });
        });

        const txRef = `TXN-${orderNumber}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
        db.prepare(
          `INSERT INTO payments (parent_order_id, method, amount, status, transaction_ref, webhook_verified)
           VALUES (?, ?, ?, ?, ?, 0)`
        ).run(parentOrderId, paymentMethod, summary.totalAmount, initialPaymentStatus, txRef);

        return {
          parentOrderId,
          orderNumber,
          totalAmount: summary.totalAmount,
          paymentMethod,
          paymentStatus: initialPaymentStatus,
          transactionRef: txRef,
          createdSubOrders,
        };
      });

      const out = checkoutTx.immediate();

      // Notify Customer, Shopkeepers, and Admin
      createNotification(
        customerId,
        `Order Placed: ${out.orderNumber}`,
        `Split into ${out.createdSubOrders.length} shop sub-order(s): ${out.createdSubOrders
          .map((s) => s.subOrderNumber)
          .join(', ')}.`,
        'ORDER_CREATED',
        out.orderNumber
      );

      for (const s of out.createdSubOrders) {
        createNotification(
          s.ownerId,
          `New Sub-Order: ${s.subOrderNumber}`,
          `A customer placed an order with ${s.shopName}. Review and accept to start preparation.`,
          'NEW_SHOP_ORDER',
          s.subOrderNumber
        );
        sendWsToUser(s.ownerId, 'suborder:created', { subOrderNumber: s.subOrderNumber });
      }

      sendWsToRole('ADMIN', 'order:created', { orderNumber: out.orderNumber });

      res.status(201).json(out);
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Checkout failed.' });
    }
  }
);

// Backend-verified payment webhook (never trusts frontend-only confirmation!)
marketplaceRouter.post('/payments/webhook', (req, res) => {
  const { transactionRef, amount, status, signature } = req.body || {};
  const payment = db
    .prepare(`SELECT * FROM payments WHERE transaction_ref = ?`)
    .get(String(transactionRef || '')) as any;

  if (!payment) {
    res.status(404).json({ error: 'Payment transaction reference not found.' });
    return;
  }

  const expectedSig = computePaymentSignature(
    payment.transaction_ref,
    Number(payment.amount),
    String(status)
  );

  if (signature !== expectedSig || Math.abs(Number(amount) - Number(payment.amount)) > 0.01) {
    res.status(401).json({ error: 'Invalid payment webhook HMAC signature or amount mismatch.' });
    return;
  }

  const finalStatus = status === 'SUCCESS' ? 'PAID' : 'FAILED';
  db.transaction(() => {
    db.prepare(
      `UPDATE payments
       SET status = ?, webhook_verified = 1, verified_at = datetime('now')
       WHERE id = ?`
    ).run(finalStatus, payment.id);

    db.prepare(`UPDATE parent_orders SET payment_status = ? WHERE id = ?`).run(
      finalStatus,
      payment.parent_order_id
    );

    db.prepare(
      `INSERT INTO order_events (parent_order_id, actor_role, event_type, description)
       VALUES (?, 'PAYMENT_WEBHOOK', 'PAYMENT_VERIFIED', ?)`
    ).run(
      payment.parent_order_id,
      `Backend HMAC webhook verified ${payment.method} payment (${payment.transaction_ref}): ${finalStatus}.`
    );
  })();

  const parent = db
    .prepare(`SELECT customer_id, order_number FROM parent_orders WHERE id = ?`)
    .get(payment.parent_order_id) as { customer_id: number; order_number: string };

  createNotification(
    parent.customer_id,
    `Payment ${finalStatus === 'PAID' ? 'Verified' : 'Failed'}: ${parent.order_number}`,
    `Transaction ${payment.transaction_ref} (${payment.method}) verified as ${finalStatus}.`,
    'PAYMENT_UPDATE',
    parent.order_number
  );
  sendWsToUser(parent.customer_id, 'order:updated', { parentOrderId: payment.parent_order_id });

  res.json({ verified: true, paymentStatus: finalStatus });
});

// Server-side sandbox gateway authorization endpoint (signs & dispatches verified webhook internally)
marketplaceRouter.post(
  '/payments/authorize-online',
  requireAuth,
  requireRole('CUSTOMER'),
  (req: AuthenticatedRequest, res) => {
    const { transactionRef, walletAccount } = req.body || {};
    if (!walletAccount || String(walletAccount).trim().length < 8) {
      res.status(400).json({ error: 'Enter a valid mobile wallet / card account number to authorize.' });
      return;
    }

    const payment = db
      .prepare(
        `SELECT p.*, po.customer_id, po.order_number
         FROM payments p
         JOIN parent_orders po ON po.id = p.parent_order_id
         WHERE p.transaction_ref = ?`
      )
      .get(String(transactionRef || '')) as any;

    if (!payment || payment.customer_id !== req.user!.userId) {
      res.status(404).json({ error: 'Authorized payment intent not found.' });
      return;
    }

    // Generate genuine server-side HMAC signature and verify transaction atomically
    const sig = computePaymentSignature(payment.transaction_ref, Number(payment.amount), 'SUCCESS');
    const expected = computePaymentSignature(payment.transaction_ref, Number(payment.amount), 'SUCCESS');
    if (sig !== expected) {
      res.status(500).json({ error: 'Signature verification failed.' });
      return;
    }

    db.transaction(() => {
      db.prepare(
        `UPDATE payments SET status = 'PAID', webhook_verified = 1, verified_at = datetime('now') WHERE id = ?`
      ).run(payment.id);
      db.prepare(`UPDATE parent_orders SET payment_status = 'PAID' WHERE id = ?`).run(
        payment.parent_order_id
      );
      db.prepare(
        `INSERT INTO order_events (parent_order_id, actor_role, event_type, description)
         VALUES (?, 'PAYMENT_GATEWAY', 'PAYMENT_VERIFIED', ?)`
      ).run(
        payment.parent_order_id,
        `Verified ${payment.method} payment of PKR ${payment.amount} (${payment.transaction_ref}).`
      );
    })();

    createNotification(
      req.user!.userId,
      `Payment Confirmed (${payment.order_number})`,
      `PKR ${payment.amount} paid via ${payment.method} (${payment.transaction_ref}).`,
      'PAYMENT_UPDATE',
      payment.order_number
    );

    res.json({ verified: true, paymentStatus: 'PAID', transactionRef: payment.transaction_ref });
  }
);

// Customer Orders with Independent Sub-Orders, Live Rider Coordinates & Events
marketplaceRouter.get('/orders', requireAuth, requireRole('CUSTOMER'), (req: AuthenticatedRequest, res) => {
  const parents = db
    .prepare(`SELECT * FROM parent_orders WHERE customer_id = ? ORDER BY id DESC`)
    .all(req.user!.userId) as any[];

  const enriched = parents.map((po) => {
    const subOrders = db
      .prepare(
        `SELECT so.*, s.name as shop_name, s.address as shop_address, s.lat as shop_lat, s.lng as shop_lng,
                r.vehicle_type, r.vehicle_plate, r.current_lat as rider_lat, r.current_lng as rider_lng,
                r.last_gps_at as rider_last_gps_at, ru.name as rider_name, ru.phone as rider_phone
         FROM shop_orders so
         JOIN shops s ON s.id = so.shop_id
         LEFT JOIN riders r ON r.id = so.rider_id
         LEFT JOIN users ru ON ru.id = r.user_id
         WHERE so.parent_order_id = ?
         ORDER BY so.id ASC`
      )
      .all(po.id) as any[];

    const subWithDetails = subOrders.map((so) => {
      const items = db.prepare(`SELECT * FROM order_items WHERE shop_order_id = ?`).all(so.id);
      const events = db
        .prepare(`SELECT * FROM order_events WHERE shop_order_id = ? ORDER BY id ASC`)
        .all(so.id);
      const refund = db.prepare(`SELECT * FROM refunds WHERE shop_order_id = ? ORDER BY id DESC LIMIT 1`).get(so.id);
      const existingReviews = db
        .prepare(`SELECT target_type, product_id, rating FROM reviews WHERE shop_order_id = ? AND customer_id = ?`)
        .all(so.id, req.user!.userId);

      // Compute honest real distance & ETA if rider GPS and destination exist
      let liveEtaMins: number | null = null;
      let remainingKm: number | null = null;
      if (
        so.rider_lat !== null &&
        so.rider_lng !== null &&
        po.delivery_lat !== null &&
        po.delivery_lng !== null &&
        !['DELIVERED', 'CANCELLED'].includes(so.delivery_status)
      ) {
        remainingKm = Number(haversineKm(so.rider_lat, so.rider_lng, po.delivery_lat, po.delivery_lng).toFixed(2));
        liveEtaMins = Math.max(2, Math.round(remainingKm * 3.5 + 3));
      }

      return {
        ...so,
        items,
        events,
        refund: refund || null,
        existingReviews,
        remainingKm,
        liveEtaMins,
      };
    });

    return {
      ...po,
      subOrders: subWithDetails,
    };
  });

  res.json({ orders: enriched });
});

// Independent Shop-Wise Sub-Order Cancellation by Customer
marketplaceRouter.post(
  '/suborders/:id/cancel',
  requireAuth,
  requireRole('CUSTOMER'),
  (req: AuthenticatedRequest, res) => {
    const subId = Number(req.params.id);
    const reason = String(req.body?.reason || 'Cancelled by customer').trim();

    const sub = db
      .prepare(
        `SELECT so.*, po.customer_id, po.payment_status, po.order_number, s.owner_id, s.name as shop_name
         FROM shop_orders so
         JOIN parent_orders po ON po.id = so.parent_order_id
         JOIN shops s ON s.id = so.shop_id
         WHERE so.id = ?`
      )
      .get(subId) as any;

    if (!sub || sub.customer_id !== req.user!.userId) {
      res.status(404).json({ error: 'Sub-order not found.' });
      return;
    }

    if (['PICKED_UP', 'ON_THE_WAY', 'ARRIVED_AT_CUSTOMER', 'DELIVERED', 'CANCELLED'].includes(sub.delivery_status)) {
      res.status(400).json({ error: 'Cannot cancel sub-order once picked up or already finalized.' });
      return;
    }
    if (['CANCELLED', 'REJECTED'].includes(sub.shop_status)) {
      res.status(400).json({ error: 'This sub-order is already cancelled.' });
      return;
    }

    db.transaction(() => {
      db.prepare(
        `UPDATE shop_orders
         SET shop_status = 'CANCELLED', delivery_status = 'CANCELLED', updated_at = datetime('now')
         WHERE id = ?`
      ).run(subId);

      // Restore stock safely
      const items = db.prepare(`SELECT * FROM order_items WHERE shop_order_id = ?`).all(subId) as any[];
      for (const it of items) {
        db.prepare(`UPDATE products SET stock_quantity = stock_quantity + ? WHERE id = ?`).run(
          it.quantity,
          it.product_id
        );
        if (it.variant_id) {
          db.prepare(`UPDATE product_variants SET stock_quantity = stock_quantity + ? WHERE id = ?`).run(
            it.quantity,
            it.variant_id
          );
        }
      }

      if (sub.rider_id) {
        db.prepare(
          `UPDATE riders SET active_deliveries = MAX(0, active_deliveries - 1) WHERE id = ?`
        ).run(sub.rider_id);
      }

      // If parent order was already PAID online, create automatic partial refund request
      if (sub.payment_status === 'PAID') {
        db.prepare(
          `INSERT INTO refunds (parent_order_id, shop_order_id, customer_id, amount, reason, status)
           VALUES (?, ?, ?, ?, ?, 'REQUESTED')`
        ).run(sub.parent_order_id, subId, req.user!.userId, sub.payable_amount, `Sub-order cancelled: ${reason}`);
        db.prepare(`UPDATE shop_orders SET refund_status = 'REQUESTED' WHERE id = ?`).run(subId);
      }

      db.prepare(
        `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
         VALUES (?, ?, 'CUSTOMER', 'SUBORDER_CANCELLED', ?)`
      ).run(sub.parent_order_id, subId, `Customer cancelled ${sub.sub_order_number}: ${reason}`);

      recalculateParentOrderStatus(sub.parent_order_id);
    })();

    createNotification(
      sub.owner_id,
      `Sub-Order Cancelled: ${sub.sub_order_number}`,
      `Customer cancelled sub-order ${sub.sub_order_number}. Other shop sub-orders remain unaffected.`,
      'ORDER_CANCELLED',
      sub.sub_order_number
    );
    sendWsToUser(sub.owner_id, 'suborder:updated', { shopOrderId: subId });
    sendWsToRole('ADMIN', 'suborder:updated', { shopOrderId: subId });

    res.json({ message: `Sub-order ${sub.sub_order_number} cancelled independently.` });
  }
);

// Customer Refund Request for a Specific Shop Sub-Order
marketplaceRouter.post(
  '/suborders/:id/refund',
  requireAuth,
  requireRole('CUSTOMER'),
  (req: AuthenticatedRequest, res) => {
    const subId = Number(req.params.id);
    const { reason, requestedAmount } = req.body || {};

    if (!reason || String(reason).trim().length < 5) {
      res.status(400).json({ error: 'Please describe the reason for your refund request.' });
      return;
    }

    const sub = db
      .prepare(
        `SELECT so.*, po.customer_id
         FROM shop_orders so
         JOIN parent_orders po ON po.id = so.parent_order_id
         WHERE so.id = ?`
      )
      .get(subId) as any;

    if (!sub || sub.customer_id !== req.user!.userId) {
      res.status(404).json({ error: 'Sub-order not found.' });
      return;
    }

    const existing = db.prepare(`SELECT id FROM refunds WHERE shop_order_id = ?`).get(subId);
    if (existing) {
      res.status(409).json({ error: 'A refund request already exists for this sub-order.' });
      return;
    }

    const amount = Math.min(
      Number(sub.payable_amount),
      Math.max(1, Number(requestedAmount || sub.payable_amount))
    );

    db.transaction(() => {
      db.prepare(
        `INSERT INTO refunds (parent_order_id, shop_order_id, customer_id, amount, reason, status)
         VALUES (?, ?, ?, ?, ?, 'REQUESTED')`
      ).run(sub.parent_order_id, subId, req.user!.userId, amount, String(reason).trim());

      db.prepare(`UPDATE shop_orders SET refund_status = 'REQUESTED' WHERE id = ?`).run(subId);

      db.prepare(
        `INSERT INTO order_events (parent_order_id, shop_order_id, actor_role, event_type, description)
         VALUES (?, ?, 'CUSTOMER', 'REFUND_REQUESTED', ?)`
      ).run(sub.parent_order_id, subId, `Refund requested for PKR ${amount}: ${String(reason).trim()}`);
    })();

    notifyAllAdmins(
      `Refund Request: ${sub.sub_order_number}`,
      `Customer requested PKR ${amount} refund on ${sub.sub_order_number}.`,
      'REFUND_ALERT',
      sub.sub_order_number
    );

    res.status(201).json({ message: 'Refund request submitted for Admin review.' });
  }
);

// Verified Reviews (Only completed sub-orders belonging to logged-in customer)
marketplaceRouter.post(
  '/reviews',
  requireAuth,
  requireRole('CUSTOMER'),
  (req: AuthenticatedRequest, res) => {
    const { shopOrderId, targetType, productId, rating, comment = '' } = req.body || {};
    const numRating = Math.round(Number(rating));
    if (numRating < 1 || numRating > 5) {
      res.status(400).json({ error: 'Rating must be between 1 and 5 stars.' });
      return;
    }
    if (!['SHOP', 'PRODUCT', 'RIDER'].includes(targetType)) {
      res.status(400).json({ error: 'Invalid review target.' });
      return;
    }

    const sub = db
      .prepare(
        `SELECT so.*, po.customer_id
         FROM shop_orders so
         JOIN parent_orders po ON po.id = so.parent_order_id
         WHERE so.id = ?`
      )
      .get(Number(shopOrderId)) as any;

    if (!sub || sub.customer_id !== req.user!.userId) {
      res.status(403).json({ error: 'You can only review your own orders.' });
      return;
    }
    if (sub.delivery_status !== 'DELIVERED') {
      res.status(400).json({ error: 'Only delivered sub-orders can be reviewed.' });
      return;
    }

    const dup = db
      .prepare(
        `SELECT id FROM reviews
         WHERE customer_id = ? AND shop_order_id = ? AND target_type = ?
           AND COALESCE(product_id, 0) = COALESCE(?, 0)`
      )
      .get(req.user!.userId, sub.id, targetType, productId || null);

    if (dup) {
      res.status(409).json({ error: 'You have already submitted this review.' });
      return;
    }

    db.transaction(() => {
      db.prepare(
        `INSERT INTO reviews (parent_order_id, shop_order_id, customer_id, shop_id, product_id, rider_id, target_type, rating, comment)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        sub.parent_order_id,
        sub.id,
        req.user!.userId,
        sub.shop_id,
        targetType === 'PRODUCT' ? Number(productId) : null,
        targetType === 'RIDER' ? sub.rider_id : null,
        targetType,
        numRating,
        String(comment).trim()
      );

      if (targetType === 'SHOP') {
        const stats = db
          .prepare(`SELECT AVG(rating) as avgR, COUNT(*) as cnt FROM reviews WHERE shop_id = ? AND target_type = 'SHOP'`)
          .get(sub.shop_id) as { avgR: number; cnt: number };
        db.prepare(`UPDATE shops SET rating_avg = ?, rating_count = ? WHERE id = ?`).run(
          Number(stats.avgR.toFixed(1)),
          stats.cnt,
          sub.shop_id
        );
      } else if (targetType === 'PRODUCT' && productId) {
        const stats = db
          .prepare(`SELECT AVG(rating) as avgR, COUNT(*) as cnt FROM reviews WHERE product_id = ? AND target_type = 'PRODUCT'`)
          .get(Number(productId)) as { avgR: number; cnt: number };
        db.prepare(`UPDATE products SET rating_avg = ?, rating_count = ? WHERE id = ?`).run(
          Number(stats.avgR.toFixed(1)),
          stats.cnt,
          Number(productId)
        );
      } else if (targetType === 'RIDER' && sub.rider_id) {
        const stats = db
          .prepare(`SELECT AVG(rating) as avgR, COUNT(*) as cnt FROM reviews WHERE rider_id = ? AND target_type = 'RIDER'`)
          .get(sub.rider_id) as { avgR: number; cnt: number };
        db.prepare(`UPDATE riders SET rating_avg = ?, rating_count = ? WHERE id = ?`).run(
          Number(stats.avgR.toFixed(1)),
          stats.cnt,
          sub.rider_id
        );
      }
    })();

    res.status(201).json({ message: 'Thank you! Your verified review has been recorded.' });
  }
);
