import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { db } from './db.ts';

const JWT_SECRET = process.env.JWT_SECRET || 'delivoo-local-dev-secret-key-change-in-prod-2026';
const JWT_EXPIRES_IN = (process.env.JWT_EXPIRES_IN || '7d') as jwt.SignOptions['expiresIn'];
const WEBHOOK_SECRET = process.env.PAYMENT_WEBHOOK_SECRET || 'delivoo-webhook-hmac-secret-2026';

export type UserRole = 'CUSTOMER' | 'SHOPKEEPER' | 'RIDER' | 'ADMIN';

export interface AuthPayload {
  userId: number;
  role: UserRole;
  email: string;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthPayload;
}

const revokedTokens = new Set<string>();

// Login rate limiter (per IP + email sliding window)
const loginAttempts = new Map<string, { count: number; resetAt: number }>();

export function checkLoginRateLimit(key: string): { allowed: boolean; retryAfterSec: number } {
  const now = Date.now();
  const entry = loginAttempts.get(key);
  if (!entry || now > entry.resetAt) {
    loginAttempts.set(key, { count: 1, resetAt: now + 15 * 60 * 1000 });
    return { allowed: true, retryAfterSec: 0 };
  }
  if (entry.count >= 12) {
    return { allowed: false, retryAfterSec: Math.ceil((entry.resetAt - now) / 1000) };
  }
  entry.count += 1;
  return { allowed: true, retryAfterSec: 0 };
}

export function clearLoginRateLimit(key: string): void {
  loginAttempts.delete(key);
}

export function signAuthToken(payload: AuthPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

export function verifyAuthToken(token: string): AuthPayload | null {
  if (!token || revokedTokens.has(token)) return null;
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AuthPayload;
    // Also verify user is still ACTIVE in database
    const row = db
      .prepare(`SELECT id, role, status FROM users WHERE id = ?`)
      .get(decoded.userId) as { id: number; role: UserRole; status: string } | undefined;
    if (!row || row.status !== 'ACTIVE' || row.role !== decoded.role) {
      return null;
    }
    return decoded;
  } catch {
    return null;
  }
}

export function revokeAuthToken(token: string): void {
  if (token) revokedTokens.add(token);
}

export function extractBearerToken(req: Request): string | null {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) return null;
  return header.slice(7).trim();
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const token = extractBearerToken(req);
  if (!token) {
    res.status(401).json({ error: 'Authentication required. Please log in.' });
    return;
  }
  const payload = verifyAuthToken(token);
  if (!payload) {
    res.status(401).json({ error: 'Session expired or invalid. Please log in again.' });
    return;
  }
  req.user = payload;
  next();
}

export function optionalAuth(req: AuthenticatedRequest, _res: Response, next: NextFunction): void {
  const token = extractBearerToken(req);
  if (token) {
    const payload = verifyAuthToken(token);
    if (payload) req.user = payload;
  }
  next();
}

export function requireRole(...roles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    if (!roles.includes(req.user.role)) {
      res.status(403).json({ error: 'Access denied for your account role.' });
      return;
    }
    next();
  };
}

export function writeAuditLog(
  actorId: number | null,
  actorRole: string,
  action: string,
  targetType: string,
  targetId: string | number,
  details: string
): void {
  db.prepare(
    `INSERT INTO audit_logs (actor_id, actor_role, action, target_type, target_id, details)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(actorId, actorRole, action, targetType, String(targetId), details);
}

export function computePaymentSignature(transactionRef: string, amount: number, status: string): string {
  const payload = `${transactionRef}|${Number(amount).toFixed(2)}|${status}`;
  return crypto.createHmac('sha256', WEBHOOK_SECRET).update(payload).digest('hex');
}
