import type { Server as HttpServer } from 'http';
import { WebSocket, WebSocketServer } from 'ws';
import { db } from './db.ts';
import { verifyAuthToken, type UserRole } from './security.ts';

interface ConnectedClient {
  ws: WebSocket;
  userId: number | null;
  role: UserRole | null;
}

const clients = new Set<ConnectedClient>();

export function attachWebSocketServer(httpServer: HttpServer): void {
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket) => {
    const client: ConnectedClient = { ws, userId: null, role: null };
    clients.add(client);

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(String(raw));
        if (msg.type === 'auth' && typeof msg.token === 'string') {
          const verified = verifyAuthToken(msg.token);
          if (verified) {
            client.userId = verified.userId;
            client.role = verified.role;
            ws.send(JSON.stringify({ type: 'auth:ack', userId: verified.userId, role: verified.role }));
          }
        }
      } catch {
        // Ignore malformed socket frames
      }
    });

    ws.on('close', () => {
      clients.delete(client);
    });

    ws.on('error', () => {
      clients.delete(client);
    });
  });
}

export function sendWsToUser(userId: number, event: string, payload: unknown): void {
  const data = JSON.stringify({ type: event, payload, timestamp: new Date().toISOString() });
  for (const client of clients) {
    if (client.userId === userId && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(data);
    }
  }
}

export function sendWsToRole(role: UserRole, event: string, payload: unknown): void {
  const data = JSON.stringify({ type: event, payload, timestamp: new Date().toISOString() });
  for (const client of clients) {
    if (client.role === role && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(data);
    }
  }
}

export function broadcastCatalogRefresh(): void {
  const data = JSON.stringify({ type: 'catalog:updated', timestamp: new Date().toISOString() });
  for (const client of clients) {
    if (client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(data);
    }
  }
}

export function createNotification(
  userId: number,
  title: string,
  message: string,
  type = 'INFO',
  referenceId = ''
): void {
  const info = db
    .prepare(
      `INSERT INTO notifications (user_id, title, message, type, reference_id)
       VALUES (?, ?, ?, ?, ?)`
    )
    .run(userId, title, message, type, referenceId);

  const created = db.prepare(`SELECT * FROM notifications WHERE id = ?`).get(info.lastInsertRowid);
  sendWsToUser(userId, 'notification:new', created);
}

export function notifyAllAdmins(title: string, message: string, type = 'ADMIN_ALERT', referenceId = ''): void {
  const admins = db.prepare(`SELECT id FROM users WHERE role = 'ADMIN' AND status = 'ACTIVE'`).all() as {
    id: number;
  }[];
  for (const admin of admins) {
    createNotification(admin.id, title, message, type, referenceId);
  }
}
