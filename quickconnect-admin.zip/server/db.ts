import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';
import { createCatalogArtwork } from './artwork.ts';

const dbFilePath = process.env.SQLITE_DB_PATH || path.resolve(process.cwd(), 'data', 'delivoo.db');
const dataDir = path.dirname(dbFilePath);

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Stage 1 / Section 1: Safe backup before running migrations on an existing database
const dbExistedBeforeBoot = fs.existsSync(dbFilePath) && fs.statSync(dbFilePath).size > 0;
if (dbExistedBeforeBoot) {
  const backupDir = path.join(dataDir, 'backups');
  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true });
  }
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupTarget = path.join(backupDir, `delivoo-pre-migration-${stamp}.db`);
  try {
    // Keep at most 5 recent backups to avoid disk bloat
    const existingBackups = fs.readdirSync(backupDir).sort();
    while (existingBackups.length >= 5) {
      const oldest = existingBackups.shift();
      if (oldest) fs.unlinkSync(path.join(backupDir, oldest));
    }
    fs.copyFileSync(dbFilePath, backupTarget);
  } catch {
    // Non-fatal if backup copy encounters transient lock
  }
}

export const db = new Database(dbFilePath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

export function runMigrationsAndSeed(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS migrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      phone TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('CUSTOMER', 'SHOPKEEPER', 'RIDER', 'ADMIN')),
      status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'SUSPENDED')),
      is_verified INTEGER NOT NULL DEFAULT 1,
      verification_otp TEXT,
      reset_otp TEXT,
      reset_otp_expires TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

    CREATE TABLE IF NOT EXISTS addresses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      label TEXT NOT NULL DEFAULT 'Home',
      address_line TEXT NOT NULL,
      city TEXT NOT NULL DEFAULT 'Lahore',
      lat REAL,
      lng REAL,
      is_default INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS shop_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      slug TEXT NOT NULL UNIQUE,
      description TEXT,
      sort_order INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS shops (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      owner_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE RESTRICT,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      category_id INTEGER REFERENCES shop_categories(id),
      category_name TEXT NOT NULL,
      description TEXT DEFAULT '',
      logo_url TEXT DEFAULT '',
      cover_url TEXT DEFAULT '',
      address TEXT NOT NULL,
      city TEXT NOT NULL DEFAULT 'Lahore',
      lat REAL NOT NULL DEFAULT 31.5102,
      lng REAL NOT NULL DEFAULT 74.3441,
      opening_time TEXT NOT NULL DEFAULT '08:00',
      closing_time TEXT NOT NULL DEFAULT '23:00',
      is_open_override TEXT NOT NULL DEFAULT 'AUTO' CHECK (is_open_override IN ('AUTO', 'FORCE_OPEN', 'FORCE_CLOSED')),
      delivery_fee REAL NOT NULL DEFAULT 120,
      prep_time_mins INTEGER NOT NULL DEFAULT 25,
      cnic_ntn TEXT DEFAULT '',
      own_rider_enabled INTEGER NOT NULL DEFAULT 1,
      own_rider_name TEXT DEFAULT '',
      own_rider_phone TEXT DEFAULT '',
      approval_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (approval_status IN ('PENDING', 'APPROVED', 'REJECTED', 'SUSPENDED')),
      rejection_reason TEXT DEFAULT '',
      rating_avg REAL NOT NULL DEFAULT 4.8,
      rating_count INTEGER NOT NULL DEFAULT 0,
      commission_rate REAL NOT NULL DEFAULT 12.0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_shops_approval ON shops(approval_status);
    CREATE INDEX IF NOT EXISTS idx_shops_category ON shops(category_name);

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      shop_id INTEGER NOT NULL REFERENCES shops(id) ON DELETE RESTRICT,
      category_name TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT DEFAULT '',
      selling_price REAL NOT NULL CHECK (selling_price >= 0),
      original_price REAL NOT NULL CHECK (original_price >= 0),
      sku TEXT NOT NULL,
      barcode TEXT DEFAULT '',
      brand TEXT DEFAULT '',
      stock_quantity INTEGER NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
      low_stock_threshold INTEGER NOT NULL DEFAULT 5,
      mfg_date TEXT DEFAULT '',
      expiry_date TEXT DEFAULT '',
      freshness_info TEXT DEFAULT '',
      image_url TEXT DEFAULT '',
      is_active INTEGER NOT NULL DEFAULT 1,
      rating_avg REAL NOT NULL DEFAULT 4.8,
      rating_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(shop_id, sku)
    );
    CREATE INDEX IF NOT EXISTS idx_products_shop ON products(shop_id);
    CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);

    CREATE TABLE IF NOT EXISTS product_images (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      image_url TEXT NOT NULL,
      sort_order INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS product_variants (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      price_delta REAL NOT NULL DEFAULT 0,
      stock_quantity INTEGER NOT NULL DEFAULT 10 CHECK (stock_quantity >= 0),
      sku TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS product_schedules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      shop_id INTEGER NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
      label TEXT NOT NULL DEFAULT 'Scheduled Window',
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      days_of_week TEXT NOT NULL DEFAULT '0,1,2,3,4,5,6',
      promo_price REAL,
      discount_percent REAL,
      is_paused INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_schedules_product ON product_schedules(product_id);

    CREATE TABLE IF NOT EXISTS inventory (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      shop_id INTEGER NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
      change_amount INTEGER NOT NULL,
      new_quantity INTEGER NOT NULL,
      reason TEXT NOT NULL,
      actor_id INTEGER REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS inventory_batches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      shop_id INTEGER NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
      batch_code TEXT NOT NULL,
      quantity INTEGER NOT NULL CHECK (quantity >= 0),
      mfg_date TEXT DEFAULT '',
      expiry_date TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS riders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE RESTRICT,
      cnic TEXT NOT NULL,
      vehicle_type TEXT NOT NULL DEFAULT 'Scooter',
      vehicle_plate TEXT NOT NULL,
      city TEXT NOT NULL DEFAULT 'Lahore',
      approval_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (approval_status IN ('PENDING', 'APPROVED', 'REJECTED', 'SUSPENDED')),
      rejection_reason TEXT DEFAULT '',
      is_online INTEGER NOT NULL DEFAULT 0,
      max_capacity INTEGER NOT NULL DEFAULT 3 CHECK (max_capacity >= 1 AND max_capacity <= 10),
      active_deliveries INTEGER NOT NULL DEFAULT 0 CHECK (active_deliveries >= 0),
      current_lat REAL,
      current_lng REAL,
      last_gps_at TEXT,
      total_earnings REAL NOT NULL DEFAULT 0,
      rating_avg REAL NOT NULL DEFAULT 4.9,
      rating_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_riders_dispatch ON riders(approval_status, is_online);

    CREATE TABLE IF NOT EXISTS rider_locations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      rider_id INTEGER NOT NULL REFERENCES riders(id) ON DELETE CASCADE,
      shop_order_id INTEGER,
      lat REAL NOT NULL,
      lng REAL NOT NULL,
      recorded_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS parent_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT NOT NULL UNIQUE,
      customer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
      subtotal_amount REAL NOT NULL,
      delivery_total REAL NOT NULL,
      tax_amount REAL NOT NULL,
      discount_amount REAL NOT NULL DEFAULT 0,
      total_amount REAL NOT NULL,
      coupon_code TEXT DEFAULT '',
      payment_method TEXT NOT NULL CHECK (payment_method IN ('COD', 'EASYPAISA', 'JAZZCASH', 'CARD')),
      payment_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (payment_status IN ('PENDING', 'PENDING_VERIFICATION', 'PAID', 'PARTIALLY_REFUNDED', 'REFUNDED', 'FAILED')),
      overall_status TEXT NOT NULL DEFAULT 'PLACED' CHECK (overall_status IN ('PLACED', 'IN_PROGRESS', 'PARTIALLY_DELIVERED', 'COMPLETED', 'PARTIALLY_CANCELLED', 'CANCELLED')),
      delivery_address TEXT NOT NULL,
      delivery_city TEXT NOT NULL DEFAULT 'Lahore',
      delivery_lat REAL,
      delivery_lng REAL,
      contact_phone TEXT NOT NULL,
      delivery_instructions TEXT DEFAULT '',
      idempotency_key TEXT UNIQUE,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_parent_orders_customer ON parent_orders(customer_id);

    CREATE TABLE IF NOT EXISTS shop_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_order_id INTEGER NOT NULL REFERENCES parent_orders(id) ON DELETE CASCADE,
      sub_order_number TEXT NOT NULL UNIQUE,
      shop_id INTEGER NOT NULL REFERENCES shops(id) ON DELETE RESTRICT,
      subtotal REAL NOT NULL,
      delivery_fee REAL NOT NULL,
      commission_amount REAL NOT NULL DEFAULT 0,
      allocated_discount REAL NOT NULL DEFAULT 0,
      payable_amount REAL NOT NULL,
      prep_time_mins INTEGER NOT NULL DEFAULT 25,
      shop_status TEXT NOT NULL DEFAULT 'PENDING_SHOP' CHECK (shop_status IN ('PENDING_SHOP', 'ACCEPTED', 'PREPARING', 'READY_FOR_PICKUP', 'REJECTED', 'CANCELLED')),
      rejection_reason TEXT DEFAULT '',
      dispatch_mode TEXT NOT NULL DEFAULT 'UNASSIGNED' CHECK (dispatch_mode IN ('UNASSIGNED', 'DELIVOO_RIDER', 'SHOP_RIDER')),
      rider_id INTEGER REFERENCES riders(id),
      own_rider_info TEXT DEFAULT '',
      delivery_status TEXT NOT NULL DEFAULT 'UNASSIGNED' CHECK (delivery_status IN ('UNASSIGNED', 'PENDING_ASSIGNMENT', 'ASSIGNED', 'ACCEPTED', 'ARRIVED_AT_SHOP', 'PICKED_UP', 'ON_THE_WAY', 'ARRIVED_AT_CUSTOMER', 'DELIVERED', 'CANCELLED')),
      refund_status TEXT NOT NULL DEFAULT 'NONE' CHECK (refund_status IN ('NONE', 'REQUESTED', 'APPROVED', 'REJECTED')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_shop_orders_parent ON shop_orders(parent_order_id);
    CREATE INDEX IF NOT EXISTS idx_shop_orders_shop ON shop_orders(shop_id);
    CREATE INDEX IF NOT EXISTS idx_shop_orders_rider ON shop_orders(rider_id);

    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      shop_order_id INTEGER NOT NULL REFERENCES shop_orders(id) ON DELETE CASCADE,
      product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
      variant_id INTEGER,
      product_name TEXT NOT NULL,
      variant_name TEXT DEFAULT '',
      unit_price REAL NOT NULL,
      quantity INTEGER NOT NULL CHECK (quantity > 0),
      line_total REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS order_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_order_id INTEGER NOT NULL REFERENCES parent_orders(id) ON DELETE CASCADE,
      shop_order_id INTEGER REFERENCES shop_orders(id) ON DELETE CASCADE,
      actor_role TEXT NOT NULL,
      event_type TEXT NOT NULL,
      description TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS rider_assignments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      shop_order_id INTEGER NOT NULL REFERENCES shop_orders(id) ON DELETE CASCADE,
      rider_id INTEGER NOT NULL REFERENCES riders(id) ON DELETE CASCADE,
      status TEXT NOT NULL DEFAULT 'OFFERED' CHECK (status IN ('OFFERED', 'ACCEPTED', 'REJECTED', 'COMPLETED', 'REASSIGNED')),
      distance_km REAL NOT NULL DEFAULT 0,
      earning_amount REAL NOT NULL DEFAULT 100,
      offered_at TEXT NOT NULL DEFAULT (datetime('now')),
      responded_at TEXT
    );

    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_order_id INTEGER NOT NULL REFERENCES parent_orders(id) ON DELETE CASCADE,
      method TEXT NOT NULL,
      amount REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'PENDING',
      transaction_ref TEXT UNIQUE,
      webhook_verified INTEGER NOT NULL DEFAULT 0,
      verified_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS refunds (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_order_id INTEGER NOT NULL REFERENCES parent_orders(id) ON DELETE CASCADE,
      shop_order_id INTEGER NOT NULL REFERENCES shop_orders(id) ON DELETE CASCADE,
      customer_id INTEGER NOT NULL REFERENCES users(id),
      amount REAL NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'REQUESTED' CHECK (status IN ('REQUESTED', 'APPROVED', 'REJECTED')),
      admin_note TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      resolved_at TEXT
    );

    CREATE TABLE IF NOT EXISTS coupons (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      discount_type TEXT NOT NULL CHECK (discount_type IN ('PERCENTAGE', 'FIXED')),
      discount_value REAL NOT NULL,
      min_order_amount REAL NOT NULL DEFAULT 0,
      max_discount REAL,
      usage_limit INTEGER NOT NULL DEFAULT 500,
      used_count INTEGER NOT NULL DEFAULT 0,
      eligible_category TEXT DEFAULT '',
      shop_id INTEGER REFERENCES shops(id),
      expires_at TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_order_id INTEGER NOT NULL REFERENCES parent_orders(id),
      shop_order_id INTEGER NOT NULL REFERENCES shop_orders(id),
      customer_id INTEGER NOT NULL REFERENCES users(id),
      shop_id INTEGER REFERENCES shops(id),
      product_id INTEGER REFERENCES products(id),
      rider_id INTEGER REFERENCES riders(id),
      target_type TEXT NOT NULL CHECK (target_type IN ('SHOP', 'PRODUCT', 'RIDER')),
      rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
      comment TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS commissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      shop_order_id INTEGER NOT NULL UNIQUE REFERENCES shop_orders(id),
      shop_id INTEGER NOT NULL REFERENCES shops(id),
      gross_amount REAL NOT NULL,
      commission_rate REAL NOT NULL,
      commission_amount REAL NOT NULL,
      net_merchant_amount REAL NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS settlements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      shop_id INTEGER NOT NULL REFERENCES shops(id),
      shop_order_id INTEGER NOT NULL REFERENCES shop_orders(id),
      amount REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'CREDITED',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'INFO',
      reference_id TEXT DEFAULT '',
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);

    CREATE TABLE IF NOT EXISTS support_tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id),
      user_name TEXT DEFAULT 'Guest',
      role TEXT DEFAULT 'GUEST',
      type TEXT NOT NULL DEFAULT 'SUPPORT' CHECK (type IN ('SUPPORT', 'FEEDBACK', 'COMPLAINT', 'BUG')),
      subject TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'IN_PROGRESS', 'RESOLVED')),
      admin_reply TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS chatbot_conversations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id),
      session_key TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS chatbot_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      conversation_id INTEGER NOT NULL REFERENCES chatbot_conversations(id) ON DELETE CASCADE,
      sender TEXT NOT NULL CHECK (sender IN ('USER', 'BOT')),
      message TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_id INTEGER REFERENCES users(id),
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT DEFAULT '',
      details TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS import_jobs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      shop_id INTEGER NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
      method TEXT NOT NULL,
      total_rows INTEGER NOT NULL DEFAULT 0,
      valid_rows INTEGER NOT NULL DEFAULT 0,
      error_rows INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'COMPLETED',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS import_job_rows (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      import_job_id INTEGER NOT NULL REFERENCES import_jobs(id) ON DELETE CASCADE,
      row_number INTEGER NOT NULL,
      sku TEXT DEFAULT '',
      product_name TEXT DEFAULT '',
      status TEXT NOT NULL,
      error_message TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS platform_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  db.prepare(`INSERT OR IGNORE INTO migrations (name) VALUES (?)`).run('001_initial_delivoo_schema');

  // Ensure default platform settings exist without overwriting existing admin edits
  const setSetting = db.prepare(`INSERT OR IGNORE INTO platform_settings (key, value) VALUES (?, ?)`);
  setSetting.run('default_commission_rate', '12');
  setSetting.run('base_delivery_fee', '120');
  setSetting.run('tax_rate_percent', '5');
  setSetting.run('rider_base_payout', '95');
  setSetting.run('rider_per_km_payout', '18');
  setSetting.run('helpline_phone', '+92-42-111-335-486');
  setSetting.run('helpline_email', 'support@delivoo.pk');

  // Ensure categories exist
  const categories = [
    ['Food', 'food', 'Prepared meals, BBQ, desi cuisine & fast food', 1],
    ['Grocery', 'grocery', 'Fresh produce, pantry staples, dairy & beverages', 2],
    ['Bakery', 'bakery', 'Artisan breads, cakes, pastries & savories', 3],
    ['Clothing', 'clothing', 'Apparel, kurtas, everyday wear & footwear', 4],
    ['Pharmacy', 'pharmacy', 'OTC wellness, medical devices & personal health', 5],
    ['Electronics', 'electronics', 'Chargers, audio gear & everyday tech accessories', 6],
    ['Beauty & Personal Care', 'beauty', 'Skincare, grooming & personal hygiene', 7],
    ['Household Products', 'household', 'Cleaning supplies, kitchenware & home essentials', 8],
  ] as const;

  const insertCat = db.prepare(
    `INSERT OR IGNORE INTO shop_categories (name, slug, description, sort_order) VALUES (?, ?, ?, ?)`
  );
  for (const [name, slug, desc, order] of categories) {
    insertCat.run(name, slug, desc, order);
  }

  // Ensure bootstrap Admin exists
  const adminEmail = (process.env.ADMIN_EMAIL || 'admin@delivoo.pk').toLowerCase().trim();
  const existingAdmin = db.prepare(`SELECT id FROM users WHERE role = 'ADMIN' LIMIT 1`).get();
  if (!existingAdmin) {
    const adminPass = process.env.ADMIN_INITIAL_PASSWORD || 'Admin@Delivoo2026';
    const hash = bcrypt.hashSync(adminPass, 10);
    db.prepare(
      `INSERT INTO users (name, email, phone, password_hash, role, status, is_verified)
       VALUES (?, ?, ?, ?, 'ADMIN', 'ACTIVE', 1)`
    ).run('DELIVOO Operations Admin', adminEmail, '+923001000001', hash);
  }

  // Only seed initial marketplace merchants/products/riders if shops table is completely empty
  const shopCount = (db.prepare(`SELECT COUNT(*) as c FROM shops`).get() as { c: number }).c;
  if (shopCount > 0) {
    return;
  }

  const seedTx = db.transaction(() => {
    const shopPassHash = bcrypt.hashSync('Shop@Delivoo2026', 10);
    const riderPassHash = bcrypt.hashSync('Rider@Delivoo2026', 10);
    const custPassHash = bcrypt.hashSync('Customer@Delivoo2026', 10);

    // 1. Seed Customer
    const custInfo = db.prepare(
      `INSERT INTO users (name, email, phone, password_hash, role, status, is_verified)
       VALUES (?, ?, ?, ?, 'CUSTOMER', 'ACTIVE', 1)`
    ).run('Ayesha Siddiqui', 'customer@delivoo.pk', '+923214567890', custPassHash);
    db.prepare(
      `INSERT INTO addresses (user_id, label, address_line, city, lat, lng, is_default)
       VALUES (?, 'Home', 'House 42-B, Main Boulevard Gulberg III', 'Lahore', 31.5125, 74.3465, 1)`
    ).run(custInfo.lastInsertRowid);

    // 2. Seed Approved Shops + 1 Pending Shopkeeper Application (demonstrating registration->approval workflow)
    const shopSeeds = [
      {
        ownerName: 'Tariq Mahmood',
        email: 'freshmart@delivoo.pk',
        phone: '+923004111222',
        name: 'Fresh Mart',
        slug: 'fresh-mart',
        category: 'Grocery',
        motif: 'grocery' as const,
        accent: '#059669',
        bg: '#ecfdf5',
        desc: 'Daily farm-fresh vegetables, dairy, imported groceries, and household staples.',
        address: 'Plot 18, Liberty Market, Gulberg III',
        city: 'Lahore',
        lat: 31.5108,
        lng: 74.3442,
        deliveryFee: 99,
        prepMins: 20,
        status: 'APPROVED',
        products: [
          {
            name: 'Guard Super Kernel Basmati Rice 5kg',
            desc: 'Aged extra-long grain aromatic Pakistani basmati rice.',
            price: 1850,
            orig: 2100,
            sku: 'FM-RICE-5KG',
            barcode: '8961000100112',
            brand: 'Guard',
            stock: 42,
            freshness: '2026 Harvest Crop',
            variants: [
              { name: '5 kg Bag', delta: 0, stock: 30 },
              { name: '10 kg Family Sack', delta: 1750, stock: 12 },
            ],
          },
          {
            name: 'Organic Free-Range Farm Eggs (12 pcs)',
            desc: 'Protein-rich brown organic eggs delivered chilled from local farms.',
            price: 460,
            orig: 500,
            sku: 'FM-EGG-12',
            barcode: '8961000100129',
            brand: 'PureNest',
            stock: 55,
            freshness: 'Packed daily at 6:00 AM',
            variants: [],
          },
          {
            name: 'Sindhri Sweet Mangoes (2 kg Crate)',
            desc: 'Hand-picked golden Sindhri mangoes, naturally ripened without carbide.',
            price: 780,
            orig: 890,
            sku: 'FM-MANGO-2K',
            barcode: '8961000100136',
            brand: 'Orchard Select',
            stock: 28,
            freshness: 'Orchard Fresh',
            variants: [],
          },
        ],
      },
      {
        ownerName: 'Hina Bokhari',
        email: 'sweetcrumbs@delivoo.pk',
        phone: '+923004333444',
        name: 'Sweet Crumbs',
        slug: 'sweet-crumbs',
        category: 'Bakery',
        motif: 'bakery' as const,
        accent: '#d97706',
        bg: '#fffbeb',
        desc: 'Small-batch artisan sourdough breads, Belgian chocolate cakes & flaky savories.',
        address: 'Sector K Commercial, DHA Phase 5',
        city: 'Lahore',
        lat: 31.4697,
        lng: 74.4084,
        deliveryFee: 130,
        prepMins: 25,
        status: 'APPROVED',
        products: [
          {
            name: 'Belgian Dark Chocolate Fudge Cake (2 lbs)',
            desc: 'Rich 70% Belgian couverture ganache layered over moist cocoa sponge.',
            price: 2450,
            orig: 2750,
            sku: 'SC-CAKE-BEL',
            barcode: '8962000200210',
            brand: 'Sweet Crumbs',
            stock: 16,
            freshness: 'Baked fresh every morning',
            variants: [
              { name: '1 lb Celebration', delta: -1050, stock: 8 },
              { name: '2 lbs Signature', delta: 0, stock: 8 },
            ],
          },
          {
            name: 'Artisan Multigrain Sourdough Loaf',
            desc: 'Slow 24-hour fermented crust bread with flax, oats, and sunflower seeds.',
            price: 520,
            orig: 580,
            sku: 'SC-BREAD-SD',
            barcode: '8962000200227',
            brand: 'Sweet Crumbs',
            stock: 24,
            freshness: 'Warm oven batch',
            variants: [],
          },
          {
            name: 'Baked Chicken Puff Patties (Box of 6)',
            desc: 'Golden crisp puff pastry shells filled with black-pepper shredded chicken.',
            price: 690,
            orig: 750,
            sku: 'SC-PATTY-06',
            barcode: '8962000200234',
            brand: 'Sweet Crumbs',
            stock: 30,
            freshness: 'Served warm',
            variants: [],
          },
        ],
      },
      {
        ownerName: 'Zainab Raza',
        email: 'styleavenue@delivoo.pk',
        phone: '+923004555666',
        name: 'Style Avenue',
        slug: 'style-avenue',
        category: 'Clothing',
        motif: 'clothing' as const,
        accent: '#0f766e',
        bg: '#f0fdfa',
        desc: 'Contemporary Pakistani stitched kurtas, breathable cotton essentials & leather craft.',
        address: '94-C MM Alam Road, Gulberg',
        city: 'Lahore',
        lat: 31.5095,
        lng: 74.3502,
        deliveryFee: 150,
        prepMins: 30,
        status: 'APPROVED',
        products: [
          {
            name: 'Embroidered Cambric Kurta — Emerald Mist',
            desc: 'Fine breathable Pakistani cotton cambric with tonal threadwork neckline.',
            price: 3490,
            orig: 4200,
            sku: 'SA-KURTA-EM',
            barcode: '8963000300319',
            brand: 'Style Avenue',
            stock: 25,
            freshness: 'New Season Collection',
            variants: [
              { name: 'Small (S)', delta: 0, stock: 8 },
              { name: 'Medium (M)', delta: 0, stock: 10 },
              { name: 'Large (L)', delta: 0, stock: 7 },
            ],
          },
          {
            name: 'Handcrafted Peshawari Chappal — Midnight Tan',
            desc: 'Full-grain cowhide leather upper with cushioned tire-grade sole.',
            price: 4150,
            orig: 4800,
            sku: 'SA-SHOE-PC',
            barcode: '8963000300326',
            brand: 'Style Avenue',
            stock: 15,
            freshness: 'Artisan Hand-stitched',
            variants: [
              { name: 'EU 41 / PK 7', delta: 0, stock: 5 },
              { name: 'EU 42 / PK 8', delta: 0, stock: 5 },
              { name: 'EU 43 / PK 9', delta: 0, stock: 5 },
            ],
          },
        ],
      },
      {
        ownerName: 'Kamran Qureshi',
        email: 'kababjees@delivoo.pk',
        phone: '+923004777888',
        name: 'Karachi Charcoal Kitchen',
        slug: 'karachi-charcoal-kitchen',
        category: 'Food',
        motif: 'food' as const,
        accent: '#047857',
        bg: '#ecfdf5',
        desc: 'Live charcoal BBQ, Peshawari karahi, handi & tandoori naan prepared to order.',
        address: 'Block G-1 Market, Johar Town',
        city: 'Lahore',
        lat: 31.4712,
        lng: 74.2791,
        deliveryFee: 110,
        prepMins: 30,
        status: 'APPROVED',
        products: [
          {
            name: 'Charsi Mutton Karahi (Half / Full)',
            desc: 'Tender mutton simmered in vine tomatoes, green chilies, ginger & black pepper.',
            price: 2150,
            orig: 2400,
            sku: 'KCK-MUTTON-01',
            barcode: '8964000400418',
            brand: 'Charcoal Kitchen',
            stock: 22,
            freshness: 'Cooked fresh on order',
            variants: [
              { name: 'Half (Serves 2)', delta: 0, stock: 12 },
              { name: 'Full (Serves 4)', delta: 1850, stock: 10 },
            ],
          },
          {
            name: 'Reshmi Chicken Seekh Kabab Platter (6 skewers)',
            desc: 'Charcoal-grilled minced chicken skewers with mint raita and tamarind chutney.',
            price: 1180,
            orig: 1320,
            sku: 'KCK-SEEKH-06',
            barcode: '8964000400425',
            brand: 'Charcoal Kitchen',
            stock: 35,
            freshness: 'Live Grill',
            variants: [],
          },
        ],
      },
      {
        ownerName: 'Dr. Salman Farooq',
        email: 'sehat@delivoo.pk',
        phone: '+923004999000',
        name: 'Sehat Plus Pharmacy',
        slug: 'sehat-plus-pharmacy',
        category: 'Pharmacy',
        motif: 'pharmacy' as const,
        accent: '#0d9488',
        bg: '#f0fdfa',
        desc: 'Licensed community pharmacy offering OTC wellness, vitamins & diagnostic devices.',
        address: 'Bank Square Market, Model Town',
        city: 'Lahore',
        lat: 31.4835,
        lng: 74.3256,
        deliveryFee: 80,
        prepMins: 15,
        status: 'APPROVED',
        products: [
          {
            name: 'Calcium + Vitamin C 1000mg Effervescent (20 Tabs)',
            desc: 'Sugar-free orange effervescent immunity & bone support tablets.',
            price: 640,
            orig: 720,
            sku: 'SP-VITC-1000',
            barcode: '8965000500517',
            brand: 'NutriPak',
            stock: 48,
            freshness: 'Exp: 2028-06-30',
            variants: [],
          },
          {
            name: 'Infrared Non-Contact Clinical Thermometer',
            desc: '1-second forehead digital reading with fever alarm and memory recall.',
            price: 3250,
            orig: 3750,
            sku: 'SP-THERM-IR',
            barcode: '8965000500524',
            brand: 'MediCheck',
            stock: 14,
            freshness: '1 Year Warranty',
            variants: [],
          },
        ],
      },
      {
        ownerName: 'Adeel Sheikh',
        email: 'spicebazaar@delivoo.pk',
        phone: '+923005112233',
        name: 'Lahore Spice & Dry Fruit House',
        slug: 'lahore-spice-dry-fruit',
        category: 'Grocery',
        motif: 'grocery' as const,
        accent: '#059669',
        bg: '#ecfdf5',
        desc: 'Hand-roasted whole spices, Hunza apricots, Chilgoza pine nuts & Kashmiri saffron.',
        address: 'Akbari Mandi / Circular Road',
        city: 'Lahore',
        lat: 31.5820,
        lng: 74.3225,
        deliveryFee: 120,
        prepMins: 25,
        status: 'PENDING', // Pending Admin Approval!
        products: [],
      },
    ];

    const insertUser = db.prepare(
      `INSERT INTO users (name, email, phone, password_hash, role, status, is_verified)
       VALUES (?, ?, ?, ?, 'SHOPKEEPER', 'ACTIVE', 1)`
    );
    const getCatId = db.prepare(`SELECT id FROM shop_categories WHERE name = ?`);
    const insertShop = db.prepare(
      `INSERT INTO shops (owner_id, name, slug, category_id, category_name, description, logo_url, cover_url, address, city, lat, lng, opening_time, closing_time, delivery_fee, prep_time_mins, cnic_ntn, approval_status, rating_avg, rating_count)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '00:00', '23:59', ?, ?, '35202-1234567-1', ?, 4.8, 24)`
    );
    const insertProd = db.prepare(
      `INSERT INTO products (shop_id, category_name, name, description, selling_price, original_price, sku, barcode, brand, stock_quantity, mfg_date, expiry_date, freshness_info, image_url, is_active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '2026-10-01', '2027-10-01', ?, ?, 1)`
    );
    const insertVariant = db.prepare(
      `INSERT INTO product_variants (product_id, name, price_delta, stock_quantity, sku) VALUES (?, ?, ?, ?, ?)`
    );
    const insertBatch = db.prepare(
      `INSERT INTO inventory_batches (product_id, shop_id, batch_code, quantity, mfg_date, expiry_date)
       VALUES (?, ?, ?, ?, '2026-10-01', '2027-10-01')`
    );

    for (const s of shopSeeds) {
      const u = insertUser.run(s.ownerName, s.email, s.phone, shopPassHash);
      const catRow = getCatId.get(s.category) as { id: number } | undefined;
      const cover = createCatalogArtwork(s.name, `${s.category} · ${s.city}`, s.accent, s.bg, s.motif);
      const shopRes = insertShop.run(
        u.lastInsertRowid,
        s.name,
        s.slug,
        catRow ? catRow.id : null,
        s.category,
        s.desc,
        cover,
        cover,
        s.address,
        s.city,
        s.lat,
        s.lng,
        s.deliveryFee,
        s.prepMins,
        s.status
      );
      const shopId = Number(shopRes.lastInsertRowid);

      for (const p of s.products) {
        const art = createCatalogArtwork(p.name.slice(0, 28), `${p.brand} · ${s.name}`, s.accent, s.bg, s.motif);
        const prodRes = insertProd.run(
          shopId,
          s.category,
          p.name,
          p.desc,
          p.price,
          p.orig,
          p.sku,
          p.barcode,
          p.brand,
          p.stock,
          p.freshness,
          art
        );
        const prodId = Number(prodRes.lastInsertRowid);
        insertBatch.run(prodId, shopId, `BATCH-${p.sku}-01`, p.stock);
        for (const v of p.variants) {
          insertVariant.run(prodId, v.name, v.delta, v.stock, `${p.sku}-${v.name.slice(0, 3).toUpperCase()}`);
        }
      }
    }

    // 3. Seed 2 Approved Online Riders + 1 Pending Rider Application (waiting for Admin approval)
    const riderSeeds = [
      {
        name: 'Muhammad Ali Raza',
        email: 'ali.rider@delivoo.pk',
        phone: '+923114001100',
        cnic: '35202-8841201-3',
        vehicle: 'Motorcycle',
        plate: 'LEB-4821',
        city: 'Lahore',
        status: 'APPROVED',
        online: 1,
        capacity: 3,
        lat: 31.5085,
        lng: 74.3468,
      },
      {
        name: 'Bilal Hussain',
        email: 'bilal.rider@delivoo.pk',
        phone: '+923124002200',
        cnic: '35202-9923104-5',
        vehicle: 'Scooter',
        plate: 'LEA-9012',
        city: 'Lahore',
        status: 'APPROVED',
        online: 1,
        capacity: 2,
        lat: 31.4740,
        lng: 74.3980,
      },
      {
        name: 'Usman Ghani',
        email: 'usman.rider@delivoo.pk',
        phone: '+923134003300',
        cnic: '35201-7712908-7',
        vehicle: 'Motorcycle',
        plate: 'LEC-7731',
        city: 'Lahore',
        status: 'PENDING', // Pending Admin Approval!
        online: 0,
        capacity: 3,
        lat: 31.5150,
        lng: 74.3400,
      },
    ];

    const insertRiderUser = db.prepare(
      `INSERT INTO users (name, email, phone, password_hash, role, status, is_verified)
       VALUES (?, ?, ?, ?, 'RIDER', 'ACTIVE', 1)`
    );
    const insertRider = db.prepare(
      `INSERT INTO riders (user_id, cnic, vehicle_type, vehicle_plate, city, approval_status, is_online, max_capacity, current_lat, current_lng, last_gps_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))`
    );

    for (const r of riderSeeds) {
      const ru = insertRiderUser.run(r.name, r.email, r.phone, riderPassHash);
      insertRider.run(
        ru.lastInsertRowid,
        r.cnic,
        r.vehicle,
        r.plate,
        r.city,
        r.status,
        r.online,
        r.capacity,
        r.lat,
        r.lng
      );
    }

    // 4. Seed Coupons
    const insertCoupon = db.prepare(
      `INSERT INTO coupons (code, discount_type, discount_value, min_order_amount, max_discount, usage_limit, eligible_category, expires_at, is_active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)`
    );
    insertCoupon.run('WELCOME10', 'PERCENTAGE', 10, 800, 500, 1000, '', '2028-12-31T23:59:59Z');
    insertCoupon.run('DELIVOO200', 'FIXED', 200, 1500, 200, 500, '', '2028-12-31T23:59:59Z');
    insertCoupon.run('FRESH15', 'PERCENTAGE', 15, 1000, 400, 300, 'Grocery', '2028-12-31T23:59:59Z');
  });

  seedTx();
}
