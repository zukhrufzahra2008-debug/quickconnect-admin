/**
 * Crisp local SVG data-URI generator for studio product & shop visuals.
 * Avoids fragile external image domains while guaranteeing instant, zero-broken-image rendering.
 */
export function createCatalogArtwork(
  title: string,
  subtitle: string,
  accentHex: string,
  bgHex: string,
  motif: 'food' | 'grocery' | 'bakery' | 'clothing' | 'pharmacy' | 'electronics' | 'beauty' | 'household'
): string {
  const iconPaths: Record<string, string> = {
    food: '<path d="M12 4c-4.4 0-8 2.7-8 6h16c0-3.3-3.6-6-8-6zm-8 8c0 2.2 1.8 4 4 4h8c2.2 0 4-1.8 4-4H4zm2 6h12v2H6v-2z" fill="currentColor"/>',
    grocery: '<path d="M7 18c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm10 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zM5.2 6l1.6 7.5c.2.9 1 1.5 1.9 1.5h7.8c.9 0 1.7-.6 1.9-1.5L20 7H6.2l-.4-2H2v2h3.2z" fill="currentColor"/>',
    bakery: '<path d="M12 5c-5 0-9 3.1-9 7 0 1.9 1 3.6 2.6 4.8L6 19h12l.4-2.2C20 15.6 21 13.9 21 12c0-3.9-4-7-9-7zm-3 5.5c0-.8.7-1.5 1.5-1.5s1.5.7 1.5 1.5V13H9v-2.5zm4.5 0c0-.8.7-1.5 1.5-1.5s1.5.7 1.5 1.5V13h-3v-2.5z" fill="currentColor"/>',
    clothing: '<path d="M16 4l4 3-2.5 3.5L15 9v11H9V9l-2.5 1.5L4 7l4-3c1 1.3 2.4 2 4 2s3-.7 4-2z" fill="currentColor"/>',
    pharmacy: '<path d="M19 5H5c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm-4 8h-2v2h-2v-2H9v-2h2V9h2v2h2v2z" fill="currentColor"/>',
    electronics: '<path d="M4 6h16v10H4V6zm18 12v2H2v-2h20zM9 9h6v4H9V9z" fill="currentColor"/>',
    beauty: '<path d="M10 3h4v3h-4V3zm-1 5h6l1 13H8L9 8zm2 3v6h2v-6h-2z" fill="currentColor"/>',
    household: '<path d="M12 3l9 8h-3v9h-5v-6h-2v6H6v-9H3l9-8z" fill="currentColor"/>',
  };

  const safeTitle = title.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const safeSub = subtitle.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 480" width="640" height="480">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${bgHex}"/>
        <stop offset="100%" stop-color="#ffffff"/>
      </linearGradient>
    </defs>
    <rect width="640" height="480" fill="url(#g)"/>
    <circle cx="520" cy="90" r="140" fill="${accentHex}" opacity="0.08"/>
    <circle cx="110" cy="400" r="110" fill="${accentHex}" opacity="0.06"/>
    <rect x="248" y="108" width="144" height="144" rx="36" fill="#ffffff" stroke="${accentHex}" stroke-opacity="0.22" stroke-width="2"/>
    <g transform="translate(272, 132) scale(4)" color="${accentHex}">
      ${iconPaths[motif] || iconPaths.grocery}
    </g>
    <text x="320" y="308" text-anchor="middle" font-family="Plus Jakarta Sans, DM Sans, sans-serif" font-size="28" font-weight="700" fill="#0f172a">${safeTitle}</text>
    <text x="320" y="344" text-anchor="middle" font-family="DM Sans, sans-serif" font-size="17" font-weight="500" fill="#475569">${safeSub}</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
