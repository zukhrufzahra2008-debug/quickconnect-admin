import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { runMigrationsAndSeed } from './server/db.ts';
import { attachWebSocketServer } from './server/realtime.ts';
import { adminRouter } from './server/routes/admin.ts';
import { authRouter } from './server/routes/auth.ts';
import { marketplaceRouter } from './server/routes/marketplace.ts';
import { riderRouter } from './server/routes/rider.ts';
import { shopkeeperRouter } from './server/routes/shopkeeper.ts';
import { supportRouter } from './server/routes/support.ts';

async function bootstrap() {
  runMigrationsAndSeed();

  const app = express();
  const httpServer = http.createServer(app);

  // Attach real-time WebSocket hub on /ws (same port 3000)
  attachWebSocketServer(httpServer);

  // Security headers
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  app.use(express.json({ limit: '5mb' }));

  // Public structured sample product page for testing Website URL Import reliably
  app.get('/public-sample-product/:slug', (req, res) => {
    const slug = String(req.params.slug || 'hunza-walnuts');
    const isHoney = slug.includes('honey');
    const productJsonLd = {
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: isHoney ? 'Raw Sidr Mountain Honey 500g' : 'Organic Hunza Shelled Walnuts 500g',
      description: isHoney
        ? 'Unheated wildflower Sidr honey harvested from northern valleys of Pakistan.'
        : 'Sun-dried snow-fed Hunza valley walnut halves rich in Omega-3.',
      sku: isHoney ? 'URL-SIDR-500' : 'URL-HUNZA-500',
      brand: { '@type': 'Brand', name: 'Karakoram Harvest' },
      offers: {
        '@type': 'Offer',
        priceCurrency: 'PKR',
        price: isHoney ? '1650' : '1290',
        availability: 'https://schema.org/InStock',
      },
    };
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(`<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${productJsonLd.name}</title>
  <meta property="og:title" content="${productJsonLd.name}" />
  <meta property="og:description" content="${productJsonLd.description}" />
  <meta property="product:price:amount" content="${productJsonLd.offers.price}" />
  <script type="application/ld+json">${JSON.stringify(productJsonLd)}</script>
</head>
<body>
  <h1>${productJsonLd.name}</h1>
  <p>${productJsonLd.description}</p>
  <p>PKR ${productJsonLd.offers.price}</p>
</body>
</html>`);
  });

  // Mount modular REST API routers
  app.use('/api/auth', authRouter);
  app.use('/api/marketplace', marketplaceRouter);
  app.use('/api/shopkeeper', shopkeeperRouter);
  app.use('/api/rider', riderRouter);
  app.use('/api/admin', adminRouter);
  app.use('/api/support', supportRouter);

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'DELIVOO', timezone: 'Asia/Karachi' });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const port = Number(process.env.PORT || 3000);
  httpServer.listen(port, '0.0.0.0', () => {
    console.log(`DELIVOO full-stack server listening on http://0.0.0.0:${port}`);
  });
}

bootstrap().catch((err) => {
  console.error('Failed to start DELIVOO server:', err);
  process.exit(1);
});
