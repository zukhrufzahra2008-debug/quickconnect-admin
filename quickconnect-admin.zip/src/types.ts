export type UserRole = 'CUSTOMER' | 'SHOPKEEPER' | 'RIDER' | 'ADMIN';

export interface UserProfile {
  id: number;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  status: string;
  is_verified: number;
  created_at: string;
}

export interface ShopProfile {
  id: number;
  owner_id: number;
  name: string;
  slug: string;
  category_name: string;
  description: string;
  logo_url: string;
  cover_url: string;
  address: string;
  city: string;
  lat: number;
  lng: number;
  opening_time: string;
  closing_time: string;
  is_open_override: 'AUTO' | 'FORCE_OPEN' | 'FORCE_CLOSED';
  delivery_fee: number;
  prep_time_mins: number;
  cnic_ntn: string;
  own_rider_enabled: number;
  own_rider_name: string;
  own_rider_phone: string;
  approval_status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'SUSPENDED';
  rejection_reason: string;
  rating_avg: number;
  rating_count: number;
  commission_rate: number;
  isOpen?: boolean;
  distanceKm?: number | null;
  estimatedDeliveryMins?: number;
}

export interface RiderProfile {
  id: number;
  user_id: number;
  cnic: string;
  vehicle_type: string;
  vehicle_plate: string;
  city: string;
  approval_status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'SUSPENDED';
  rejection_reason: string;
  is_online: number;
  max_capacity: number;
  active_deliveries: number;
  current_lat: number | null;
  current_lng: number | null;
  last_gps_at: string | null;
  total_earnings: number;
  rating_avg: number;
  rating_count: number;
}

export interface AddressRecord {
  id: number;
  label: string;
  address_line: string;
  city: string;
  lat: number | null;
  lng: number | null;
  is_default: number;
}

export interface SessionData {
  token: string;
  user: UserProfile;
  shop: ShopProfile | null;
  rider: RiderProfile | null;
  addresses: AddressRecord[];
  unreadNotifications: number;
}

export interface ProductVariant {
  id: number;
  product_id: number;
  name: string;
  price_delta: number;
  stock_quantity: number;
  sku: string;
}

export interface CatalogProduct {
  id: number;
  shop_id: number;
  shopName: string;
  shopDeliveryFee: number;
  shopIsOpen: boolean;
  category_name: string;
  name: string;
  description: string;
  selling_price: number;
  original_price: number;
  effectivePrice: number;
  sku: string;
  barcode: string;
  brand: string;
  stock_quantity: number;
  mfg_date: string;
  expiry_date: string;
  freshness_info: string;
  image_url: string;
  rating_avg: number;
  rating_count: number;
  available: boolean;
  availabilityReason: string;
  activeScheduleLabel: string | null;
  variants: ProductVariant[];
}

export interface CartItem {
  key: string;
  productId: number;
  variantId: number | null;
  variantName: string;
  productName: string;
  shopId: number;
  shopName: string;
  unitPrice: number;
  quantity: number;
  maxStock: number;
  imageUrl: string;
}

export interface SavedAccountSlot {
  userId: number;
  name: string;
  email: string;
  role: UserRole;
  token: string;
}
