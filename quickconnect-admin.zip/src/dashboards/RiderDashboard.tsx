import { Check, MapPin, Navigation, Power } from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { LiveTrackingMap } from '../components/LiveTrackingMap';
import { apiRequest } from '../lib/api';
import type { SessionData } from '../types';

interface RiderDashboardProps {
  session: SessionData;
  refreshTick: number;
  onSessionRefresh: () => Promise<void>;
}

const NEXT_STATUS_ACTION: Record<string, { next: string; label: string }> = {
  ACCEPTED: { next: 'ARRIVED_AT_SHOP', label: 'Mark Arrived at Shop' },
  ARRIVED_AT_SHOP: { next: 'PICKED_UP', label: 'Confirm Order Picked Up' },
  PICKED_UP: { next: 'ON_THE_WAY', label: 'Start Journey (On the Way)' },
  ON_THE_WAY: { next: 'ARRIVED_AT_CUSTOMER', label: 'Mark Arrived at Customer' },
  ARRIVED_AT_CUSTOMER: { next: 'DELIVERED', label: 'Complete Delivery' },
};

export function RiderDashboard({ session, refreshTick, onSessionRefresh }: RiderDashboardProps) {
  const [data, setData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'ACTIVE' | 'MAP' | 'HISTORY' | 'PROFILE'>('ACTIVE');
  const [notice, setNotice] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Real Browser Geolocation watcher
  const [gpsSharing, setGpsSharing] = useState(false);
  const [gpsStatus, setGpsStatus] = useState('Inactive');
  const watchIdRef = useRef<number | null>(null);

  // KYC / Capacity form
  const [cnic, setCnic] = useState('');
  const [vehicleType, setVehicleType] = useState('Motorcycle');
  const [vehiclePlate, setVehiclePlate] = useState('');
  const [city, setCity] = useState('Lahore');
  const [maxCapacity, setMaxCapacity] = useState('3');

  const loadDashboard = async () => {
    try {
      const res = await apiRequest('/api/rider/dashboard');
      setData(res);
      if (res.rider) {
        setCnic(res.rider.cnic);
        setVehicleType(res.rider.vehicle_type);
        setVehiclePlate(res.rider.vehicle_plate);
        setCity(res.rider.city);
        setMaxCapacity(String(res.rider.max_capacity));
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to load Rider dashboard.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboard();
  }, [refreshTick]);

  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  const flash = (msg: string, isErr = false) => {
    if (isErr) {
      setErrorMsg(msg);
      setNotice('');
    } else {
      setNotice(msg);
      setErrorMsg('');
      setTimeout(() => setNotice(''), 3500);
    }
  };

  const toggleOnline = async () => {
    if (!data?.rider) return;
    try {
      const next = !data.rider.is_online;
      await apiRequest('/api/rider/online', {
        method: 'POST',
        body: JSON.stringify({ isOnline: next }),
      });
      await loadDashboard();
      flash(next ? 'You are now Online and eligible for Smart Dispatch!' : 'You are now Offline.');
    } catch (err) {
      flash(err instanceof Error ? err.message : 'Could not change online state.', true);
    }
  };

  const toggleLiveGps = () => {
    if (gpsSharing) {
      if (watchIdRef.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
      watchIdRef.current = null;
      setGpsSharing(false);
      setGpsStatus('Stopped');
      return;
    }

    if (!navigator.geolocation) {
      setGpsStatus('Geolocation API unsupported in this browser');
      return;
    }

    setGpsStatus('Requesting device GPS permission...');
    const id = navigator.geolocation.watchPosition(
      async (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(6));
        const lng = Number(pos.coords.longitude.toFixed(6));
        setGpsSharing(true);
        setGpsStatus(`Sharing live GPS (${lat.toFixed(4)}, ${lng.toFixed(4)})`);
        try {
          await apiRequest('/api/rider/location', {
            method: 'POST',
            body: JSON.stringify({ lat, lng }),
          });
          await loadDashboard();
        } catch {
          // Ignore transient network blip
        }
      },
      () => {
        setGpsSharing(false);
        setGpsStatus('Browser GPS permission blocked — use manual check-in pin on Live Map tab');
      },
      { enableHighAccuracy: true, maximumAge: 5000 }
    );
    watchIdRef.current = id;
  };

  const handleRespondOffer = async (subOrderId: number, decision: 'ACCEPT' | 'REJECT') => {
    try {
      const res = await apiRequest<{ message: string }>(`/api/rider/assignments/${subOrderId}/respond`, {
        method: 'POST',
        body: JSON.stringify({ decision }),
      });
      await loadDashboard();
      flash(res.message);
    } catch (err) {
      flash(err instanceof Error ? err.message : 'Response failed.', true);
    }
  };

  const handleAdvanceStatus = async (subOrderId: number, status: string) => {
    try {
      const res = await apiRequest<{ message: string }>(`/api/rider/suborders/${subOrderId}/status`, {
        method: 'POST',
        body: JSON.stringify({ status }),
      });
      await loadDashboard();
      flash(res.message);
    } catch (err) {
      flash(err instanceof Error ? err.message : 'Could not update delivery status.', true);
    }
  };

  const handleUpdateApplication = async (e: React.FormEvent, resubmit = false) => {
    e.preventDefault();
    try {
      await apiRequest('/api/rider/application', {
        method: 'PUT',
        body: JSON.stringify({
          cnic,
          vehicleType,
          vehiclePlate,
          city,
          maxCapacity: Number(maxCapacity),
          resubmitForApproval: resubmit,
        }),
      });
      await onSessionRefresh();
      await loadDashboard();
      flash(resubmit ? 'Rider verification resubmitted for Admin approval!' : 'Rider profile saved.');
    } catch (err) {
      flash(err instanceof Error ? err.message : 'Save failed.', true);
    }
  };

  if (loading) {
    return <div className="max-w-4xl mx-auto p-8 text-sm text-slate-500">Loading Rider Dashboard...</div>;
  }

  const rider = data?.rider;

  // MANDATORY APPROVAL GATE: Newly registered Riders wait for Admin approval before joining the fleet!
  if (!rider || rider.approval_status !== 'APPROVED') {
    return (
      <div className="max-w-2xl mx-auto px-4 sm:px-8 py-12">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 space-y-5">
          <div className="flex items-center justify-between gap-2 pb-4 border-b border-slate-100">
            <div>
              <p className="text-xs font-medium text-amber-700">
                Rider Identity Verification: {rider?.approval_status || 'PENDING'}
              </p>
              <h1 className="font-display text-2xl font-bold text-slate-900 mt-1">
                {rider?.approval_status === 'REJECTED'
                  ? 'Rider Verification Requires Update'
                  : rider?.approval_status === 'SUSPENDED'
                  ? 'Rider Account Suspended'
                  : 'Awaiting DELIVOO Admin Approval'}
              </h1>
            </div>
            <button
              type="button"
              onClick={loadDashboard}
              className="px-3.5 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:border-emerald-500"
            >
              Refresh Status
            </button>
          </div>

          <p className="text-sm text-slate-600 leading-relaxed">
            Your Rider registration ({rider?.vehicle_type} · <span className="font-mono">{rider?.vehicle_plate}</span>)
            has been submitted. As soon as a DELIVOO Administrator verifies and approves your profile, your Online
            dispatch toggle and live deliveries will automatically unlock here.
          </p>

          {rider?.rejection_reason && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-800">
              <strong>Admin Feedback:</strong> {rider.rejection_reason}
            </div>
          )}

          {notice && <div className="p-3 rounded-xl bg-emerald-50 text-sm text-emerald-800">{notice}</div>}
          {errorMsg && <div className="p-3 rounded-xl bg-rose-50 text-sm text-rose-700">{errorMsg}</div>}

          <form onSubmit={(e) => handleUpdateApplication(e, true)} className="space-y-4 pt-2">
            <h2 className="text-sm font-semibold text-slate-900">Submitted Rider KYC & Vehicle Details</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">CNIC Number</label>
                <input
                  type="text"
                  required
                  value={cnic}
                  onChange={(e) => setCnic(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Vehicle Plate</label>
                <input
                  type="text"
                  required
                  value={vehiclePlate}
                  onChange={(e) => setVehiclePlate(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono uppercase"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Vehicle Type</label>
                <select
                  value={vehicleType}
                  onChange={(e) => setVehicleType(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  <option value="Motorcycle">Motorcycle</option>
                  <option value="Scooter">Scooter</option>
                  <option value="Bicycle">Bicycle</option>
                  <option value="Car">Car</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">City</label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700"
            >
              {rider?.approval_status === 'REJECTED'
                ? 'Update & Resubmit for Admin Approval'
                : 'Save Verification Details'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  const firstActive = data.activeDeliveries?.[0] || null;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-8 py-6 space-y-6">
      {/* RIDER HEADER & ONLINE TOGGLE */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs text-slate-500 flex items-center gap-2 tabular-nums">
            <span>Verified Rider</span>
            <span>·</span>
            <span className="font-mono">{rider.vehicle_plate}</span>
            <span>·</span>
            <span>
              Workload: {rider.active_deliveries}/{rider.max_capacity}
            </span>
            <span>·</span>
            <span>Rating: {Number(rider.rating_avg).toFixed(1)}★</span>
          </div>
          <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900 mt-0.5">
            {session.user.name}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">GPS Telemetry: {gpsStatus}</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={toggleLiveGps}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border text-xs font-semibold transition-colors ${
              gpsSharing
                ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
                : 'border-slate-300 text-slate-700 hover:border-emerald-500'
            }`}
          >
            <Navigation className="w-3.5 h-3.5" />
            {gpsSharing ? 'Stop GPS Sharing' : 'Share Real Device GPS'}
          </button>

          <button
            type="button"
            onClick={toggleOnline}
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-colors ${
              rider.is_online
                ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                : 'bg-slate-200 text-slate-800 hover:bg-slate-300'
            }`}
          >
            <Power className="w-4 h-4" />
            {rider.is_online ? 'ONLINE — Receiving Requests' : 'OFFLINE — Go Online'}
          </button>
        </div>
      </div>

      {/* RIDER TABS */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl overflow-x-auto">
        {(
          [
            ['ACTIVE', `Active & Requests (${data.activeDeliveries.length})`],
            ['MAP', 'Live Route & GPS Check-In'],
            ['HISTORY', `Earnings & History (PKR ${Number(rider.total_earnings).toLocaleString()})`],
            ['PROFILE', 'Capacity & Vehicle'],
          ] as const
        ).map(([k, label]) => (
          <button
            key={k}
            type="button"
            onClick={() => setTab(k)}
            className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              tab === k ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {notice && (
        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-sm text-emerald-800">
          {notice}
        </div>
      )}
      {errorMsg && (
        <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-700">
          {errorMsg}
        </div>
      )}

      {/* TAB 1: ACTIVE DELIVERIES & DISPATCH OFFERS */}
      {tab === 'ACTIVE' && (
        <div className="space-y-4">
          {data.activeDeliveries.length === 0 ? (
            <div className="p-10 rounded-2xl border border-slate-200 text-center text-sm text-slate-500">
              {rider.is_online
                ? 'You are Online. New nearby shop sub-orders within your capacity will appear here automatically.'
                : 'Switch to Online above to receive delivery requests.'}
            </div>
          ) : (
            data.activeDeliveries.map((d: any) => {
              const nextStep = NEXT_STATUS_ACTION[d.delivery_status];
              return (
                <div key={d.id} className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
                  <div className="flex flex-wrap items-start justify-between gap-4 pb-3 border-b border-slate-100">
                    <div>
                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <span className="font-mono font-bold text-slate-900 text-sm">{d.sub_order_number}</span>
                        <span>·</span>
                        <span>Current Stage: {d.delivery_status.replace(/_/g, ' ')}</span>
                        <span>·</span>
                        <span>Payment: {d.payment_method}</span>
                      </div>
                      <div className="mt-2 space-y-1 text-sm">
                        <div>
                          <strong className="text-slate-900">Pickup:</strong> {d.shop_name} — {d.shop_address}
                        </div>
                        <div>
                          <strong className="text-slate-900">Dropoff:</strong> {d.customer_name} —{' '}
                          {d.delivery_address}, {d.delivery_city} ({d.contact_phone})
                        </div>
                      </div>
                    </div>

                    <div className="text-right tabular-nums">
                      <div className="text-xs text-slate-500">Rider Payout</div>
                      <div className="font-mono text-lg font-bold text-emerald-700">
                        PKR {Number(d.earning_amount || 110).toLocaleString()}
                      </div>
                    </div>
                  </div>

                  {/* 7-Stage Progression Controls */}
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="text-xs text-slate-500">
                      Items: {d.items.map((i: any) => `${i.quantity}x ${i.product_name}`).join(', ')}
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {d.delivery_status === 'ASSIGNED' && (
                        <>
                          <button
                            type="button"
                            onClick={() => handleRespondOffer(d.id, 'ACCEPT')}
                            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
                          >
                            <Check className="w-4 h-4" />
                            Accept Delivery
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRespondOffer(d.id, 'REJECT')}
                            className="px-4 py-2 rounded-xl border border-rose-200 text-rose-700 text-xs font-semibold hover:bg-rose-50"
                          >
                            Decline
                          </button>
                        </>
                      )}

                      {nextStep && (
                        <button
                          type="button"
                          onClick={() => handleAdvanceStatus(d.id, nextStep.next)}
                          className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
                        >
                          {nextStep.label}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB 2: LIVE MAP & REAL LOCATION CHECK-IN */}
      {tab === 'MAP' && (
        <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900">Live Route & Rider Location</h2>
              <p className="text-xs text-slate-500">
                Tap "Share Real Device GPS" above for continuous browser geolocation, or tap the map to check in your
                exact position if geolocation permission is restricted in an iframe.
              </p>
            </div>
            {rider.current_lat && (
              <span className="text-xs font-mono text-slate-600 tabular-nums">
                <MapPin className="w-3.5 h-3.5 inline text-emerald-600 mr-1" />
                {Number(rider.current_lat).toFixed(4)}, {Number(rider.current_lng).toFixed(4)}
              </span>
            )}
          </div>

          <LiveTrackingMap
            shopPoint={
              firstActive
                ? { lat: firstActive.shop_lat, lng: firstActive.shop_lng, label: firstActive.shop_name }
                : null
            }
            customerPoint={
              firstActive?.delivery_lat && firstActive?.delivery_lng
                ? {
                    lat: firstActive.delivery_lat,
                    lng: firstActive.delivery_lng,
                    label: firstActive.delivery_address,
                  }
                : null
            }
            riderPoint={
              rider.current_lat && rider.current_lng
                ? {
                    lat: rider.current_lat,
                    lng: rider.current_lng,
                    label: session.user.name,
                    lastGpsAt: rider.last_gps_at,
                  }
                : null
            }
            onSelectPin={async (lat, lng) => {
              try {
                await apiRequest('/api/rider/location', {
                  method: 'POST',
                  body: JSON.stringify({ lat, lng }),
                });
                await loadDashboard();
                flash(`Updated rider position (${lat.toFixed(4)}, ${lng.toFixed(4)})`);
              } catch (err) {
                flash(err instanceof Error ? err.message : 'GPS update failed', true);
              }
            }}
            heightClass="h-80"
          />
        </div>
      )}

      {/* TAB 3: EARNINGS & COMPLETED HISTORY */}
      {tab === 'HISTORY' && (
        <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-display text-lg font-bold text-slate-900">Completed Deliveries</h2>
            <span className="font-mono text-base font-bold text-emerald-700 tabular-nums">
              Total Verified Earnings: PKR {Number(rider.total_earnings).toLocaleString()}
            </span>
          </div>
          {data.deliveryHistory.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">No completed deliveries yet.</div>
          ) : (
            <div className="divide-y divide-slate-100 tabular-nums">
              {data.deliveryHistory.map((h: any) => (
                <div key={h.id} className="px-6 py-3.5 flex items-center justify-between gap-4 text-sm">
                  <div>
                    <div className="font-mono font-semibold text-slate-900">{h.sub_order_number}</div>
                    <div className="text-xs text-slate-500">
                      {h.shop_name} → {h.delivery_address}
                    </div>
                  </div>
                  <div className="font-mono font-semibold text-emerald-700">
                    + PKR {Number(h.earning_amount).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: CAPACITY & VEHICLE */}
      {tab === 'PROFILE' && (
        <form
          onSubmit={(e) => handleUpdateApplication(e, false)}
          className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4 max-w-xl"
        >
          <h2 className="font-display text-lg font-bold text-slate-900">Dispatch Capacity & Vehicle Details</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Max Concurrent Orders</label>
              <select
                value={maxCapacity}
                onChange={(e) => setMaxCapacity(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                <option value="1">1 Active Order</option>
                <option value="2">2 Active Orders</option>
                <option value="3">3 Active Orders</option>
                <option value="4">4 Active Orders</option>
                <option value="5">5 Active Orders</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Vehicle Plate</label>
              <input
                type="text"
                value={vehiclePlate}
                onChange={(e) => setVehiclePlate(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono uppercase"
              />
            </div>
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700"
          >
            Save Capacity Settings
          </button>
        </form>
      )}
    </div>
  );
}
