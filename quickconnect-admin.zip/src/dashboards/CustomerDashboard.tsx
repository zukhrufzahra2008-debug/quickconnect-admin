import { Check, MapPin, Minus, Plus, Search, ShoppingBag, Star, Trash2, Truck, X } from 'lucide-react';
import React, { useEffect, useMemo, useState } from 'react';
import { LiveTrackingMap } from '../components/LiveTrackingMap';
import { apiRequest } from '../lib/api';
import type { CartItem, CatalogProduct, SessionData, ShopProfile } from '../types';

interface CustomerDashboardProps {
  session: SessionData;
  refreshTick: number;
}

export function CustomerDashboard({ session, refreshTick }: CustomerDashboardProps) {
  const [activeTab, setActiveTab] = useState<'DISCOVER' | 'CART' | 'ORDERS'>('DISCOVER');
  const [loadingCatalog, setLoadingCatalog] = useState(true);
  const [shops, setShops] = useState<ShopProfile[]>([]);
  const [products, setProducts] = useState<CatalogProduct[]>([]);
  const [categories, setCategories] = useState<{ id: number; name: string }[]>([]);
  const [coupons, setCoupons] = useState<any[]>([]);

  // Discovery filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedShopId, setSelectedShopId] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<'RATING' | 'DISTANCE' | 'DELIVERY_FEE'>('RATING');
  const [customerCoords, setCustomerCoords] = useState<{ lat: number; lng: number }>(() => {
    const def = session.addresses?.[0];
    return {
      lat: def?.lat ?? 31.5125,
      lng: def?.lng ?? 74.3465,
    };
  });

  // Product modal
  const [detailProduct, setDetailProduct] = useState<any | null>(null);
  const [selectedVariantId, setSelectedVariantId] = useState<number | null>(null);
  const [detailQty, setDetailQty] = useState(1);

  // Multi-shop cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(`delivoo_cart_${session.user.id}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [couponInput, setCouponInput] = useState('');
  const [cartSummary, setCartSummary] = useState<any | null>(null);
  const [cartError, setCartError] = useState('');

  // Checkout state
  const [deliveryAddress, setDeliveryAddress] = useState(
    session.addresses?.[0]?.address_line || 'House 42-B, Main Boulevard Gulberg III'
  );
  const [deliveryCity, setDeliveryCity] = useState(session.addresses?.[0]?.city || 'Lahore');
  const [contactPhone, setContactPhone] = useState(session.user.phone || '+923214567890');
  const [deliveryInstructions, setDeliveryInstructions] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'EASYPAISA' | 'JAZZCASH' | 'CARD'>('COD');
  const [checkoutBusy, setCheckoutBusy] = useState(false);
  const [toastMsg, setToastMsg] = useState('');

  // Online payment verification modal
  const [pendingPaymentChallenge, setPendingPaymentChallenge] = useState<{
    orderNumber: string;
    transactionRef: string;
    method: string;
    amount: number;
  } | null>(null);
  const [walletNumber, setWalletNumber] = useState('03001234567');

  // Orders & Tracking
  const [orders, setOrders] = useState<any[]>([]);
  const [expandedMapSubId, setExpandedMapSubId] = useState<number | null>(null);
  const [refundModalSub, setRefundModalSub] = useState<any | null>(null);
  const [refundReason, setRefundReason] = useState('');
  const [refundAmount, setRefundAmount] = useState('');
  const [reviewModalSub, setReviewModalSub] = useState<any | null>(null);
  const [reviewTarget, setReviewTarget] = useState<'SHOP' | 'RIDER' | 'PRODUCT'>('SHOP');
  const [reviewProductId, setReviewProductId] = useState<number | null>(null);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');

  useEffect(() => {
    try {
      localStorage.setItem(`delivoo_cart_${session.user.id}`, JSON.stringify(cart));
    } catch {
      // Ignore storage error
    }
  }, [cart, session.user.id]);

  const loadCatalog = async () => {
    try {
      const res = await apiRequest<{
        categories: any[];
        shops: ShopProfile[];
        products: CatalogProduct[];
        coupons: any[];
      }>(`/api/marketplace/catalog?lat=${customerCoords.lat}&lng=${customerCoords.lng}`);
      setCategories(res.categories || []);
      setShops(res.shops || []);
      setProducts(res.products || []);
      setCoupons(res.coupons || []);
    } catch {
      // Keep previous catalog state on transient error
    } finally {
      setLoadingCatalog(false);
    }
  };

  const loadOrders = async () => {
    try {
      const res = await apiRequest<{ orders: any[] }>('/api/marketplace/orders');
      setOrders(res.orders || []);
    } catch {
      // Ignore
    }
  };

  useEffect(() => {
    loadCatalog();
    loadOrders();
  }, [refreshTick, customerCoords.lat, customerCoords.lng]);

  // Re-validate cart on backend whenever cart or coupon changes
  useEffect(() => {
    if (cart.length === 0) {
      setCartSummary(null);
      setCartError('');
      return;
    }
    const payloadItems = cart.map((c) => ({
      productId: c.productId,
      variantId: c.variantId,
      quantity: c.quantity,
    }));
    apiRequest('/api/marketplace/validate-cart', {
      method: 'POST',
      body: JSON.stringify({ items: payloadItems, couponCode: couponInput }),
    })
      .then((res) => {
        setCartSummary(res);
        setCartError('');
      })
      .catch((err) => {
        setCartError(err instanceof Error ? err.message : 'Cart validation warning');
      });
  }, [cart, couponInput]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 3200);
  };

  const openProductDetail = async (p: CatalogProduct) => {
    try {
      const full = await apiRequest(`/api/marketplace/products/${p.id}`);
      setDetailProduct(full);
      setSelectedVariantId(full.variants?.[0]?.id ?? null);
      setDetailQty(1);
    } catch {
      setDetailProduct(p);
      setSelectedVariantId(p.variants?.[0]?.id ?? null);
      setDetailQty(1);
    }
  };

  const addToCart = (prod: CatalogProduct | any, qty = 1, variantId: number | null = null) => {
    if (!prod.available) {
      showToast(`Unavailable: ${prod.availabilityReason}`);
      return;
    }
    const chosenVariant =
      variantId && prod.variants
        ? prod.variants.find((v: any) => v.id === variantId)
        : prod.variants?.[0] || null;
    const vId = chosenVariant ? chosenVariant.id : null;
    const vName = chosenVariant ? chosenVariant.name : '';
    const unitPrice = Math.max(0, Number(prod.effectivePrice) + Number(chosenVariant?.price_delta || 0));
    const maxStock = chosenVariant
      ? Math.min(prod.stock_quantity, chosenVariant.stock_quantity)
      : prod.stock_quantity;

    const key = `${prod.id}-${vId || 0}`;
    setCart((prev) => {
      const existing = prev.find((i) => i.key === key);
      if (existing) {
        return prev.map((i) =>
          i.key === key ? { ...i, quantity: Math.min(maxStock, i.quantity + qty) } : i
        );
      }
      return [
        ...prev,
        {
          key,
          productId: prod.id,
          variantId: vId,
          variantName: vName,
          productName: prod.name,
          shopId: prod.shop_id,
          shopName: prod.shopName || prod.shop_name,
          unitPrice,
          quantity: Math.min(maxStock, qty),
          maxStock,
          imageUrl: prod.image_url,
        },
      ];
    });
    showToast(`Added "${prod.name}" to multi-shop cart`);
  };

  const updateCartQty = (key: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.key !== key) return item;
          const next = item.quantity + delta;
          return next <= 0 ? null : { ...item, quantity: Math.min(item.maxStock, next) };
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const detectCustomerGps = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCustomerCoords({
          lat: Number(pos.coords.latitude.toFixed(6)),
          lng: Number(pos.coords.longitude.toFixed(6)),
        });
        showToast('Updated delivery GPS coordinates');
      },
      () => showToast('GPS permission unavailable; tap map pin to set exact coordinates')
    );
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0 || checkoutBusy) return;
    setCheckoutBusy(true);
    setCartError('');
    try {
      const idempotencyKey = `chk-${session.user.id}-${Date.now()}`;
      const res = await apiRequest<{
        parentOrderId: number;
        orderNumber: string;
        totalAmount: number;
        paymentMethod: string;
        paymentStatus: string;
        transactionRef: string;
      }>('/api/marketplace/checkout', {
        method: 'POST',
        body: JSON.stringify({
          items: cart.map((c) => ({
            productId: c.productId,
            variantId: c.variantId,
            quantity: c.quantity,
          })),
          couponCode: couponInput,
          deliveryAddress,
          deliveryCity,
          deliveryLat: customerCoords.lat,
          deliveryLng: customerCoords.lng,
          contactPhone,
          deliveryInstructions,
          paymentMethod,
          idempotencyKey,
        }),
      });

      setCart([]);
      setCouponInput('');
      await loadOrders();
      await loadCatalog();

      if (paymentMethod !== 'COD') {
        setPendingPaymentChallenge({
          orderNumber: res.orderNumber,
          transactionRef: res.transactionRef,
          method: paymentMethod,
          amount: res.totalAmount,
        });
      } else {
        setActiveTab('ORDERS');
        showToast(`Order ${res.orderNumber} placed! Track each shop sub-order below.`);
      }
    } catch (err) {
      setCartError(err instanceof Error ? err.message : 'Checkout failed.');
    } finally {
      setCheckoutBusy(false);
    }
  };

  const handleAuthorizeOnlinePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pendingPaymentChallenge) return;
    try {
      await apiRequest('/api/marketplace/payments/authorize-online', {
        method: 'POST',
        body: JSON.stringify({
          transactionRef: pendingPaymentChallenge.transactionRef,
          walletAccount: walletNumber,
        }),
      });
      const ordNum = pendingPaymentChallenge.orderNumber;
      setPendingPaymentChallenge(null);
      await loadOrders();
      setActiveTab('ORDERS');
      showToast(`Payment verified via backend HMAC for ${ordNum}!`);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Payment authorization failed.');
    }
  };

  const handleCancelSubOrder = async (subOrderId: number) => {
    try {
      const res = await apiRequest<{ message: string }>(`/api/marketplace/suborders/${subOrderId}/cancel`, {
        method: 'POST',
        body: JSON.stringify({ reason: 'Customer cancelled sub-order from order tracker' }),
      });
      await loadOrders();
      await loadCatalog();
      showToast(res.message);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Could not cancel sub-order.');
    }
  };

  const handleSubmitRefund = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!refundModalSub) return;
    try {
      const res = await apiRequest<{ message: string }>(
        `/api/marketplace/suborders/${refundModalSub.id}/refund`,
        {
          method: 'POST',
          body: JSON.stringify({
            reason: refundReason,
            requestedAmount: Number(refundAmount || refundModalSub.payable_amount),
          }),
        }
      );
      setRefundModalSub(null);
      setRefundReason('');
      await loadOrders();
      showToast(res.message);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Refund request failed.');
    }
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewModalSub) return;
    try {
      const res = await apiRequest<{ message: string }>('/api/marketplace/reviews', {
        method: 'POST',
        body: JSON.stringify({
          shopOrderId: reviewModalSub.id,
          targetType: reviewTarget,
          productId: reviewTarget === 'PRODUCT' ? reviewProductId : null,
          rating: reviewRating,
          comment: reviewComment,
        }),
      });
      setReviewModalSub(null);
      setReviewComment('');
      await loadOrders();
      await loadCatalog();
      showToast(res.message);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Could not submit review.');
    }
  };

  const filteredShops = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return shops
      .filter((s) => {
        if (selectedCategory !== 'ALL' && s.category_name !== selectedCategory) return false;
        if (q && !s.name.toLowerCase().includes(q) && !s.description.toLowerCase().includes(q)) {
          const shopHasMatchingProd = products.some(
            (p) => p.shop_id === s.id && p.name.toLowerCase().includes(q)
          );
          if (!shopHasMatchingProd) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'DISTANCE') return (a.distanceKm ?? 99) - (b.distanceKm ?? 99);
        if (sortBy === 'DELIVERY_FEE') return a.delivery_fee - b.delivery_fee;
        return b.rating_avg - a.rating_avg;
      });
  }, [shops, products, searchQuery, selectedCategory, sortBy]);

  const filteredProducts = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return products.filter((p) => {
      if (selectedShopId && p.shop_id !== selectedShopId) return false;
      if (selectedCategory !== 'ALL' && p.category_name !== selectedCategory) return false;
      if (
        q &&
        !p.name.toLowerCase().includes(q) &&
        !p.shopName.toLowerCase().includes(q) &&
        !p.brand.toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });
  }, [products, searchQuery, selectedCategory, selectedShopId]);

  const totalCartItems = cart.reduce((s, i) => s + i.quantity, 0);

  // Group cart items by shop for UI
  const cartGroups = useMemo(() => {
    const map = new Map<number, { shopId: number; shopName: string; items: CartItem[] }>();
    for (const item of cart) {
      const g = map.get(item.shopId) || { shopId: item.shopId, shopName: item.shopName, items: [] };
      g.items.push(item);
      map.set(item.shopId, g);
    }
    return Array.from(map.values());
  }, [cart]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 space-y-8">
      {toastMsg && (
        <div className="fixed top-20 right-5 z-40 rounded-xl bg-slate-900 text-white px-4 py-2.5 text-sm shadow-lg">
          {toastMsg}
        </div>
      )}

      {/* ROLE NAVIGATION BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveTab('DISCOVER')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'DISCOVER' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Discover Shops
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('CART')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap tabular-nums ${
              activeTab === 'CART' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Multi-Shop Cart ({totalCartItems})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ORDERS')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap tabular-nums ${
              activeTab === 'ORDERS' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            My Orders ({orders.length})
          </button>
        </div>

        <button
          type="button"
          onClick={detectCustomerGps}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-emerald-700 whitespace-nowrap"
        >
          <MapPin className="w-4 h-4 text-emerald-600" />
          <span>Delivering to {deliveryCity}</span>
          <span>·</span>
          <span className="underline">Update GPS</span>
        </button>
      </div>

      {/* TAB 1: DISCOVER SHOPS & PRODUCTS */}
      {activeTab === 'DISCOVER' && (
        <div className="space-y-8">
          {/* Search, Sort & Offers */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search approved shops, groceries, meals, bakery, pharmacy..."
                  className="w-full rounded-xl border border-slate-300 pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-emerald-600"
                />
              </div>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm bg-white text-slate-700 shrink-0"
              >
                <option value="RATING">Sort: Highest Rated</option>
                <option value="DISTANCE">Sort: Nearest Distance</option>
                <option value="DELIVERY_FEE">Sort: Lowest Delivery Fee</option>
              </select>
            </div>

            {/* Category Filter Bar */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              <button
                type="button"
                onClick={() => {
                  setSelectedCategory('ALL');
                  setSelectedShopId(null);
                }}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  selectedCategory === 'ALL'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                All Categories
              </button>
              {categories.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => {
                    setSelectedCategory(c.name);
                    setSelectedShopId(null);
                  }}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    selectedCategory === c.name
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>

            {/* Slim Dismissible / Clean Available Offers Line */}
            {coupons.length > 0 && (
              <div className="py-2.5 px-4 rounded-xl bg-emerald-50/70 border border-emerald-200/70 flex flex-wrap items-center justify-between gap-2 text-xs text-emerald-950">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-semibold">Available Marketplace Vouchers:</span>
                  {coupons.slice(0, 3).map((cp, i) => (
                    <React.Fragment key={cp.code}>
                      {i > 0 && <span>·</span>}
                      <button
                        type="button"
                        onClick={() => {
                          setCouponInput(cp.code);
                          showToast(`Applied voucher code ${cp.code} to your cart`);
                        }}
                        className="font-mono font-semibold text-emerald-700 hover:underline"
                      >
                        {cp.code} (
                        {cp.discount_type === 'PERCENTAGE'
                          ? `${cp.discount_value}% off`
                          : `PKR ${cp.discount_value} off`}{' '}
                        min PKR {cp.min_order_amount})
                      </button>
                    </React.Fragment>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* SECTION A: NEARBY APPROVED SHOPS */}
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold text-slate-900">
                {selectedShopId
                  ? `Browsing Shop: ${shops.find((s) => s.id === selectedShopId)?.name}`
                  : 'Verified Shops Near You'}
              </h2>
              {selectedShopId && (
                <button
                  type="button"
                  onClick={() => setSelectedShopId(null)}
                  className="text-xs font-semibold text-emerald-700 hover:underline"
                >
                  Show all shops
                </button>
              )}
            </div>

            {loadingCatalog ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3].map((n) => (
                  <div key={n} className="h-56 rounded-2xl bg-slate-100 animate-pulse" />
                ))}
              </div>
            ) : filteredShops.length === 0 ? (
              <div className="p-8 rounded-2xl border border-slate-200 text-center text-sm text-slate-500">
                No approved shops match your current search or category filter.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredShops.map((shop) => {
                  const isSelected = selectedShopId === shop.id;
                  return (
                    <div
                      key={shop.id}
                      onClick={() => setSelectedShopId(isSelected ? null : shop.id)}
                      className={`cursor-pointer group rounded-2xl border transition-all overflow-hidden bg-white ${
                        isSelected
                          ? 'border-emerald-600 shadow-sm'
                          : 'border-slate-200 hover:border-emerald-400 hover:-translate-y-0.5'
                      }`}
                    >
                      <div className="aspect-[16/9] bg-slate-50 overflow-hidden">
                        <img
                          src={shop.cover_url}
                          alt={shop.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="p-4 space-y-1.5">
                        <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                          <span>{shop.category_name}</span>
                          <span>·</span>
                          <span className={shop.isOpen ? 'text-emerald-700 font-medium' : 'text-rose-600 font-medium'}>
                            {shop.isOpen
                              ? `Open (${shop.opening_time}–${shop.closing_time})`
                              : 'Closed'}
                          </span>
                        </div>
                        <h3 className="font-display text-base font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                          {shop.name}
                        </h3>
                        <p className="text-xs text-slate-600 line-clamp-1">{shop.description}</p>
                        <div className="pt-2 flex items-center gap-2 text-xs text-slate-600 tabular-nums">
                          <span className="inline-flex items-center gap-1 font-medium text-slate-800">
                            <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                            {shop.rating_avg.toFixed(1)}
                          </span>
                          <span>·</span>
                          <span>{shop.estimatedDeliveryMins} mins</span>
                          <span>·</span>
                          <span>Delivery PKR {shop.delivery_fee}</span>
                          {shop.distanceKm !== null && shop.distanceKm !== undefined && (
                            <>
                              <span>·</span>
                              <span>{shop.distanceKm} km</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* SECTION B: FEATURED & AVAILABLE PRODUCTS */}
          <section className="space-y-4">
            <h2 className="font-display text-xl font-bold text-slate-900">
              {selectedShopId ? 'Shop Catalog' : 'Products Across Approved Shops'}
            </h2>

            {filteredProducts.length === 0 ? (
              <div className="p-8 rounded-2xl border border-slate-200 text-center text-sm text-slate-500">
                No products match your current filter.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((prod) => (
                  <div
                    key={prod.id}
                    className="rounded-2xl border border-slate-200 bg-white overflow-hidden flex flex-col hover:-translate-y-0.5 transition-transform"
                  >
                    <button
                      type="button"
                      onClick={() => openProductDetail(prod)}
                      className="aspect-[4/3] bg-slate-50 overflow-hidden text-left"
                    >
                      <img
                        src={prod.image_url}
                        alt={prod.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </button>
                    <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                      <div>
                        <div className="text-xs text-slate-500 flex items-center gap-1.5">
                          <span className="truncate">{prod.shopName}</span>
                          <span>·</span>
                          <span>{prod.category_name}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => openProductDetail(prod)}
                          className="mt-1 text-left font-display text-base font-semibold text-slate-900 hover:text-emerald-700 line-clamp-2"
                        >
                          {prod.name}
                        </button>
                        <div className="mt-1 text-xs text-slate-500 tabular-nums">
                          {prod.available ? (
                            <span>
                              Stock: {prod.stock_quantity}
                              {prod.activeScheduleLabel ? ` · ${prod.activeScheduleLabel}` : ''}
                            </span>
                          ) : (
                            <span className="text-rose-600 font-medium">{prod.availabilityReason}</span>
                          )}
                        </div>
                      </div>

                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                        <div className="tabular-nums">
                          <span className="font-mono text-base font-bold text-slate-900">
                            PKR {prod.effectivePrice.toLocaleString()}
                          </span>
                          {prod.original_price > prod.effectivePrice && (
                            <span className="ml-2 font-mono text-xs text-slate-400 line-through">
                              PKR {prod.original_price.toLocaleString()}
                            </span>
                          )}
                        </div>
                        <button
                          type="button"
                          disabled={!prod.available}
                          onClick={() =>
                            prod.variants.length > 0 ? openProductDetail(prod) : addToCart(prod, 1, null)
                          }
                          className="px-3.5 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 disabled:bg-slate-200 disabled:text-slate-500 transition-colors whitespace-nowrap shrink-0"
                        >
                          {prod.variants.length > 0 ? 'Select Option' : 'Add to Cart'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}

      {/* TAB 2: MULTI-SHOP CART & CHECKOUT */}
      {activeTab === 'CART' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 space-y-6">
            <h2 className="font-display text-2xl font-bold text-slate-900">
              Multi-Shop Shopping Cart
            </h2>
            {cartGroups.length === 0 ? (
              <div className="p-10 rounded-2xl border border-slate-200 text-center space-y-4">
                <ShoppingBag className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-sm text-slate-600">
                  Your cart is empty. Add items from one or multiple approved shops into a single checkout!
                </p>
                <button
                  type="button"
                  onClick={() => setActiveTab('DISCOVER')}
                  className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700"
                >
                  Browse Approved Shops
                </button>
              </div>
            ) : (
              <div className="space-y-5">
                <p className="text-xs text-slate-500">
                  Ordering from {cartGroups.length} shop(s). Checkout will create 1 Parent Order with{' '}
                  {cartGroups.length} independent Shop Sub-Order(s).
                </p>
                {cartGroups.map((group, idx) => {
                  const groupSubtotal = group.items.reduce(
                    (s, it) => s + it.unitPrice * it.quantity,
                    0
                  );
                  return (
                    <div key={group.shopId} className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
                      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                        <div>
                          <span className="text-xs text-slate-500">Sub-Order {String.fromCharCode(65 + idx)}</span>
                          <h3 className="font-display text-base font-bold text-slate-900">{group.shopName}</h3>
                        </div>
                        <span className="font-mono text-sm font-semibold text-slate-700 tabular-nums">
                          Subtotal: PKR {groupSubtotal.toLocaleString()}
                        </span>
                      </div>

                      <div className="divide-y divide-slate-100">
                        {group.items.map((it) => (
                          <div key={it.key} className="py-3 flex items-center justify-between gap-4">
                            <div className="min-w-0">
                              <div className="text-sm font-medium text-slate-900 truncate">{it.productName}</div>
                              <div className="text-xs text-slate-500 tabular-nums">
                                {it.variantName ? `${it.variantName} · ` : ''}PKR {it.unitPrice.toLocaleString()} each
                              </div>
                            </div>
                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                type="button"
                                onClick={() => updateCartQty(it.key, -1)}
                                className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="w-6 text-center font-mono text-sm tabular-nums">{it.quantity}</span>
                              <button
                                type="button"
                                onClick={() => updateCartQty(it.key, 1)}
                                className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => updateCartQty(it.key, -999)}
                                aria-label="Remove item"
                                className="p-1.5 text-slate-400 hover:text-rose-600"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* CHECKOUT PANEL */}
          {cart.length > 0 && (
            <form
              onSubmit={handlePlaceOrder}
              className="lg:col-span-5 rounded-2xl border border-slate-200 bg-white p-6 space-y-5"
            >
              <h3 className="font-display text-lg font-bold text-slate-900">Checkout & Verification</h3>

              {cartError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700">
                  {cartError}
                </div>
              )}

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Delivery Street Address *</label>
                  <input
                    type="text"
                    required
                    value={deliveryAddress}
                    onChange={(e) => setDeliveryAddress(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">City *</label>
                    <input
                      type="text"
                      required
                      value={deliveryCity}
                      onChange={(e) => setDeliveryCity(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Contact Phone *</label>
                    <input
                      type="tel"
                      required
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-medium text-slate-700">Pin Exact Delivery Coordinates</label>
                    <button
                      type="button"
                      onClick={detectCustomerGps}
                      className="text-xs text-emerald-700 hover:underline"
                    >
                      Use Browser GPS
                    </button>
                  </div>
                  <LiveTrackingMap
                    interactivePin={customerCoords}
                    onSelectPin={(lat, lng) => setCustomerCoords({ lat, lng })}
                    heightClass="h-40"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Delivery Instructions</label>
                  <input
                    type="text"
                    value={deliveryInstructions}
                    onChange={(e) => setDeliveryInstructions(e.target.value)}
                    placeholder="Gate code, landmark, or rider note..."
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Coupon Code</label>
                  <input
                    type="text"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                    placeholder="e.g. WELCOME10 or DELIVOO200"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono uppercase"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1.5">Payment Method</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(
                      [
                        ['COD', 'Cash on Delivery'],
                        ['EASYPAISA', 'Easypaisa'],
                        ['JAZZCASH', 'JazzCash'],
                        ['CARD', 'Debit / Credit Card'],
                      ] as const
                    ).map(([code, label]) => (
                      <button
                        key={code}
                        type="button"
                        onClick={() => setPaymentMethod(code)}
                        className={`py-2 px-3 rounded-lg border text-xs font-medium transition-colors text-left ${
                          paymentMethod === code
                            ? 'border-emerald-600 bg-emerald-50 text-emerald-900'
                            : 'border-slate-200 text-slate-700 hover:border-slate-300'
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Backend-Validated Financial Breakdown */}
              {cartSummary && (
                <div className="pt-4 border-t border-slate-100 space-y-1.5 text-sm tabular-nums">
                  <div className="flex justify-between text-slate-600">
                    <span>Items Subtotal ({cartSummary.groups.length} shop(s))</span>
                    <span className="font-mono">PKR {cartSummary.subtotalAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Shop-Wise Delivery Charges</span>
                    <span className="font-mono">PKR {cartSummary.deliveryTotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Applicable GST ({cartSummary.taxRate}%)</span>
                    <span className="font-mono">PKR {cartSummary.taxAmount.toLocaleString()}</span>
                  </div>
                  {cartSummary.discountAmount > 0 && (
                    <div className="flex justify-between text-emerald-700 font-medium">
                      <span>Coupon Discount ({cartSummary.appliedCoupon?.code})</span>
                      <span className="font-mono">- PKR {cartSummary.discountAmount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="pt-2 border-t border-slate-200 flex justify-between font-display text-base font-bold text-slate-900">
                    <span>Total Payable</span>
                    <span className="font-mono">PKR {cartSummary.totalAmount.toLocaleString()}</span>
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={checkoutBusy || Boolean(cartError)}
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700 disabled:opacity-50 transition-colors"
              >
                {checkoutBusy ? 'Validating Stock & Creating Sub-Orders...' : 'Confirm & Place Multi-Shop Order'}
              </button>
            </form>
          )}
        </div>
      )}

      {/* TAB 3: PARENT ORDERS & INDEPENDENT SHOP SUB-ORDERS */}
      {activeTab === 'ORDERS' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-2xl font-bold text-slate-900">
              Order History & Live Sub-Order Tracking
            </h2>
            <button
              type="button"
              onClick={loadOrders}
              className="text-xs font-semibold text-emerald-700 hover:underline"
            >
              Refresh Live Status
            </button>
          </div>

          {orders.length === 0 ? (
            <div className="p-10 rounded-2xl border border-slate-200 text-center text-sm text-slate-500">
              You have not placed any orders yet.
            </div>
          ) : (
            <div className="space-y-6">
              {orders.map((po) => (
                <div key={po.id} className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
                  {/* Parent Order Header */}
                  <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <span className="font-mono font-bold text-slate-900 text-sm">{po.order_number}</span>
                        <span>·</span>
                        <span>{new Date(po.created_at).toLocaleString()}</span>
                        <span>·</span>
                        <span>{po.subOrders.length} Shop Sub-Order(s)</span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1">
                        Destination: {po.delivery_address}, {po.delivery_city}
                      </p>
                    </div>
                    <div className="text-right tabular-nums">
                      <div className="font-mono text-base font-bold text-slate-900">
                        PKR {Number(po.total_amount).toLocaleString()}
                      </div>
                      <div className="text-xs text-slate-600">
                        Overall: <strong className="text-slate-900">{po.overall_status.replace(/_/g, ' ')}</strong> ·
                        Payment: {po.payment_method} ({po.payment_status})
                      </div>
                    </div>
                  </div>

                  {/* Independent Shop-Wise Sub-Orders */}
                  <div className="divide-y divide-slate-200">
                    {po.subOrders.map((so: any) => {
                      const canCancel =
                        !['CANCELLED', 'REJECTED'].includes(so.shop_status) &&
                        !['PICKED_UP', 'ON_THE_WAY', 'ARRIVED_AT_CUSTOMER', 'DELIVERED', 'CANCELLED'].includes(
                          so.delivery_status
                        );
                      const isMapOpen = expandedMapSubId === so.id;

                      return (
                        <div key={so.id} className="p-6 space-y-4">
                          <div className="flex flex-wrap items-start justify-between gap-4">
                            <div>
                              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                                <span className="font-mono font-bold text-emerald-700">{so.sub_order_number}</span>
                                <span>·</span>
                                <span className="font-semibold text-slate-900 text-sm">{so.shop_name}</span>
                                <span>·</span>
                                <span>Shop: {so.shop_status.replace(/_/g, ' ')}</span>
                                <span>·</span>
                                <span>Delivery: {so.delivery_status.replace(/_/g, ' ')}</span>
                              </div>

                              {/* Items in this sub-order */}
                              <div className="mt-2 space-y-1">
                                {so.items.map((it: any) => (
                                  <div key={it.id} className="text-sm text-slate-700 tabular-nums">
                                    {it.quantity}x {it.product_name}
                                    {it.variant_name ? ` (${it.variant_name})` : ''} —{' '}
                                    <span className="font-mono">PKR {it.line_total.toLocaleString()}</span>
                                  </div>
                                ))}
                              </div>

                              {/* Assigned Rider / Own Rider Info */}
                              <div className="mt-2 text-xs text-slate-600 flex flex-wrap items-center gap-2">
                                <Truck className="w-3.5 h-3.5 text-emerald-600" />
                                {so.rider_name ? (
                                  <span>
                                    DELIVOO Rider: <strong>{so.rider_name}</strong> ({so.vehicle_type} ·{' '}
                                    {so.vehicle_plate})
                                    {so.liveEtaMins ? ` · Est. ${so.liveEtaMins} mins (${so.remainingKm} km)` : ''}
                                  </span>
                                ) : so.own_rider_info ? (
                                  <span>Shop Rider: {so.own_rider_info}</span>
                                ) : (
                                  <span>Rider assignment pending shop preparation</span>
                                )}
                              </div>

                              {so.refund && (
                                <div className="mt-2 text-xs text-amber-800">
                                  Refund ({so.refund.status}): PKR {so.refund.amount} — {so.refund.reason}
                                </div>
                              )}
                            </div>

                            <div className="flex flex-wrap items-center gap-2 shrink-0">
                              <button
                                type="button"
                                onClick={() => setExpandedMapSubId(isMapOpen ? null : so.id)}
                                className="px-3 py-1.5 rounded-lg border border-slate-200 hover:border-emerald-500 text-xs font-medium text-slate-700"
                              >
                                {isMapOpen ? 'Hide Live Map' : 'Track on Map'}
                              </button>

                              {canCancel && (
                                <button
                                  type="button"
                                  onClick={() => handleCancelSubOrder(so.id)}
                                  className="px-3 py-1.5 rounded-lg border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-medium"
                                >
                                  Cancel Sub-Order
                                </button>
                              )}

                              {!so.refund && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setRefundModalSub(so);
                                    setRefundAmount(String(so.payable_amount));
                                  }}
                                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-medium"
                                >
                                  Request Refund
                                </button>
                              )}

                              {so.delivery_status === 'DELIVERED' && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setReviewModalSub(so);
                                    setReviewTarget('SHOP');
                                    setReviewProductId(so.items?.[0]?.product_id ?? null);
                                    setReviewRating(5);
                                  }}
                                  className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 text-xs font-medium"
                                >
                                  Rate & Review
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Independent Sub-Order Live Map */}
                          {isMapOpen && (
                            <div className="pt-2">
                              <LiveTrackingMap
                                shopPoint={{
                                  lat: so.shop_lat,
                                  lng: so.shop_lng,
                                  label: so.shop_name,
                                }}
                                customerPoint={
                                  po.delivery_lat && po.delivery_lng
                                    ? {
                                        lat: po.delivery_lat,
                                        lng: po.delivery_lng,
                                        label: po.delivery_address,
                                      }
                                    : null
                                }
                                riderPoint={
                                  so.rider_lat !== null && so.rider_lng !== null
                                    ? {
                                        lat: so.rider_lat,
                                        lng: so.rider_lng,
                                        label: so.rider_name || 'Assigned Rider',
                                        lastGpsAt: so.rider_last_gps_at,
                                      }
                                    : null
                                }
                              />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* PRODUCT DETAIL MODAL (Contiguous Purchase Module) */}
      {detailProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full p-6 max-h-[88vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <p className="text-xs text-slate-500">
                  {detailProduct.shop_name || detailProduct.shopName} · {detailProduct.category_name}
                </p>
                <h2 className="font-display text-xl font-bold text-slate-900 mt-0.5">{detailProduct.name}</h2>
              </div>
              <button
                type="button"
                onClick={() => setDetailProduct(null)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="aspect-[4/3] rounded-xl overflow-hidden bg-slate-50 border border-slate-100">
                <img
                  src={detailProduct.image_url}
                  alt={detailProduct.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="space-y-4">
                <p className="text-sm text-slate-600 leading-relaxed">{detailProduct.description}</p>
                <div className="text-xs text-slate-500 space-y-1">
                  {detailProduct.brand && <div>Brand: {detailProduct.brand}</div>}
                  {detailProduct.freshness_info && <div>Freshness: {detailProduct.freshness_info}</div>}
                  <div>Available Stock: {detailProduct.stock_quantity}</div>
                </div>

                {detailProduct.variants?.length > 0 && (
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1.5">Select Variant / Size</label>
                    <div className="flex flex-wrap gap-2">
                      {detailProduct.variants.map((v: any) => (
                        <button
                          key={v.id}
                          type="button"
                          onClick={() => setSelectedVariantId(v.id)}
                          className={`px-3 py-1.5 rounded-lg border text-xs font-medium ${
                            selectedVariantId === v.id
                              ? 'border-emerald-600 bg-emerald-50 text-emerald-900'
                              : 'border-slate-200 text-slate-700'
                          }`}
                        >
                          {v.name} ({v.price_delta >= 0 ? `+${v.price_delta}` : v.price_delta} PKR)
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-3">
                  <div className="flex items-center border border-slate-200 rounded-lg">
                    <button
                      type="button"
                      onClick={() => setDetailQty((q) => Math.max(1, q - 1))}
                      className="px-3 py-2 text-sm"
                    >
                      -
                    </button>
                    <span className="px-3 font-mono text-sm tabular-nums">{detailQty}</span>
                    <button
                      type="button"
                      onClick={() => setDetailQty((q) => Math.min(detailProduct.stock_quantity, q + 1))}
                      className="px-3 py-2 text-sm"
                    >
                      +
                    </button>
                  </div>

                  <button
                    type="button"
                    disabled={!detailProduct.available}
                    onClick={() => {
                      addToCart(detailProduct, detailQty, selectedVariantId);
                      setDetailProduct(null);
                    }}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700 disabled:bg-slate-200"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>

            {detailProduct.reviews?.length > 0 && (
              <div className="mt-6 pt-4 border-t border-slate-100 space-y-2">
                <h3 className="text-sm font-semibold text-slate-900">Verified Customer Reviews</h3>
                {detailProduct.reviews.map((r: any) => (
                  <div key={r.id} className="p-3 rounded-lg bg-slate-50 text-xs">
                    <div className="font-semibold text-slate-800">
                      {r.customer_name} · {r.rating}/5 Stars
                    </div>
                    {r.comment && <p className="text-slate-600 mt-1">{r.comment}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ONLINE PAYMENT GATEWAY HMAC VERIFICATION MODAL */}
      {pendingPaymentChallenge && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
          <form
            onSubmit={handleAuthorizeOnlinePayment}
            className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 space-y-4"
          >
            <h3 className="font-display text-lg font-bold text-slate-900">
              Authorize {pendingPaymentChallenge.method} Payment
            </h3>
            <p className="text-xs text-slate-600">
              Order <strong>{pendingPaymentChallenge.orderNumber}</strong> is awaiting verified backend webhook
              confirmation (<span className="font-mono">{pendingPaymentChallenge.transactionRef}</span>).
            </p>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 font-mono text-sm font-bold text-slate-900 tabular-nums">
              Amount Due: PKR {pendingPaymentChallenge.amount.toLocaleString()}
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                {pendingPaymentChallenge.method === 'CARD' ? 'Card Last-4 / Account Number' : 'Mobile Wallet Number'}
              </label>
              <input
                type="text"
                required
                value={walletNumber}
                onChange={(e) => setWalletNumber(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setPendingPaymentChallenge(null);
                  setActiveTab('ORDERS');
                }}
                className="flex-1 py-2.5 px-4 rounded-lg border border-slate-200 text-xs font-medium text-slate-700"
              >
                Verify Later
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 px-4 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                Authorize & Verify
              </button>
            </div>
          </form>
        </div>
      )}

      {/* REFUND MODAL */}
      {refundModalSub && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
          <form
            onSubmit={handleSubmitRefund}
            className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-slate-900">
                Refund Request — {refundModalSub.sub_order_number}
              </h3>
              <button type="button" onClick={() => setRefundModalSub(null)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Refund Amount (Max PKR {refundModalSub.payable_amount})
              </label>
              <input
                type="number"
                min={1}
                max={refundModalSub.payable_amount}
                required
                value={refundAmount}
                onChange={(e) => setRefundAmount(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Reason *</label>
              <textarea
                required
                rows={3}
                value={refundReason}
                onChange={(e) => setRefundReason(e.target.value)}
                placeholder="Describe missing, damaged, or unsatisfactory item..."
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700"
            >
              Submit Refund Request
            </button>
          </form>
        </div>
      )}

      {/* REVIEW MODAL */}
      {reviewModalSub && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
          <form
            onSubmit={handleSubmitReview}
            className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-slate-900">
                Rate {reviewModalSub.sub_order_number}
              </h3>
              <button type="button" onClick={() => setReviewModalSub(null)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
              {(['SHOP', 'PRODUCT', ...(reviewModalSub.rider_id ? ['RIDER'] : [])] as any[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setReviewTarget(t)}
                  className={`flex-1 py-1.5 text-xs font-medium rounded-md ${
                    reviewTarget === t ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            {reviewTarget === 'PRODUCT' && (
              <select
                value={reviewProductId || ''}
                onChange={(e) => setReviewProductId(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                {reviewModalSub.items.map((it: any) => (
                  <option key={it.product_id} value={it.product_id}>
                    {it.product_name}
                  </option>
                ))}
              </select>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Rating (1–5 Stars)</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setReviewRating(star)}
                    className={`w-10 h-10 rounded-lg border font-mono font-bold text-sm ${
                      reviewRating >= star
                        ? 'border-amber-400 bg-amber-50 text-amber-700'
                        : 'border-slate-200 text-slate-400'
                    }`}
                  >
                    {star}★
                  </button>
                ))}
              </div>
            </div>

            <textarea
              rows={3}
              value={reviewComment}
              onChange={(e) => setReviewComment(e.target.value)}
              placeholder="Optional feedback..."
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />

            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700"
            >
              Submit Verified Review
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
