import { Camera, Clock, Download, Globe, Layers, Package, Upload, X } from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { LiveTrackingMap } from '../components/LiveTrackingMap';
import { apiRequest } from '../lib/api';
import type { SessionData } from '../types';

interface ShopkeeperDashboardProps {
  session: SessionData;
  refreshTick: number;
  onSessionRefresh: () => Promise<void>;
}

const WEEKDAYS = [
  { idx: 0, short: 'Sun' },
  { idx: 1, short: 'Mon' },
  { idx: 2, short: 'Tue' },
  { idx: 3, short: 'Wed' },
  { idx: 4, short: 'Thu' },
  { idx: 5, short: 'Fri' },
  { idx: 6, short: 'Sat' },
];

function parseSimpleCsv(csvText: string): Record<string, string>[] {
  const lines = csvText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length < 2) return [];

  const splitLine = (line: string): string[] => {
    const out: string[] = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        inQuotes = !inQuotes;
      } else if (ch === ',' && !inQuotes) {
        out.push(cur.trim());
        cur = '';
      } else {
        cur += ch;
      }
    }
    out.push(cur.trim());
    return out;
  };

  const headers = splitLine(lines[0]).map((h) => h.toLowerCase().replace(/\s+/g, '_'));
  return lines.slice(1).map((line) => {
    const cols = splitLine(line);
    const obj: Record<string, string> = {};
    headers.forEach((h, i) => {
      obj[h] = cols[i] ?? '';
    });
    return obj;
  });
}

export function ShopkeeperDashboard({
  session,
  refreshTick,
  onSessionRefresh,
}: ShopkeeperDashboardProps) {
  const [data, setData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'ORDERS' | 'PRODUCTS' | 'SCHEDULES' | 'INVENTORY' | 'SETTINGS'>('ORDERS');
  const [productMethod, setProductMethod] = useState<'MANUAL' | 'CSV' | 'URL' | 'BARCODE' | 'CATALOG'>('MANUAL');
  const [feedback, setFeedback] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Manual / Shared Product Form State
  const [pName, setPName] = useState('');
  const [pCategory, setPCategory] = useState('Grocery');
  const [pDesc, setPDesc] = useState('');
  const [pPrice, setPPrice] = useState('');
  const [pOrigPrice, setPOrigPrice] = useState('');
  const [pSku, setPSku] = useState('');
  const [pBarcode, setPBarcode] = useState('');
  const [pBrand, setPBrand] = useState('');
  const [pStock, setPStock] = useState('25');
  const [pMfg, setPMfg] = useState('2026-11-01');
  const [pExp, setPExp] = useState('2027-11-01');
  const [pFreshness, setPFreshness] = useState('Fresh Batch');
  const [pImage, setPImage] = useState('');
  const [pVariantsText, setPVariantsText] = useState('');

  // Method 2 & 5: CSV / Catalog Preview Rows
  const [previewRows, setPreviewRows] = useState<any[]>([]);
  const [catalogJsonInput, setCatalogJsonInput] = useState(
    JSON.stringify(
      [
        {
          name: 'Kashmiri Mamra Almonds 250g',
          category: 'Grocery',
          selling_price: 1350,
          original_price: 1500,
          sku: 'CAT-ALM-250',
          barcode: '8967700112233',
          quantity: 20,
          brand: 'Northern Nut Co',
          description: 'Hand-sorted crunchy Kashmiri almonds',
        },
      ],
      null,
      2
    )
  );

  // Method 3: Website URL Import
  const [scrapeUrl, setScrapeUrl] = useState('');
  const [scrapeNotice, setScrapeNotice] = useState('');

  // Method 4: Barcode Lookup + Camera
  const [barcodeQuery, setBarcodeQuery] = useState('8961000100112');
  const [barcodeStatus, setBarcodeStatus] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Schedule Form
  const [schProductId, setSchProductId] = useState<number | ''>('');
  const [schLabel, setSchLabel] = useState('Morning Fresh Batch');
  const [schStart, setSchStart] = useState('07:00');
  const [schEnd, setSchEnd] = useState('11:00');
  const [schDays, setSchDays] = useState<number[]>([0, 1, 2, 3, 4, 5, 6]);
  const [schPromoPrice, setSchPromoPrice] = useState('');

  // Inventory adjustment & batch
  const [adjProdId, setAdjProdId] = useState<number | ''>('');
  const [adjDelta, setAdjDelta] = useState('10');
  const [adjReason, setAdjReason] = useState('Restock delivery');
  const [batchCode, setBatchCode] = useState('BATCH-2026-NOV');
  const [batchQty, setBatchQty] = useState('20');
  const [batchExp, setBatchExp] = useState('2027-06-30');

  // Shop Settings / Application Edit State
  const [sName, setSName] = useState('');
  const [sCategory, setSCategory] = useState('Grocery');
  const [sAddress, setSAddress] = useState('');
  const [sCity, setSCity] = useState('Lahore');
  const [sDesc, setSDesc] = useState('');
  const [sCnic, setSCnic] = useState('');
  const [sFee, setSFee] = useState('120');
  const [sOpenTime, setSOpenTime] = useState('08:00');
  const [sCloseTime, setSCloseTime] = useState('23:00');
  const [sOverride, setSOverride] = useState<'AUTO' | 'FORCE_OPEN' | 'FORCE_CLOSED'>('AUTO');
  const [sOwnRiderName, setSOwnRiderName] = useState('');
  const [sOwnRiderPhone, setSOwnRiderPhone] = useState('');
  const [sCoords, setSCoords] = useState<{ lat: number; lng: number }>({ lat: 31.5102, lng: 74.3441 });

  const loadDashboard = async () => {
    try {
      const res = await apiRequest('/api/shopkeeper/dashboard');
      setData(res);
      if (res.shop) {
        setSName(res.shop.name);
        setSCategory(res.shop.category_name);
        setSAddress(res.shop.address);
        setSCity(res.shop.city);
        setSDesc(res.shop.description || '');
        setSCnic(res.shop.cnic_ntn || '');
        setSFee(String(res.shop.delivery_fee));
        setSOpenTime(res.shop.opening_time);
        setSCloseTime(res.shop.closing_time);
        setSOverride(res.shop.is_open_override);
        setSOwnRiderName(res.shop.own_rider_name || '');
        setSOwnRiderPhone(res.shop.own_rider_phone || '');
        setSCoords({ lat: res.shop.lat, lng: res.shop.lng });
        setPCategory(res.shop.category_name);
      }
      if (res.products?.length > 0 && !schProductId) {
        setSchProductId(res.products[0].id);
        setAdjProdId(res.products[0].id);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Could not load merchant dashboard.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboard();
  }, [refreshTick]);

  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  const flash = (msg: string, isErr = false) => {
    if (isErr) {
      setErrorMsg(msg);
      setFeedback('');
    } else {
      setFeedback(msg);
      setErrorMsg('');
      setTimeout(() => setFeedback(''), 3500);
    }
  };

  const handleSaveShopSettings = async (e: React.FormEvent, resubmit = false) => {
    e.preventDefault();
    try {
      await apiRequest('/api/shopkeeper/application', {
        method: 'PUT',
        body: JSON.stringify({
          name: sName,
          categoryName: sCategory,
          address: sAddress,
          city: sCity,
          description: sDesc,
          cnicNtn: sCnic,
          deliveryFee: Number(sFee),
          openingTime: sOpenTime,
          closingTime: sCloseTime,
          isOpenOverride: sOverride,
          ownRiderName: sOwnRiderName,
          ownRiderPhone: sOwnRiderPhone,
          lat: sCoords.lat,
          lng: sCoords.lng,
          resubmitForApproval: resubmit,
        }),
      });
      await onSessionRefresh();
      await loadDashboard();
      flash(resubmit ? 'Application resubmitted for Admin approval!' : 'Shop settings saved.');
    } catch (err) {
      flash(err instanceof Error ? err.message : 'Could not update shop.', true);
    }
  };

  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1.8 * 1024 * 1024) {
      flash('Image file must be under 1.8 MB.', true);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') setPImage(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleCreateManualProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const variants = pVariantsText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
        .map((token) => {
          const [vName, deltaStr] = token.split(':');
          return { name: vName.trim(), priceDelta: Number(deltaStr || 0) };
        });

      await apiRequest('/api/shopkeeper/products', {
        method: 'POST',
        body: JSON.stringify({
          name: pName,
          categoryName: pCategory,
          description: pDesc,
          sellingPrice: Number(pPrice),
          originalPrice: pOrigPrice ? Number(pOrigPrice) : Number(pPrice),
          sku: pSku,
          barcode: pBarcode,
          brand: pBrand,
          stockQuantity: Number(pStock),
          mfgDate: pMfg,
          expiryDate: pExp,
          freshnessInfo: pFreshness,
          imageUrl: pImage,
          variants,
        }),
      });

      setPName('');
      setPDesc('');
      setPPrice('');
      setPOrigPrice('');
      setPSku('');
      setPBarcode('');
      setPVariantsText('');
      await loadDashboard();
      flash('Product published to your DELIVOO storefront!');
    } catch (err) {
      flash(err instanceof Error ? err.message : 'Failed to create product.', true);
    }
  };

  const handleCsvUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const parsed = parseSimpleCsv(text);
    if (parsed.length === 0) {
      flash('CSV file contains no data rows.', true);
      return;
    }
    try {
      const res = await apiRequest<{ rows: any[] }>('/api/shopkeeper/import/validate-rows', {
        method: 'POST',
        body: JSON.stringify({ rows: parsed }),
      });
      setPreviewRows(res.rows);
      flash(`Validated ${res.rows.length} row(s). Review below before importing.`);
    } catch (err) {
      flash(err instanceof Error ? err.message : 'CSV validation failed.', true);
    }
  };

  const handleCatalogPreview = async () => {
    try {
      const parsed = JSON.parse(catalogJsonInput);
      const rows = Array.isArray(parsed) ? parsed : parsed.products || [];
      const res = await apiRequest<{ rows: any[] }>('/api/shopkeeper/import/validate-rows', {
        method: 'POST',
        body: JSON.stringify({ rows }),
      });
      setPreviewRows(res.rows);
      flash(`Mapped ${res.rows.length} catalog item(s). Confirm below to import.`);
    } catch (err) {
      flash(err instanceof Error ? err.message : 'Invalid JSON catalog format.', true);
    }
  };

  const handleCommitImport = async (methodName: string) => {
    const validOnly = previewRows.filter((r) => r.valid);
    if (validOnly.length === 0) {
      flash('Fix row errors so at least 1 valid product can be imported.', true);
      return;
    }
    try {
      const res = await apiRequest<{ message: string }>('/api/shopkeeper/import/commit', {
        method: 'POST',
        body: JSON.stringify({ method: methodName, rows: validOnly }),
      });
      setPreviewRows([]);
      await loadDashboard();
      flash(res.message);
    } catch (err) {
      flash(err instanceof Error ? err.message : 'Import commit failed.', true);
    }
  };

  const handleScrapeUrl = async (targetUrl?: string) => {
    const u = targetUrl || scrapeUrl;
    if (!u) return;
    setScrapeNotice('');
    try {
      const res = await apiRequest<{ extracted: any; notice: string }>(
        '/api/shopkeeper/import/url-scrape',
        {
          method: 'POST',
          body: JSON.stringify({ url: u }),
        }
      );
      setPName(res.extracted.name || '');
      setPDesc(res.extracted.description || '');
      setPPrice(res.extracted.sellingPrice ? String(res.extracted.sellingPrice) : '');
      setPBrand(res.extracted.brand || '');
      setPSku(res.extracted.sku || `URL-${Math.floor(100 + Math.random() * 900)}`);
      if (res.extracted.imageUrl) setPImage(res.extracted.imageUrl);
      setScrapeNotice(res.notice);
      setProductMethod('MANUAL');
      flash('Public metadata loaded into editable product form — review & confirm to save!');
    } catch (err) {
      flash(err instanceof Error ? err.message : 'URL metadata fetch failed.', true);
    }
  };

  const handleBarcodeLookup = async (codeToLookup?: string) => {
    const code = (codeToLookup || barcodeQuery).trim();
    if (!code) return;
    setBarcodeStatus('Looking up barcode...');
    try {
      const res = await apiRequest<any>(`/api/shopkeeper/import/barcode/${encodeURIComponent(code)}`);
      setPBarcode(code);
      if (res.found && res.product) {
        setPName(res.product.name || '');
        setPBrand(res.product.brand || '');
        setPDesc(res.product.description || '');
        if (res.product.suggestedPrice) setPPrice(String(res.product.suggestedPrice));
        setPSku(`BC-${code.slice(-6)}`);
        setBarcodeStatus(`Found in ${res.source}! Loaded into form — review and save.`);
        setProductMethod('MANUAL');
      } else {
        setPSku(`BC-${code.slice(-6)}`);
        setBarcodeStatus(res.message || 'No public barcode match. Complete details manually.');
      }
    } catch (err) {
      setBarcodeStatus(err instanceof Error ? err.message : 'Lookup error.');
    }
  };

  const startCameraScanner = async () => {
    setBarcodeStatus('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      streamRef.current = stream;
      setCameraActive(true);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
      }, 100);

      const AnyWin = window as any;
      if (AnyWin.BarcodeDetector) {
        const detector = new AnyWin.BarcodeDetector({
          formats: ['ean_13', 'ean_8', 'upc_a', 'code_128'],
        });
        const scanTick = async () => {
          if (!streamRef.current || !videoRef.current) return;
          try {
            const barcodes = await detector.detect(videoRef.current);
            if (barcodes.length > 0 && barcodes[0].rawValue) {
              const detected = String(barcodes[0].rawValue);
              stopCameraScanner();
              setBarcodeQuery(detected);
              handleBarcodeLookup(detected);
              return;
            }
          } catch {
            // Continue scanning
          }
          requestAnimationFrame(scanTick);
        };
        requestAnimationFrame(scanTick);
      } else {
        setBarcodeStatus('Camera preview active. Enter barcode digits below if browser lacks native BarcodeDetector.');
      }
    } catch {
      setBarcodeStatus('Camera permission unavailable in this browser frame. Enter barcode digits manually below.');
    }
  };

  const stopCameraScanner = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  const handleSubOrderStatus = async (subId: number, action: string) => {
    try {
      await apiRequest(`/api/shopkeeper/suborders/${subId}/status`, {
        method: 'POST',
        body: JSON.stringify({ action }),
      });
      await loadDashboard();
      flash(`Sub-order updated: ${action}`);
    } catch (err) {
      flash(err instanceof Error ? err.message : 'Action failed.', true);
    }
  };

  const handleDispatchRider = async (subId: number, mode: 'DELIVOO_RIDER' | 'SHOP_RIDER') => {
    try {
      const res = await apiRequest<{ message?: string; ownRider?: string }>(
        `/api/shopkeeper/suborders/${subId}/dispatch`,
        {
          method: 'POST',
          body: JSON.stringify({
            mode,
            ownRiderName: sOwnRiderName || `${data.shop.name} Rider`,
            ownRiderPhone: sOwnRiderPhone || session.user.phone,
          }),
        }
      );
      await loadDashboard();
      flash(res.message || `Dispatched via ${mode}`);
    } catch (err) {
      flash(err instanceof Error ? err.message : 'Dispatch failed.', true);
    }
  };

  const handleAddSchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!schProductId) return;
    try {
      await apiRequest('/api/shopkeeper/schedules', {
        method: 'POST',
        body: JSON.stringify({
          productId: Number(schProductId),
          label: schLabel,
          startTime: schStart,
          endTime: schEnd,
          daysOfWeek: schDays.join(','),
          promoPrice: schPromoPrice ? Number(schPromoPrice) : null,
        }),
      });
      setSchPromoPrice('');
      await loadDashboard();
      flash('Asia/Karachi schedule saved!');
    } catch (err) {
      flash(err instanceof Error ? err.message : 'Could not save schedule.', true);
    }
  };

  if (loading) {
    return <div className="max-w-6xl mx-auto p-8 text-sm text-slate-500">Loading Merchant Dashboard...</div>;
  }

  const shop = data?.shop;

  // MANDATORY APPROVAL GATE: Newly registered Shopkeepers wait for Admin approval before going live!
  if (!shop || shop.approval_status !== 'APPROVED') {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-8 py-12 space-y-6">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100">
            <div>
              <p className="text-xs font-medium text-amber-700">
                Shopkeeper Verification Status: {shop?.approval_status || 'PENDING'}
              </p>
              <h1 className="font-display text-2xl font-bold text-slate-900 mt-1">
                {shop?.approval_status === 'REJECTED'
                  ? 'Shop Registration Needs Revision'
                  : shop?.approval_status === 'SUSPENDED'
                  ? 'Shop Account Suspended'
                  : 'Awaiting DELIVOO Admin Approval'}
              </h1>
            </div>
            <button
              type="button"
              onClick={loadDashboard}
              className="px-3.5 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:border-emerald-500"
            >
              Check Status
            </button>
          </div>

          <p className="text-sm text-slate-600 leading-relaxed">
            Your shop <strong>{shop?.name}</strong> has been registered in DELIVOO. Once an Administrator reviews and
            approves your merchant profile, your storefront will automatically unlock and appear in the Customer app
            (live updates connected).
          </p>

          {shop?.rejection_reason && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-800">
              <strong>Admin Feedback:</strong> {shop.rejection_reason}
            </div>
          )}

          {feedback && <div className="p-3 rounded-xl bg-emerald-50 text-sm text-emerald-800">{feedback}</div>}
          {errorMsg && <div className="p-3 rounded-xl bg-rose-50 text-sm text-rose-700">{errorMsg}</div>}

          <form onSubmit={(e) => handleSaveShopSettings(e, true)} className="space-y-4 pt-2">
            <h2 className="text-sm font-semibold text-slate-900">Submitted Shop Registration Details</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Shop Name</label>
                <input
                  type="text"
                  required
                  value={sName}
                  onChange={(e) => setSName(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">CNIC / NTN</label>
                <input
                  type="text"
                  required
                  value={sCnic}
                  onChange={(e) => setSCnic(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">City</label>
                <input
                  type="text"
                  required
                  value={sCity}
                  onChange={(e) => setSCity(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Street Address</label>
                <input
                  type="text"
                  required
                  value={sAddress}
                  onChange={(e) => setSAddress(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700"
            >
              {shop?.approval_status === 'REJECTED'
                ? 'Update & Resubmit for Admin Approval'
                : 'Save Application Updates'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 space-y-6">
      {/* MERCHANT HEADER SUMMARY */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="text-xs text-slate-500 flex items-center gap-2">
            <span>Approved Merchant</span>
            <span>·</span>
            <span>{shop.category_name}</span>
            <span>·</span>
            <span>PKT Clock: {data.karachiClock.timeHHMM}</span>
            <span>·</span>
            <span className={shop.isOpen ? 'text-emerald-700 font-semibold' : 'text-rose-600 font-semibold'}>
              {shop.isOpen ? 'Shop Open' : 'Shop Closed'}
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-900 mt-0.5">{shop.name}</h1>
        </div>

        <div className="flex items-center gap-6 text-right tabular-nums">
          <div>
            <div className="text-xs text-slate-500">Net Settled Earnings</div>
            <div className="font-mono text-lg font-bold text-emerald-700">
              PKR {Number(data.earnings?.netEarnings || 0).toLocaleString()}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Delivered Sub-Orders</div>
            <div className="font-mono text-lg font-bold text-slate-900">
              {data.earnings?.deliveredCount || 0}
            </div>
          </div>
        </div>
      </div>

      {/* MERCHANT ROLE NAVIGATION */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl overflow-x-auto">
        {(
          [
            ['ORDERS', `Sub-Orders (${data.subOrders.length})`],
            ['PRODUCTS', `Products & 5 Import Methods (${data.products.length})`],
            ['SCHEDULES', `PKT Schedules (${data.schedules.length})`],
            ['INVENTORY', 'Inventory & Batches'],
            ['SETTINGS', 'Shop Settings'],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              tab === key ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-sm text-emerald-800">
          {feedback}
        </div>
      )}
      {errorMsg && (
        <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-700">
          {errorMsg}
        </div>
      )}

      {/* TAB 1: INDEPENDENT SHOP-WISE SUB-ORDERS */}
      {tab === 'ORDERS' && (
        <div className="space-y-4">
          {data.subOrders.length === 0 ? (
            <div className="p-10 rounded-2xl border border-slate-200 text-center text-sm text-slate-500">
              No customer sub-orders received yet.
            </div>
          ) : (
            data.subOrders.map((so: any) => (
              <div key={so.id} className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
                <div className="flex flex-wrap items-start justify-between gap-4 pb-3 border-b border-slate-100">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                      <span className="font-mono font-bold text-slate-900 text-sm">{so.sub_order_number}</span>
                      <span>·</span>
                      <span>Parent {so.order_number}</span>
                      <span>·</span>
                      <span>Customer: {so.customer_name}</span>
                      <span>·</span>
                      <span>{so.payment_method} ({so.payment_status})</span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1">
                      Dropoff: {so.delivery_address}, {so.delivery_city} · Phone: {so.contact_phone}
                    </p>
                  </div>
                  <div className="text-right tabular-nums">
                    <div className="font-mono text-base font-bold text-slate-900">
                      Subtotal PKR {Number(so.subtotal).toLocaleString()}
                    </div>
                    <div className="text-xs text-slate-500">
                      Shop: <strong>{so.shop_status}</strong> · Delivery: <strong>{so.delivery_status}</strong>
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  {so.items.map((it: any) => (
                    <div key={it.id} className="text-sm text-slate-800 tabular-nums">
                      {it.quantity}x {it.product_name}
                      {it.variant_name ? ` (${it.variant_name})` : ''} —{' '}
                      <span className="font-mono">PKR {it.line_total.toLocaleString()}</span>
                    </div>
                  ))}
                </div>

                {/* Action Workflow */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <div className="text-xs text-slate-600">
                    {so.rider_name
                      ? `Assigned DELIVOO Rider: ${so.rider_name} (${so.vehicle_plate})`
                      : so.own_rider_info
                      ? `Shop Own Rider: ${so.own_rider_info}`
                      : 'No rider dispatched yet'}
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {so.shop_status === 'PENDING_SHOP' && (
                      <>
                        <button
                          type="button"
                          onClick={() => handleSubOrderStatus(so.id, 'ACCEPT')}
                          className="px-3.5 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
                        >
                          Accept Sub-Order
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSubOrderStatus(so.id, 'REJECT')}
                          className="px-3.5 py-1.5 rounded-lg border border-rose-200 text-rose-700 text-xs font-semibold hover:bg-rose-50"
                        >
                          Reject
                        </button>
                      </>
                    )}

                    {so.shop_status === 'ACCEPTED' && (
                      <button
                        type="button"
                        onClick={() => handleSubOrderStatus(so.id, 'PREPARING')}
                        className="px-3.5 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-semibold"
                      >
                        Mark Preparing
                      </button>
                    )}

                    {(so.shop_status === 'ACCEPTED' || so.shop_status === 'PREPARING') && (
                      <button
                        type="button"
                        onClick={() => handleSubOrderStatus(so.id, 'READY_FOR_PICKUP')}
                        className="px-3.5 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-semibold"
                      >
                        Mark Ready for Pickup
                      </button>
                    )}

                    {['ACCEPTED', 'PREPARING', 'READY_FOR_PICKUP'].includes(so.shop_status) &&
                      ['UNASSIGNED', 'PENDING_ASSIGNMENT'].includes(so.delivery_status) && (
                        <>
                          <button
                            type="button"
                            onClick={() => handleDispatchRider(so.id, 'DELIVOO_RIDER')}
                            className="px-3.5 py-1.5 rounded-lg border border-emerald-600 text-emerald-700 hover:bg-emerald-50 text-xs font-semibold"
                          >
                            Smart Dispatch DELIVOO Rider
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDispatchRider(so.id, 'SHOP_RIDER')}
                            className="px-3.5 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-medium"
                          >
                            Send Shop's Own Rider
                          </button>
                        </>
                      )}

                    {so.dispatch_mode === 'SHOP_RIDER' && so.delivery_status !== 'DELIVERED' && (
                      <button
                        type="button"
                        onClick={async () => {
                          await apiRequest(`/api/shopkeeper/suborders/${so.id}/dispatch`, {
                            method: 'POST',
                            body: JSON.stringify({
                              mode: 'SHOP_RIDER',
                              shopRiderDeliveryStatus: 'DELIVERED',
                            }),
                          });
                          await loadDashboard();
                          flash('Marked delivered by Shop Rider!');
                        }}
                        className="px-3.5 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-semibold"
                      >
                        Confirm Shop Rider Delivered
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 2: 5 PRODUCT ADDITION METHODS + CATALOG TABLE */}
      {tab === 'PRODUCTS' && (
        <div className="space-y-8">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
              <h2 className="font-display text-lg font-bold text-slate-900">Add Products (5 Methods)</h2>
              <div className="flex flex-wrap gap-1 p-1 bg-slate-100 rounded-lg">
                {(
                  [
                    ['MANUAL', '1. Manual Entry', Package],
                    ['CSV', '2. Excel / CSV', Upload],
                    ['URL', '3. Website URL', Globe],
                    ['BARCODE', '4. Barcode Scan', Camera],
                    ['CATALOG', '5. App / Catalog API', Layers],
                  ] as const
                ).map(([m, label, Icon]) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setProductMethod(m)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                      productMethod === m ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* METHOD 1: MANUAL ENTRY */}
            {productMethod === 'MANUAL' && (
              <form onSubmit={handleCreateManualProduct} className="space-y-4">
                {scrapeNotice && (
                  <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
                    {scrapeNotice}
                  </div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-slate-700 mb-1">Product Name *</label>
                    <input
                      type="text"
                      required
                      value={pName}
                      onChange={(e) => setPName(e.target.value)}
                      placeholder="e.g. Fresh Olpers Full Cream Milk 1L"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Category *</label>
                    <select
                      value={pCategory}
                      onChange={(e) => setPCategory(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                    >
                      {(data.categories || []).map((c: any) => (
                        <option key={c.id} value={c.name}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Selling Price (PKR) *</label>
                    <input
                      type="number"
                      required
                      min={1}
                      value={pPrice}
                      onChange={(e) => setPPrice(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Original Price</label>
                    <input
                      type="number"
                      min={0}
                      value={pOrigPrice}
                      onChange={(e) => setPOrigPrice(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">SKU *</label>
                    <input
                      type="text"
                      required
                      value={pSku}
                      onChange={(e) => setPSku(e.target.value)}
                      placeholder="SKU-101"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono uppercase"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Barcode</label>
                    <input
                      type="text"
                      value={pBarcode}
                      onChange={(e) => setPBarcode(e.target.value)}
                      placeholder="8961..."
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Quantity *</label>
                    <input
                      type="number"
                      required
                      min={0}
                      value={pStock}
                      onChange={(e) => setPStock(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Brand</label>
                    <input
                      type="text"
                      value={pBrand}
                      onChange={(e) => setPBrand(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Mfg Date</label>
                    <input
                      type="date"
                      value={pMfg}
                      onChange={(e) => setPMfg(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Expiry Date</label>
                    <input
                      type="date"
                      value={pExp}
                      onChange={(e) => setPExp(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Variants (Optional: Name:PriceDelta comma-separated)
                    </label>
                    <input
                      type="text"
                      value={pVariantsText}
                      onChange={(e) => setPVariantsText(e.target.value)}
                      placeholder="Regular:0, Large:350"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Upload Product Image (or auto-generate studio card)
                    </label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageFileUpload}
                      className="w-full text-xs text-slate-600 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-emerald-50 file:text-emerald-700 file:font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Description & Freshness</label>
                  <textarea
                    rows={2}
                    value={pDesc}
                    onChange={(e) => setPDesc(e.target.value)}
                    placeholder="Detailed product description..."
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>

                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700"
                >
                  Save & Publish Product
                </button>
              </form>
            )}

            {/* METHOD 2: CSV / EXCEL IMPORT */}
            {productMethod === 'CSV' && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <p className="text-sm text-slate-600">
                    Download the DELIVOO CSV template, upload your spreadsheet export, inspect duplicate SKU/barcode
                    validation, edit any invalid row inline, and commit valid products.
                  </p>
                  <a
                    href="/api/shopkeeper/import/template"
                    download="delivoo_product_import_template.csv"
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:border-emerald-500"
                  >
                    <Download className="w-4 h-4" />
                    Download Sample CSV Template
                  </a>
                </div>

                <input
                  type="file"
                  accept=".csv,text/csv"
                  onChange={handleCsvUpload}
                  className="block w-full text-sm text-slate-600 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-emerald-600 file:text-white file:text-xs file:font-semibold"
                />

                {previewRows.length > 0 && (
                  <div className="space-y-3">
                    <div className="overflow-x-auto border border-slate-200 rounded-xl">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                          <tr>
                            <th className="p-2.5">#</th>
                            <th className="p-2.5">Name</th>
                            <th className="p-2.5">SKU</th>
                            <th className="p-2.5">Price (PKR)</th>
                            <th className="p-2.5">Qty</th>
                            <th className="p-2.5">Validation</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {previewRows.map((row, idx) => (
                            <tr key={idx}>
                              <td className="p-2 font-mono">{row.rowNumber}</td>
                              <td className="p-2">
                                <input
                                  type="text"
                                  value={row.name}
                                  onChange={(e) => {
                                    const copy = [...previewRows];
                                    copy[idx] = { ...copy[idx], name: e.target.value, valid: true, errors: [] };
                                    setPreviewRows(copy);
                                  }}
                                  className="border border-slate-200 rounded px-2 py-1 w-44"
                                />
                              </td>
                              <td className="p-2">
                                <input
                                  type="text"
                                  value={row.sku}
                                  onChange={(e) => {
                                    const copy = [...previewRows];
                                    copy[idx] = {
                                      ...copy[idx],
                                      sku: e.target.value.toUpperCase(),
                                      valid: true,
                                      errors: [],
                                    };
                                    setPreviewRows(copy);
                                  }}
                                  className="border border-slate-200 rounded px-2 py-1 w-28 font-mono"
                                />
                              </td>
                              <td className="p-2 font-mono">{row.sellingPrice}</td>
                              <td className="p-2 font-mono">{row.quantity}</td>
                              <td className="p-2">
                                {row.valid ? (
                                  <span className="text-emerald-700 font-medium">Valid</span>
                                ) : (
                                  <span className="text-rose-600">{row.errors.join('; ')}</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCommitImport('CSV_EXCEL')}
                      className="px-5 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
                    >
                      Import Valid Products
                    </button>
                  </div>
                )}

                {data.importJobs?.length > 0 && (
                  <div className="pt-3 border-t border-slate-100">
                    <h4 className="text-xs font-semibold text-slate-700 mb-2">Recent Import History</h4>
                    <div className="space-y-1 text-xs text-slate-600 tabular-nums">
                      {data.importJobs.map((j: any) => (
                        <div key={j.id}>
                          Job #{j.id} ({j.method}) · Imported {j.valid_rows}/{j.total_rows} rows ·{' '}
                          {new Date(j.created_at).toLocaleString()}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* METHOD 3: PUBLIC WEBSITE URL IMPORT */}
            {productMethod === 'URL' && (
              <div className="space-y-4">
                <p className="text-sm text-slate-600">
                  Enter any public product page URL containing OpenGraph or Schema.org Product metadata. Missing fields
                  are never fabricated and always open in an editable preview before saving.
                </p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="url"
                    value={scrapeUrl}
                    onChange={(e) => setScrapeUrl(e.target.value)}
                    placeholder="https://example.com/products/organic-walnuts"
                    className="flex-1 rounded-lg border border-slate-300 px-3.5 py-2 text-sm"
                  />
                  <button
                    type="button"
                    onClick={() => handleScrapeUrl()}
                    className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 whitespace-nowrap"
                  >
                    Retrieve Metadata
                  </button>
                </div>
                <div className="flex flex-wrap gap-3 text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      const sample = `${window.location.origin}/public-sample-product/hunza-walnuts`;
                      setScrapeUrl(sample);
                      handleScrapeUrl(sample);
                    }}
                    className="text-emerald-700 font-medium hover:underline"
                  >
                    Test with Sample Public Product URL (Hunza Walnuts)
                  </button>
                  <span>·</span>
                  <button
                    type="button"
                    onClick={() => {
                      const sample = `${window.location.origin}/public-sample-product/sidr-honey`;
                      setScrapeUrl(sample);
                      handleScrapeUrl(sample);
                    }}
                    className="text-emerald-700 font-medium hover:underline"
                  >
                    Test with Sample Public Product URL (Sidr Honey)
                  </button>
                </div>
              </div>
            )}

            {/* METHOD 4: BARCODE SCANNING & LOOKUP */}
            {productMethod === 'BARCODE' && (
              <div className="space-y-4">
                <p className="text-sm text-slate-600">
                  Scan a barcode using your device camera or enter an EAN/UPC barcode to query the DELIVOO &
                  OpenFoodFacts barcode registries.
                </p>

                <div className="flex flex-wrap gap-2">
                  {!cameraActive ? (
                    <button
                      type="button"
                      onClick={startCameraScanner}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-800 hover:border-emerald-500"
                    >
                      <Camera className="w-4 h-4 text-emerald-600" />
                      Open Camera Barcode Scanner
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={stopCameraScanner}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-rose-200 text-xs font-semibold text-rose-700"
                    >
                      <X className="w-4 h-4" />
                      Stop Camera
                    </button>
                  )}
                </div>

                {cameraActive && (
                  <video
                    ref={videoRef}
                    muted
                    playsInline
                    className="w-full max-w-sm h-48 rounded-xl bg-slate-900 object-cover"
                  />
                )}

                <div className="flex gap-2 max-w-md">
                  <input
                    type="text"
                    value={barcodeQuery}
                    onChange={(e) => setBarcodeQuery(e.target.value)}
                    placeholder="Enter EAN-13 / UPC barcode..."
                    className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => handleBarcodeLookup()}
                    className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
                  >
                    Lookup Barcode
                  </button>
                </div>

                {barcodeStatus && <p className="text-xs text-slate-700">{barcodeStatus}</p>}
              </div>
            )}

            {/* METHOD 5: APP / AUTHORIZED CATALOG JSON IMPORT */}
            {productMethod === 'CATALOG' && (
              <div className="space-y-4">
                <p className="text-sm text-slate-600">
                  Import structured product records from an authorized POS/ERP JSON catalog export with full validation
                  preview before saving.
                </p>
                <textarea
                  rows={6}
                  value={catalogJsonInput}
                  onChange={(e) => setCatalogJsonInput(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 p-3 text-xs font-mono"
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={handleCatalogPreview}
                    className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-800 hover:border-emerald-500"
                  >
                    Map & Preview Records
                  </button>
                  {previewRows.length > 0 && (
                    <button
                      type="button"
                      onClick={() => handleCommitImport('CATALOG_API')}
                      className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
                    >
                      Confirm & Import {previewRows.filter((r) => r.valid).length} Valid Item(s)
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* EXISTING SHOP PRODUCTS TABLE */}
          <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100">
              <h3 className="font-display text-base font-bold text-slate-900">Your Shop Catalog</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                  <tr>
                    <th className="px-4 py-3">Product</th>
                    <th className="px-4 py-3">SKU</th>
                    <th className="px-4 py-3 text-right">Price (PKR)</th>
                    <th className="px-4 py-3 text-right">Stock</th>
                    <th className="px-4 py-3">PKT Availability</th>
                    <th className="px-4 py-3 text-right">Toggle</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 tabular-nums">
                  {data.products.map((p: any) => (
                    <tr key={p.id} className="hover:bg-slate-50/60">
                      <td className="px-4 py-3 font-medium text-slate-900">{p.name}</td>
                      <td className="px-4 py-3 font-mono text-xs text-slate-600">{p.sku}</td>
                      <td className="px-4 py-3 text-right font-mono">{p.effectivePrice.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right font-mono">
                        <span className={p.stock_quantity <= p.low_stock_threshold ? 'text-rose-600 font-bold' : ''}>
                          {p.stock_quantity}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-600">{p.availabilityReason}</td>
                      <td className="px-4 py-3 text-right">
                        <button
                          type="button"
                          onClick={async () => {
                            await apiRequest(`/api/shopkeeper/products/${p.id}`, {
                              method: 'PUT',
                              body: JSON.stringify({ isActive: !p.is_active }),
                            });
                            await loadDashboard();
                          }}
                          className="text-xs font-medium text-emerald-700 hover:underline"
                        >
                          {p.is_active ? 'Deactivate' : 'Activate'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: TIME-BASED PRODUCT SCHEDULING (ASIA/KARACHI) */}
      {tab === 'SCHEDULES' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleAddSchedule}
            className="lg:col-span-5 rounded-2xl border border-slate-200 bg-white p-6 space-y-4"
          >
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-600" />
              <h2 className="font-display text-lg font-bold text-slate-900">Create PKT Schedule</h2>
            </div>
            <p className="text-xs text-slate-500">
              Evaluated server-side in Asia/Karachi timezone (Current PKT: {data.karachiClock.timeHHMM}).
            </p>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Product</label>
              <select
                required
                value={schProductId}
                onChange={(e) => setSchProductId(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                {data.products.map((p: any) => (
                  <option key={p.id} value={p.id}>
                    {p.name} (PKR {p.selling_price})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Schedule Label</label>
              <input
                type="text"
                required
                value={schLabel}
                onChange={(e) => setSchLabel(e.target.value)}
                placeholder="Morning Fresh Bread (7 AM – 11 AM)"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Start Time (PKT)</label>
                <input
                  type="time"
                  required
                  value={schStart}
                  onChange={(e) => setSchStart(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">End Time (PKT)</label>
                <input
                  type="time"
                  required
                  value={schEnd}
                  onChange={(e) => setSchEnd(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">Active Weekdays</label>
              <div className="flex flex-wrap gap-1.5">
                {WEEKDAYS.map((d) => {
                  const active = schDays.includes(d.idx);
                  return (
                    <button
                      key={d.idx}
                      type="button"
                      onClick={() =>
                        setSchDays((prev) =>
                          prev.includes(d.idx) ? prev.filter((x) => x !== d.idx) : [...prev, d.idx]
                        )
                      }
                      className={`px-2.5 py-1 rounded-md text-xs font-medium border ${
                        active
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white text-slate-600 border-slate-200'
                      }`}
                    >
                      {d.short}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Scheduled Promotional Price (Optional PKR)
              </label>
              <input
                type="number"
                min={1}
                value={schPromoPrice}
                onChange={(e) => setSchPromoPrice(e.target.value)}
                placeholder="Leave blank to keep standard price"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700"
            >
              Activate Product Schedule
            </button>
          </form>

          <div className="lg:col-span-7 rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
            <h3 className="font-display text-lg font-bold text-slate-900">Configured Schedules</h3>
            {data.schedules.length === 0 ? (
              <p className="text-sm text-slate-500">
                No time restrictions configured — products remain available throughout your shop's opening hours.
              </p>
            ) : (
              <div className="divide-y divide-slate-100">
                {data.schedules.map((s: any) => (
                  <div key={s.id} className="py-3 flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-semibold text-slate-900">{s.product_name}</div>
                      <div className="text-xs text-slate-600 font-mono">
                        {s.label} · {s.start_time}–{s.end_time} PKT
                        {s.promo_price ? ` · Promo PKR ${s.promo_price}` : ''} ·{' '}
                        {s.is_paused ? 'PAUSED' : 'ACTIVE'}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 text-xs">
                      <button
                        type="button"
                        onClick={async () => {
                          await apiRequest(`/api/shopkeeper/schedules/${s.id}`, {
                            method: 'PUT',
                            body: JSON.stringify({ isPaused: !s.is_paused }),
                          });
                          await loadDashboard();
                        }}
                        className="font-medium text-slate-700 hover:underline"
                      >
                        {s.is_paused ? 'Resume' : 'Pause'}
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          await apiRequest(`/api/shopkeeper/schedules/${s.id}`, { method: 'DELETE' });
                          await loadDashboard();
                        }}
                        className="font-medium text-rose-600 hover:underline"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: INVENTORY & BATCH EXPIRY MANAGEMENT */}
      {tab === 'INVENTORY' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-5">
            <h3 className="font-display text-lg font-bold text-slate-900">Stock Adjustment & New Batch</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Select Product</label>
                <select
                  value={adjProdId}
                  onChange={(e) => setAdjProdId(Number(e.target.value))}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  {data.products.map((p: any) => (
                    <option key={p.id} value={p.id}>
                      {p.name} (Current Stock: {p.stock_quantity})
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Delta (+/- Units)</label>
                  <input
                    type="number"
                    value={adjDelta}
                    onChange={(e) => setAdjDelta(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Reason</label>
                  <input
                    type="text"
                    value={adjReason}
                    onChange={(e) => setAdjReason(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
              </div>
              <button
                type="button"
                onClick={async () => {
                  try {
                    await apiRequest('/api/shopkeeper/inventory/adjust', {
                      method: 'POST',
                      body: JSON.stringify({
                        productId: Number(adjProdId),
                        changeAmount: Number(adjDelta),
                        reason: adjReason,
                      }),
                    });
                    await loadDashboard();
                    flash('Stock adjusted.');
                  } catch (err) {
                    flash(err instanceof Error ? err.message : 'Error', true);
                  }
                }}
                className="px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold"
              >
                Apply Stock Adjustment
              </button>
            </div>

            <div className="pt-4 border-t border-slate-100 space-y-3">
              <h4 className="text-sm font-semibold text-slate-900">Log Fresh Product Batch</h4>
              <div className="grid grid-cols-3 gap-2">
                <input
                  type="text"
                  value={batchCode}
                  onChange={(e) => setBatchCode(e.target.value)}
                  placeholder="Batch Code"
                  className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs font-mono"
                />
                <input
                  type="number"
                  value={batchQty}
                  onChange={(e) => setBatchQty(e.target.value)}
                  placeholder="Qty"
                  className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs font-mono"
                />
                <input
                  type="date"
                  value={batchExp}
                  onChange={(e) => setBatchExp(e.target.value)}
                  className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs"
                />
              </div>
              <button
                type="button"
                onClick={async () => {
                  try {
                    await apiRequest('/api/shopkeeper/inventory/batches', {
                      method: 'POST',
                      body: JSON.stringify({
                        productId: Number(adjProdId),
                        batchCode,
                        quantity: Number(batchQty),
                        expiryDate: batchExp,
                      }),
                    });
                    await loadDashboard();
                    flash('Batch logged and stock incremented!');
                  } catch (err) {
                    flash(err instanceof Error ? err.message : 'Batch failed', true);
                  }
                }}
                className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold"
              >
                Receive Batch
              </button>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
            <h3 className="font-display text-lg font-bold text-slate-900">Recent Inventory Ledger</h3>
            <div className="space-y-2 max-h-80 overflow-y-auto text-xs tabular-nums">
              {data.inventoryLogs.map((l: any) => (
                <div key={l.id} className="py-2 border-b border-slate-100 flex justify-between gap-2">
                  <div>
                    <span className="font-medium text-slate-900">{l.product_name}</span> · {l.reason}
                  </div>
                  <div className="font-mono shrink-0">
                    {l.change_amount > 0 ? `+${l.change_amount}` : l.change_amount} → {l.new_quantity}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: SHOP SETTINGS & GPS */}
      {tab === 'SETTINGS' && (
        <form onSubmit={(e) => handleSaveShopSettings(e, false)} className="rounded-2xl border border-slate-200 bg-white p-6 space-y-5 max-w-3xl">
          <h2 className="font-display text-lg font-bold text-slate-900">Shop Profile, Hours & Own Rider</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Shop Name</label>
              <input
                type="text"
                value={sName}
                onChange={(e) => setSName(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Open / Closed Mode</label>
              <select
                value={sOverride}
                onChange={(e) => setSOverride(e.target.value as any)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                <option value="AUTO">Automatic (Follow PKT Opening Hours)</option>
                <option value="FORCE_OPEN">Force Open Now</option>
                <option value="FORCE_CLOSED">Temporarily Closed</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Opening Time (PKT)</label>
              <input
                type="time"
                value={sOpenTime}
                onChange={(e) => setSOpenTime(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Closing Time (PKT)</label>
              <input
                type="time"
                value={sCloseTime}
                onChange={(e) => setSCloseTime(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Delivery Fee (PKR)</label>
              <input
                type="number"
                value={sFee}
                onChange={(e) => setSFee(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Shop's Own Rider Name & Phone</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={sOwnRiderName}
                  onChange={(e) => setSOwnRiderName(e.target.value)}
                  placeholder="Rider Name"
                  className="w-1/2 rounded-lg border border-slate-300 px-2.5 py-2 text-sm"
                />
                <input
                  type="text"
                  value={sOwnRiderPhone}
                  onChange={(e) => setSOwnRiderPhone(e.target.value)}
                  placeholder="+923..."
                  className="w-1/2 rounded-lg border border-slate-300 px-2.5 py-2 text-sm"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Shop Pickup Coordinates</label>
            <LiveTrackingMap
              interactivePin={sCoords}
              onSelectPin={(lat, lng) => setSCoords({ lat, lng })}
              heightClass="h-48"
            />
          </div>

          <button
            type="submit"
            className="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700"
          >
            Save Shop Configuration
          </button>
        </form>
      )}
    </div>
  );
}
