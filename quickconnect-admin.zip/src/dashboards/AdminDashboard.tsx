import { Check, X } from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { LiveTrackingMap } from '../components/LiveTrackingMap';
import { apiRequest } from '../lib/api';
import type { SessionData } from '../types';

interface AdminDashboardProps {
  session: SessionData;
  refreshTick: number;
}

export function AdminDashboard({ refreshTick }: AdminDashboardProps) {
  const [tab, setTab] = useState<'ANALYTICS' | 'APPROVALS' | 'ORDERS' | 'USERS' | 'OPERATIONS'>('ANALYTICS');
  const [dateRange, setDateRange] = useState<'ALL' | '7D' | 'TODAY'>('ALL');
  const [analytics, setAnalytics] = useState<any | null>(null);
  const [approvals, setApprovals] = useState<{ shops: any[]; riders: any[] }>({ shops: [], riders: [] });
  const [ordersData, setOrdersData] = useState<{ parentOrders: any[]; eligibleRiders: any[] }>({
    parentOrders: [],
    eligibleRiders: [],
  });
  const [usersData, setUsersData] = useState<{ users: any[]; categories: any[]; products: any[] }>({
    users: [],
    categories: [],
    products: [],
  });
  const [opsData, setOpsData] = useState<any | null>(null);
  const [toast, setToast] = useState('');

  // Forms
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');
  const [cpCode, setCpCode] = useState('');
  const [cpType, setCpType] = useState<'PERCENTAGE' | 'FIXED'>('PERCENTAGE');
  const [cpVal, setCpVal] = useState('15');
  const [cpMin, setCpMin] = useState('1000');
  const [selectedMapSub, setSelectedMapSub] = useState<any | null>(null);
  const [ticketReplies, setTicketReplies] = useState<Record<number, string>>({});
  const [rejectNotes, setRejectNotes] = useState<Record<string, string>>({});

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 3400);
  };

  const loadAll = async () => {
    try {
      const [an, ap, ord, usr, ops] = await Promise.all([
        apiRequest(`/api/admin/analytics?range=${dateRange}`),
        apiRequest<{ shops: any[]; riders: any[] }>('/api/admin/approvals'),
        apiRequest<{ parentOrders: any[]; eligibleRiders: any[] }>('/api/admin/orders'),
        apiRequest<{ users: any[]; categories: any[]; products: any[] }>('/api/admin/users'),
        apiRequest('/api/admin/operations'),
      ]);
      setAnalytics(an);
      setApprovals(ap);
      setOrdersData(ord);
      setUsersData(usr);
      setOpsData(ops);
    } catch {
      // Ignore transient error
    }
  };

  useEffect(() => {
    loadAll();
  }, [refreshTick, dateRange]);

  const handleShopApproval = async (shopId: number, status: string) => {
    try {
      const res = await apiRequest<{ message: string }>(`/api/admin/shops/${shopId}/approval`, {
        method: 'POST',
        body: JSON.stringify({ status, reason: rejectNotes[`shop-${shopId}`] || '' }),
      });
      await loadAll();
      showToast(res.message);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Shop approval update failed.');
    }
  };

  const handleRiderApproval = async (riderId: number, status: string) => {
    try {
      const res = await apiRequest<{ message: string }>(`/api/admin/riders/${riderId}/approval`, {
        method: 'POST',
        body: JSON.stringify({ status, reason: rejectNotes[`rider-${riderId}`] || '' }),
      });
      await loadAll();
      showToast(res.message);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Rider approval update failed.');
    }
  };

  const handleManualAssignRider = async (subOrderId: number, riderId: number) => {
    if (!riderId) return;
    try {
      const res = await apiRequest<{ message: string }>(`/api/admin/suborders/${subOrderId}/assign-rider`, {
        method: 'POST',
        body: JSON.stringify({ riderId }),
      });
      await loadAll();
      showToast(res.message);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Rider assignment failed.');
    }
  };

  const pendingShopsCount = approvals.shops.filter((s) => s.approval_status === 'PENDING').length;
  const pendingRidersCount = approvals.riders.filter((r) => r.approval_status === 'PENDING').length;
  const m = analytics?.metrics;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 space-y-6">
      {toast && (
        <div className="fixed top-20 right-5 z-40 rounded-xl bg-slate-900 text-white px-4 py-2.5 text-sm shadow-lg">
          {toast}
        </div>
      )}

      {/* ADMIN WORKSPACE HEADER */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <p className="text-xs text-slate-500">Centralized Marketplace Governance</p>
          <h1 className="font-display text-2xl font-bold text-slate-900">DELIVOO Administration</h1>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl overflow-x-auto">
          {(
            [
              ['ANALYTICS', 'Analytics'],
              ['APPROVALS', `Approvals (${pendingShopsCount + pendingRidersCount} Pending)`],
              ['ORDERS', `Orders & Dispatch (${ordersData.parentOrders.length})`],
              ['USERS', 'Accounts & Categories'],
              ['OPERATIONS', 'Coupons, Refunds & Logs'],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setTab(key)}
              className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                tab === key ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: ANALYTICS OVERVIEW (ALL 13 REQUIRED METRICS) */}
      {tab === 'ANALYTICS' && m && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-bold text-slate-900">Marketplace Performance</h2>
            <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
              {(
                [
                  ['ALL', 'All Time'],
                  ['7D', 'Last 7 Days'],
                  ['TODAY', 'Today'],
                ] as const
              ).map(([r, lbl]) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setDateRange(r)}
                  className={`px-3 py-1 text-xs font-medium rounded-md ${
                    dateRange === r ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                  }`}
                >
                  {lbl}
                </button>
              ))}
            </div>
          </div>

          {/* Pending Approvals Action Banner if any new Shopkeeper or Rider registered */}
          {(m.pendingShopApprovals > 0 || m.pendingRiderApprovals > 0) && (
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex flex-wrap items-center justify-between gap-3">
              <div className="text-sm text-amber-950">
                <strong>Action Required:</strong> {m.pendingShopApprovals} Shopkeeper registration(s) and{' '}
                {m.pendingRiderApprovals} Rider registration(s) are awaiting Admin approval to join DELIVOO.
              </div>
              <button
                type="button"
                onClick={() => setTab('APPROVALS')}
                className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
              >
                Review Registrations Now
              </button>
            </div>
          )}

          {/* 13 Core Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 tabular-nums">
            {[
              ['Gross Order Value', `PKR ${Number(m.grossOrderValue).toLocaleString()}`],
              ['Platform Commissions', `PKR ${Number(m.platformCommissions).toLocaleString()}`],
              ['Delivery Revenue', `PKR ${Number(m.deliveryRevenue).toLocaleString()}`],
              ['Total Customers', m.totalCustomers],
              ['Total Shops', m.totalShops],
              ['Approved Shops', m.approvedShops],
              ['Pending Shop Approvals', m.pendingShopApprovals],
              ['Active Approved Riders', `${m.activeRiders} (${m.onlineRiders} Online)`],
              ['Pending Rider Approvals', m.pendingRiderApprovals],
              ['Total Parent Orders', m.totalOrders],
              ['Active Orders', m.activeOrders],
              ['Delivered Orders', m.deliveredOrders],
              ['Cancelled Orders', m.cancelledOrders],
            ].map(([label, val]) => (
              <div key={String(label)} className="p-4 rounded-xl border border-slate-200 bg-white">
                <div className="text-xs text-slate-500">{label}</div>
                <div className="mt-1 font-mono text-xl font-bold text-slate-900">{val}</div>
              </div>
            ))}
          </div>

          {/* Category Revenue Visual Breakdown */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
            <h3 className="font-display text-base font-bold text-slate-900">Revenue by Marketplace Category</h3>
            <div className="space-y-3 tabular-nums">
              {(analytics.categorySales || []).map((cs: any) => {
                const maxRev = Math.max(
                  1,
                  ...analytics.categorySales.map((x: any) => Number(x.revenue || 0))
                );
                const pct = Math.round((Number(cs.revenue || 0) / maxRev) * 100);
                return (
                  <div key={cs.category} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-slate-800">
                        {cs.category} ({cs.subOrdersCount} sub-orders)
                      </span>
                      <span className="font-mono text-slate-700">
                        PKR {Number(cs.revenue || 0).toLocaleString()}
                      </span>
                    </div>
                    <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-600 rounded-full transition-all"
                        style={{ width: `${Math.max(3, pct)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SHOPKEEPER & RIDER REGISTRATION APPROVALS */}
      {tab === 'APPROVALS' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Shopkeeper Registrations */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
            <h2 className="font-display text-lg font-bold text-slate-900">
              Shopkeeper Registrations ({approvals.shops.length})
            </h2>
            <p className="text-xs text-slate-500">
              Only APPROVED shops appear in the DELIVOO customer marketplace and can publish live inventory.
            </p>

            <div className="divide-y divide-slate-100">
              {approvals.shops.map((s) => (
                <div key={s.id} className="py-4 space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-display font-bold text-slate-900">{s.name}</div>
                      <div className="text-xs text-slate-500">
                        {s.category_name} · Owner: {s.owner_name} ({s.owner_email} · {s.owner_phone})
                      </div>
                      <div className="text-xs text-slate-600 mt-0.5">
                        Address: {s.address}, {s.city} · CNIC/NTN: <span className="font-mono">{s.cnic_ntn}</span>
                      </div>
                    </div>
                    <span
                      className={`text-xs font-semibold ${
                        s.approval_status === 'APPROVED'
                          ? 'text-emerald-700'
                          : s.approval_status === 'PENDING'
                          ? 'text-amber-700'
                          : 'text-rose-700'
                      }`}
                    >
                      {s.approval_status}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="text"
                      value={rejectNotes[`shop-${s.id}`] || ''}
                      onChange={(e) =>
                        setRejectNotes((prev) => ({ ...prev, [`shop-${s.id}`]: e.target.value }))
                      }
                      placeholder="Optional note (for rejection/suspension)..."
                      className="flex-1 min-w-[160px] rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs"
                    />
                    {s.approval_status !== 'APPROVED' && (
                      <button
                        type="button"
                        onClick={() => handleShopApproval(s.id, 'APPROVED')}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
                      >
                        <Check className="w-3.5 h-3.5" />
                        Approve Shop
                      </button>
                    )}
                    {s.approval_status === 'PENDING' && (
                      <button
                        type="button"
                        onClick={() => handleShopApproval(s.id, 'REJECTED')}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-rose-200 text-rose-700 text-xs font-semibold hover:bg-rose-50"
                      >
                        <X className="w-3.5 h-3.5" />
                        Reject
                      </button>
                    )}
                    {s.approval_status === 'APPROVED' && (
                      <button
                        type="button"
                        onClick={() => handleShopApproval(s.id, 'SUSPENDED')}
                        className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 text-xs font-medium hover:bg-slate-50"
                      >
                        Suspend
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Rider Registrations */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
            <h2 className="font-display text-lg font-bold text-slate-900">
              Rider Registrations ({approvals.riders.length})
            </h2>
            <p className="text-xs text-slate-500">
              Only APPROVED riders can toggle Online and receive Smart Dispatch assignments.
            </p>

            <div className="divide-y divide-slate-100">
              {approvals.riders.map((r) => (
                <div key={r.id} className="py-4 space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-display font-bold text-slate-900">{r.rider_name}</div>
                      <div className="text-xs text-slate-500">
                        {r.rider_email} · {r.rider_phone} · {r.city}
                      </div>
                      <div className="text-xs text-slate-600 mt-0.5 font-mono">
                        CNIC: {r.cnic} · {r.vehicle_type} ({r.vehicle_plate}) · Cap: {r.max_capacity}
                      </div>
                    </div>
                    <span
                      className={`text-xs font-semibold ${
                        r.approval_status === 'APPROVED'
                          ? 'text-emerald-700'
                          : r.approval_status === 'PENDING'
                          ? 'text-amber-700'
                          : 'text-rose-700'
                      }`}
                    >
                      {r.approval_status}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="text"
                      value={rejectNotes[`rider-${r.id}`] || ''}
                      onChange={(e) =>
                        setRejectNotes((prev) => ({ ...prev, [`rider-${r.id}`]: e.target.value }))
                      }
                      placeholder="Optional note..."
                      className="flex-1 min-w-[160px] rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs"
                    />
                    {r.approval_status !== 'APPROVED' && (
                      <button
                        type="button"
                        onClick={() => handleRiderApproval(r.id, 'APPROVED')}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
                      >
                        <Check className="w-3.5 h-3.5" />
                        Approve Rider
                      </button>
                    )}
                    {r.approval_status === 'PENDING' && (
                      <button
                        type="button"
                        onClick={() => handleRiderApproval(r.id, 'REJECTED')}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-rose-200 text-rose-700 text-xs font-semibold hover:bg-rose-50"
                      >
                        <X className="w-3.5 h-3.5" />
                        Reject
                      </button>
                    )}
                    {r.approval_status === 'APPROVED' && (
                      <button
                        type="button"
                        onClick={() => handleRiderApproval(r.id, 'SUSPENDED')}
                        className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 text-xs font-medium hover:bg-slate-50"
                      >
                        Suspend
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: PARENT ORDERS, SUB-ORDERS & MANUAL RIDER DISPATCH */}
      {tab === 'ORDERS' && (
        <div className="space-y-6">
          {selectedMapSub && (
            <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display font-bold text-sm text-slate-900">
                  Live Sub-Order Monitor: {selectedMapSub.sub.sub_order_number} ({selectedMapSub.sub.shop_name})
                </h3>
                <button
                  type="button"
                  onClick={() => setSelectedMapSub(null)}
                  className="text-xs text-slate-500 hover:text-slate-900"
                >
                  Close Map
                </button>
              </div>
              <LiveTrackingMap
                shopPoint={{
                  lat: selectedMapSub.sub.shop_lat,
                  lng: selectedMapSub.sub.shop_lng,
                  label: selectedMapSub.sub.shop_name,
                }}
                customerPoint={
                  selectedMapSub.parent.delivery_lat && selectedMapSub.parent.delivery_lng
                    ? {
                        lat: selectedMapSub.parent.delivery_lat,
                        lng: selectedMapSub.parent.delivery_lng,
                        label: selectedMapSub.parent.delivery_address,
                      }
                    : null
                }
                riderPoint={
                  selectedMapSub.sub.rider_lat && selectedMapSub.sub.rider_lng
                    ? {
                        lat: selectedMapSub.sub.rider_lat,
                        lng: selectedMapSub.sub.rider_lng,
                        label: selectedMapSub.sub.rider_name || 'Rider',
                        lastGpsAt: selectedMapSub.sub.last_gps_at,
                      }
                    : null
                }
              />
            </div>
          )}

          {ordersData.parentOrders.length === 0 ? (
            <div className="p-8 rounded-2xl border border-slate-200 text-center text-sm text-slate-500">
              No marketplace orders recorded yet.
            </div>
          ) : (
            ordersData.parentOrders.map((po) => (
              <div key={po.id} className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
                <div className="px-6 py-3.5 bg-slate-50 border-b border-slate-200 flex flex-wrap justify-between gap-2 text-xs">
                  <div>
                    <span className="font-mono font-bold text-slate-900 text-sm">{po.order_number}</span> · Customer:{' '}
                    {po.customer_name} ({po.customer_email}) · {po.payment_method} ({po.payment_status})
                  </div>
                  <div className="font-mono font-bold text-slate-900 tabular-nums">
                    Total PKR {Number(po.total_amount).toLocaleString()} · {po.overall_status}
                  </div>
                </div>

                <div className="divide-y divide-slate-100">
                  {po.subOrders.map((so: any) => (
                    <div key={so.id} className="px-6 py-4 flex flex-wrap items-center justify-between gap-4">
                      <div>
                        <div className="text-sm font-semibold text-slate-900">
                          <span className="font-mono text-emerald-700 mr-2">{so.sub_order_number}</span>
                          {so.shop_name}
                        </div>
                        <div className="text-xs text-slate-500 mt-0.5">
                          Shop: {so.shop_status} · Delivery: {so.delivery_status} · Rider:{' '}
                          {so.rider_name ? `${so.rider_name} (${so.vehicle_plate})` : so.own_rider_info || 'Unassigned'}
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedMapSub({ parent: po, sub: so })}
                          className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:border-emerald-500"
                        >
                          Monitor Map
                        </button>

                        {!['DELIVERED', 'CANCELLED'].includes(so.delivery_status) && (
                          <select
                            defaultValue=""
                            onChange={(e) => {
                              if (e.target.value) handleManualAssignRider(so.id, Number(e.target.value));
                              e.target.value = '';
                            }}
                            className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs bg-white"
                          >
                            <option value="">Assign / Reassign Rider...</option>
                            {ordersData.eligibleRiders.map((r: any) => (
                              <option key={r.id} value={r.id}>
                                {r.rider_name} ({r.is_online ? 'Online' : 'Offline'} · {r.active_deliveries}/
                                {r.max_capacity})
                              </option>
                            ))}
                          </select>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 4: ACCOUNTS & CATEGORIES */}
      {tab === 'USERS' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 rounded-2xl border border-slate-200 bg-white overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100">
              <h2 className="font-display text-base font-bold text-slate-900">Marketplace User Accounts</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                  <tr>
                    <th className="px-4 py-3">Name</th>
                    <th className="px-4 py-3">Email</th>
                    <th className="px-4 py-3">Role</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {usersData.users.map((u) => (
                    <tr key={u.id}>
                      <td className="px-4 py-2.5 font-medium text-slate-900">{u.name}</td>
                      <td className="px-4 py-2.5 text-slate-600">{u.email}</td>
                      <td className="px-4 py-2.5 text-slate-700">{u.role}</td>
                      <td className="px-4 py-2.5">{u.status}</td>
                      <td className="px-4 py-2.5 text-right">
                        {u.role !== 'ADMIN' && (
                          <button
                            type="button"
                            onClick={async () => {
                              await apiRequest(`/api/admin/users/${u.id}/status`, {
                                method: 'POST',
                                body: JSON.stringify({
                                  status: u.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE',
                                }),
                              });
                              await loadAll();
                              showToast(`Updated ${u.name}`);
                            }}
                            className="font-medium text-emerald-700 hover:underline"
                          >
                            {u.status === 'ACTIVE' ? 'Suspend' : 'Activate'}
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="lg:col-span-4 rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
            <h2 className="font-display text-base font-bold text-slate-900">Manage Categories</h2>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                await apiRequest('/api/admin/categories', {
                  method: 'POST',
                  body: JSON.stringify({ name: newCatName, description: newCatDesc }),
                });
                setNewCatName('');
                setNewCatDesc('');
                await loadAll();
                showToast('Category added.');
              }}
              className="space-y-3"
            >
              <input
                type="text"
                required
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                placeholder="New category name"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
              />
              <input
                type="text"
                value={newCatDesc}
                onChange={(e) => setNewCatDesc(e.target.value)}
                placeholder="Description"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"
              />
              <button
                type="submit"
                className="w-full py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
              >
                Add Category
              </button>
            </form>

            <div className="divide-y divide-slate-100 text-xs">
              {usersData.categories.map((c: any) => (
                <div key={c.id} className="py-2 font-medium text-slate-800">
                  {c.name}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: COUPONS, REFUNDS, SUPPORT & AUDIT LOGS */}
      {tab === 'OPERATIONS' && opsData && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Coupons */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
              <h3 className="font-display text-base font-bold text-slate-900">Marketplace Coupons</h3>
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  try {
                    await apiRequest('/api/admin/coupons', {
                      method: 'POST',
                      body: JSON.stringify({
                        code: cpCode,
                        discountType: cpType,
                        discountValue: Number(cpVal),
                        minOrderAmount: Number(cpMin),
                      }),
                    });
                    setCpCode('');
                    await loadAll();
                    showToast('Coupon created!');
                  } catch (err) {
                    showToast(err instanceof Error ? err.message : 'Failed');
                  }
                }}
                className="grid grid-cols-2 sm:grid-cols-4 gap-2"
              >
                <input
                  type="text"
                  required
                  value={cpCode}
                  onChange={(e) => setCpCode(e.target.value.toUpperCase())}
                  placeholder="CODE"
                  className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs font-mono uppercase"
                />
                <select
                  value={cpType}
                  onChange={(e) => setCpType(e.target.value as any)}
                  className="rounded-lg border border-slate-300 px-2 py-1.5 text-xs bg-white"
                >
                  <option value="PERCENTAGE">% Off</option>
                  <option value="FIXED">PKR Off</option>
                </select>
                <input
                  type="number"
                  required
                  value={cpVal}
                  onChange={(e) => setCpVal(e.target.value)}
                  placeholder="Value"
                  className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs font-mono"
                />
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700"
                >
                  Create
                </button>
              </form>

              <div className="divide-y divide-slate-100 text-xs tabular-nums">
                {opsData.coupons.map((cp: any) => (
                  <div key={cp.id} className="py-2 flex items-center justify-between">
                    <div>
                      <span className="font-mono font-bold text-slate-900">{cp.code}</span> ·{' '}
                      {cp.discount_type === 'PERCENTAGE' ? `${cp.discount_value}%` : `PKR ${cp.discount_value}`} (min
                      PKR {cp.min_order_amount}) · Used {cp.used_count}/{cp.usage_limit}
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await apiRequest(`/api/admin/coupons/${cp.id}/toggle`, { method: 'POST' });
                        await loadAll();
                      }}
                      className="font-medium text-emerald-700 hover:underline"
                    >
                      {cp.is_active ? 'Disable' : 'Enable'}
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Refunds Reconciliation */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
              <h3 className="font-display text-base font-bold text-slate-900">Sub-Order Refunds</h3>
              {opsData.refunds.length === 0 ? (
                <p className="text-xs text-slate-500">No refund requests submitted.</p>
              ) : (
                <div className="divide-y divide-slate-100 text-xs space-y-2">
                  {opsData.refunds.map((rf: any) => (
                    <div key={rf.id} className="py-2.5 flex items-center justify-between gap-2">
                      <div>
                        <div className="font-semibold text-slate-900">
                          {rf.sub_order_number} ({rf.shop_name}) — PKR {rf.amount}
                        </div>
                        <div className="text-slate-600">
                          {rf.customer_name}: {rf.reason} · Status: <strong>{rf.status}</strong>
                        </div>
                      </div>
                      {rf.status === 'REQUESTED' && (
                        <div className="flex gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={async () => {
                              await apiRequest(`/api/admin/refunds/${rf.id}/resolve`, {
                                method: 'POST',
                                body: JSON.stringify({ status: 'APPROVED', adminNote: 'Approved by Admin' }),
                              });
                              await loadAll();
                              showToast('Refund approved');
                            }}
                            className="px-2.5 py-1 rounded bg-emerald-600 text-white font-semibold"
                          >
                            Approve
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              await apiRequest(`/api/admin/refunds/${rf.id}/resolve`, {
                                method: 'POST',
                                body: JSON.stringify({ status: 'REJECTED', adminNote: 'Declined after review' }),
                              });
                              await loadAll();
                              showToast('Refund declined');
                            }}
                            className="px-2.5 py-1 rounded border border-rose-200 text-rose-700"
                          >
                            Reject
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Support / Feedback Tickets & Audit Logs */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-3">
              <h3 className="font-display text-base font-bold text-slate-900">
                Support Tickets & User Feedback ({opsData.tickets.length})
              </h3>
              {opsData.tickets.length === 0 ? (
                <p className="text-xs text-slate-500">No support tickets or complaints yet.</p>
              ) : (
                <div className="divide-y divide-slate-100 text-xs max-h-72 overflow-y-auto">
                  {opsData.tickets.map((t: any) => (
                    <div key={t.id} className="py-3 space-y-2">
                      <div className="font-semibold text-slate-900">
                        [{t.type}] {t.subject} — {t.user_name} ({t.status})
                      </div>
                      <p className="text-slate-600">{t.message}</p>
                      {t.admin_reply ? (
                        <p className="text-emerald-700">Reply: {t.admin_reply}</p>
                      ) : (
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={ticketReplies[t.id] || ''}
                            onChange={(e) =>
                              setTicketReplies((prev) => ({ ...prev, [t.id]: e.target.value }))
                            }
                            placeholder="Write official reply..."
                            className="flex-1 rounded border border-slate-200 px-2 py-1"
                          />
                          <button
                            type="button"
                            onClick={async () => {
                              await apiRequest(`/api/admin/tickets/${t.id}/reply`, {
                                method: 'POST',
                                body: JSON.stringify({ reply: ticketReplies[t.id] || 'Resolved by DELIVOO Support' }),
                              });
                              await loadAll();
                              showToast('Reply sent');
                            }}
                            className="px-3 py-1 rounded bg-slate-900 text-white font-medium"
                          >
                            Reply
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-3">
              <h3 className="font-display text-base font-bold text-slate-900">Security & Admin Audit Logs</h3>
              <div className="divide-y divide-slate-100 text-xs max-h-72 overflow-y-auto tabular-nums">
                {opsData.auditLogs.map((log: any) => (
                  <div key={log.id} className="py-2">
                    <div className="font-mono font-semibold text-slate-800">
                      {log.action} · {log.actor_role}
                    </div>
                    <div className="text-slate-600">
                      {log.details} ({new Date(log.created_at).toLocaleString()})
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
