import L from 'leaflet';
import { useEffect, useRef } from 'react';

interface MapPoint {
  lat: number;
  lng: number;
  label: string;
}

interface LiveTrackingMapProps {
  shopPoint?: MapPoint | null;
  customerPoint?: MapPoint | null;
  riderPoint?: (MapPoint & { lastGpsAt?: string | null }) | null;
  interactivePin?: { lat: number; lng: number } | null;
  onSelectPin?: (lat: number, lng: number) => void;
  heightClass?: string;
}

function makePinIcon(bgHex: string, shortText: string) {
  return L.divIcon({
    className: 'delivoo-custom-pin',
    html: `<div style="background:${bgHex};color:#fff;width:30px;height:30px;border-radius:9999px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:11px;border:2px solid #fff;box-shadow:0 2px 8px rgba(15,23,42,0.28);">${shortText}</div>`,
    iconSize: [30, 30],
    iconAnchor: [15, 15],
  });
}

export function LiveTrackingMap({
  shopPoint,
  customerPoint,
  riderPoint,
  interactivePin,
  onSelectPin,
  heightClass = 'h-64',
}: LiveTrackingMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const initialCenter: [number, number] = interactivePin
      ? [interactivePin.lat, interactivePin.lng]
      : riderPoint
      ? [riderPoint.lat, riderPoint.lng]
      : shopPoint
      ? [shopPoint.lat, shopPoint.lng]
      : customerPoint
      ? [customerPoint.lat, customerPoint.lng]
      : [31.5102, 74.3441];

    const map = L.map(containerRef.current, {
      center: initialCenter,
      zoom: 13,
      attributionControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(map);

    const group = L.layerGroup().addTo(map);
    mapRef.current = map;
    layerGroupRef.current = group;

    if (onSelectPin) {
      map.on('click', (e: L.LeafletMouseEvent) => {
        onSelectPin(Number(e.latlng.lat.toFixed(6)), Number(e.latlng.lng.toFixed(6)));
      });
    }

    setTimeout(() => map.invalidateSize(), 150);

    return () => {
      map.remove();
      mapRef.current = null;
      layerGroupRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    const group = layerGroupRef.current;
    if (!map || !group) return;

    group.clearLayers();
    const boundsPoints: [number, number][] = [];

    if (interactivePin) {
      const m = L.marker([interactivePin.lat, interactivePin.lng], {
        icon: makePinIcon('#059669', 'PIN'),
      }).bindPopup('Selected Location');
      group.addLayer(m);
      boundsPoints.push([interactivePin.lat, interactivePin.lng]);
    }

    if (shopPoint) {
      const m = L.marker([shopPoint.lat, shopPoint.lng], {
        icon: makePinIcon('#0f172a', 'S'),
      }).bindPopup(`<strong>Shop:</strong> ${shopPoint.label}`);
      group.addLayer(m);
      boundsPoints.push([shopPoint.lat, shopPoint.lng]);
    }

    if (customerPoint) {
      const m = L.marker([customerPoint.lat, customerPoint.lng], {
        icon: makePinIcon('#2563eb', 'C'),
      }).bindPopup(`<strong>Destination:</strong> ${customerPoint.label}`);
      group.addLayer(m);
      boundsPoints.push([customerPoint.lat, customerPoint.lng]);
    }

    if (riderPoint) {
      const m = L.marker([riderPoint.lat, riderPoint.lng], {
        icon: makePinIcon('#059669', 'R'),
      }).bindPopup(
        `<strong>Rider:</strong> ${riderPoint.label}${
          riderPoint.lastGpsAt ? `<br/><small>GPS: ${new Date(riderPoint.lastGpsAt).toLocaleTimeString()}</small>` : ''
        }`
      );
      group.addLayer(m);
      boundsPoints.push([riderPoint.lat, riderPoint.lng]);
    }

    // Draw route polyline
    const routeCoords: [number, number][] = [];
    if (shopPoint) routeCoords.push([shopPoint.lat, shopPoint.lng]);
    if (riderPoint) routeCoords.push([riderPoint.lat, riderPoint.lng]);
    if (customerPoint) routeCoords.push([customerPoint.lat, customerPoint.lng]);

    if (routeCoords.length >= 2) {
      const line = L.polyline(routeCoords, {
        color: '#059669',
        weight: 3,
        dashArray: '6, 6',
      });
      group.addLayer(line);
    }

    if (boundsPoints.length >= 2) {
      map.fitBounds(L.latLngBounds(boundsPoints), { padding: [32, 32], maxZoom: 15 });
    } else if (boundsPoints.length === 1) {
      map.setView(boundsPoints[0], 14);
    }
  }, [shopPoint, customerPoint, riderPoint, interactivePin]);

  return (
    <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-50">
      <div ref={containerRef} className={`w-full ${heightClass}`} />
      <div className="px-3 py-2 bg-white border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
        <div className="flex items-center gap-3">
          {shopPoint && <span>S: Shop Pickup</span>}
          {riderPoint && <span>· R: Live Rider GPS</span>}
          {customerPoint && <span>· C: Customer Dropoff</span>}
          {onSelectPin && <span>Tap anywhere on map to adjust coordinates</span>}
        </div>
        {!riderPoint && (shopPoint || customerPoint) && !onSelectPin && (
          <span>Awaiting live rider GPS signal</span>
        )}
        {riderPoint?.lastGpsAt && (
          <span className="font-mono tabular-nums">
            Last GPS: {new Date(riderPoint.lastGpsAt).toLocaleTimeString()}
          </span>
        )}
      </div>
    </div>
  );
}
