import { ArrowLeft, Bike, ShieldCheck, ShoppingBag, Store } from 'lucide-react';
import { motion } from 'motion/react';
import React, { useEffect, useState } from 'react';
import { apiRequest } from '../lib/api';
import type { SessionData, UserRole } from '../types';

interface RoleAuthPortalProps {
  initialSelectedRole?: UserRole | null;
  onAuthenticated: (session: SessionData) => void;
}

const ROLE_CARDS: {
  role: UserRole;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  {
    role: 'CUSTOMER',
    title: 'Customer',
    description: 'Discover nearby shops, browse products, place orders and track deliveries.',
    icon: ShoppingBag,
  },
  {
    role: 'SHOPKEEPER',
    title: 'Shopkeeper',
    description: 'Manage a shop, products, inventory, orders, schedules and earnings.',
    icon: Store,
  },
  {
    role: 'RIDER',
    title: 'Rider',
    description: 'Accept delivery requests, manage active deliveries and view earnings.',
    icon: Bike,
  },
  {
    role: 'ADMIN',
    title: 'Admin',
    description: 'Manage the complete DELIVOO marketplace.',
    icon: ShieldCheck,
  },
];

const CATEGORIES = [
  'Food',
  'Grocery',
  'Bakery',
  'Clothing',
  'Pharmacy',
  'Electronics',
  'Beauty & Personal Care',
  'Household Products',
];

export function RoleAuthPortal({ initialSelectedRole = null, onAuthenticated }: RoleAuthPortalProps) {
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(initialSelectedRole);
  const [mode, setMode] = useState<'LOGIN' | 'REGISTER' | 'RESET'>('LOGIN');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  // Common auth fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('+92300');
  const [password, setPassword] = useState('');
  const [city, setCity] = useState('Lahore');
  const [addressLine, setAddressLine] = useState('');

  // Shopkeeper registration fields
  const [shopName, setShopName] = useState('');
  const [categoryName, setCategoryName] = useState('Grocery');
  const [shopAddress, setShopAddress] = useState('');
  const [shopDescription, setShopDescription] = useState('');
  const [cnicNtn, setCnicNtn] = useState('');
  const [deliveryFee, setDeliveryFee] = useState('120');
  const [lat, setLat] = useState<number | undefined>(undefined);
  const [lng, setLng] = useState<number | undefined>(undefined);

  // Rider registration fields
  const [cnic, setCnic] = useState('');
  const [vehicleType, setVehicleType] = useState('Motorcycle');
  const [vehiclePlate, setVehiclePlate] = useState('');
  const [maxCapacity, setMaxCapacity] = useState('3');

  // Password reset fields
  const [resetStep, setResetStep] = useState<'REQUEST' | 'VERIFY'>('REQUEST');
  const [otpCode, setOtpCode] = useState('');
  const [newPassword, setNewPassword] = useState('');

  // Sandbox quick-fill accounts (enabled in dev/preview)
  const [sandboxAccounts, setSandboxAccounts] = useState<
    { role: UserRole; label: string; email: string; password: string }[]
  >([]);

  useEffect(() => {
    setSelectedRole(initialSelectedRole);
    setMode('LOGIN');
    setError('');
    setNotice('');
  }, [initialSelectedRole]);

  useEffect(() => {
    apiRequest<{ enabled: boolean; accounts: any[] }>('/api/auth/sandbox-accounts')
      .then((res) => {
        if (res.enabled) setSandboxAccounts(res.accounts || []);
      })
      .catch(() => {});
  }, []);

  const detectBrowserGps = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLat(Number(pos.coords.latitude.toFixed(6)));
        setLng(Number(pos.coords.longitude.toFixed(6)));
        setNotice(`Detected coordinates: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`);
      },
      () => {
        setError('Location permission declined. Default city coordinates will be used.');
      }
    );
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole) return;
    setError('');
    setNotice('');
    setLoading(true);
    try {
      const res = await apiRequest<SessionData>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({
          email,
          password,
          expectedRole: selectedRole,
        }),
      });
      onAuthenticated(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign in failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole || selectedRole === 'ADMIN') return;
    setError('');
    setNotice('');
    setLoading(true);
    try {
      const res = await apiRequest<SessionData & { message?: string }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({
          role: selectedRole,
          name,
          email,
          phone,
          password,
          city,
          addressLine,
          shopName,
          categoryName,
          shopAddress,
          shopDescription,
          cnicNtn,
          deliveryFee: Number(deliveryFee),
          lat,
          lng,
          cnic,
          vehicleType,
          vehiclePlate,
          maxCapacity: Number(maxCapacity),
        }),
      });
      onAuthenticated(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleRequestOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setNotice('');
    setLoading(true);
    try {
      const res = await apiRequest<{ message: string; devOtpPreview?: string }>('/api/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email }),
      });
      setNotice(
        res.devOtpPreview
          ? `${res.message} Verification OTP: ${res.devOtpPreview}`
          : res.message
      );
      if (res.devOtpPreview) setOtpCode(res.devOtpPreview);
      setResetStep('VERIFY');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not initiate password reset.');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await apiRequest<{ message: string }>('/api/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify({ email, otp: otpCode, newPassword }),
      });
      setNotice(res.message);
      setMode('LOGIN');
      setPassword('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Password reset failed.');
    } finally {
      setLoading(false);
    }
  };

  // STEP 1: FOUR ROLE-BASED ENTRY SCREEN
  if (!selectedRole) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-8 py-12 sm:py-16">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="text-center max-w-xl mx-auto"
        >
          <img
            src="/assets/aistudio/Delivoo_Scooter_Delivery_Logo_73c58518.png"
            alt="DELIVOO Scooter Mascot"
            referrerPolicy="no-referrer"
            className="w-20 h-20 object-contain mx-auto mb-5 rounded-2xl"
          />
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900">
            Welcome to DELIV<span className="text-emerald-600">OO</span>
          </h1>
          <p className="mt-2.5 text-lg font-medium text-slate-600">Who are you?</p>
        </motion.div>

        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-5">
          {ROLE_CARDS.map((card, index) => {
            const Icon = card.icon;
            return (
              <motion.button
                key={card.role}
                type="button"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05, duration: 0.25 }}
                onClick={() => {
                  setSelectedRole(card.role);
                  setMode('LOGIN');
                  setError('');
                  setNotice('');
                }}
                className="group text-left p-6 rounded-2xl border border-slate-200 bg-white hover:border-emerald-500 hover:shadow-md transition-all focus-visible:outline-2 focus-visible:outline-emerald-600"
              >
                <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                  <Icon className="w-5 h-5" />
                </div>
                <h2 className="mt-4 font-display text-xl font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                  {card.title}
                </h2>
                <p className="mt-1.5 text-sm text-slate-600 leading-relaxed">{card.description}</p>
                {(card.role === 'SHOPKEEPER' || card.role === 'RIDER') && (
                  <p className="mt-3 text-xs text-slate-500">
                    Self-registration supported · Activated after Admin approval
                  </p>
                )}
              </motion.button>
            );
          })}
        </div>
      </div>
    );
  }

  const roleMatches = sandboxAccounts.filter((a) => a.role === selectedRole);

  // STEP 2: ROLE-SPECIFIC LOGIN / SELF-REGISTRATION / PASSWORD RESET
  return (
    <div className="max-w-xl mx-auto px-4 sm:px-6 py-10">
      <button
        type="button"
        onClick={() => setSelectedRole(null)}
        className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-600 hover:text-slate-900 mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to role selection
      </button>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 shadow-sm">
        <div className="flex items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <p className="text-xs font-medium text-emerald-700">Selected Portal</p>
            <h1 className="font-display text-2xl font-bold text-slate-900 mt-0.5">
              {selectedRole.charAt(0) + selectedRole.slice(1).toLowerCase()} Access
            </h1>
          </div>

          {/* Public users can NEVER register as ADMIN */}
          {selectedRole !== 'ADMIN' && (
            <div className="flex p-1 bg-slate-100 rounded-lg shrink-0">
              <button
                type="button"
                onClick={() => {
                  setMode('LOGIN');
                  setError('');
                }}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  mode === 'LOGIN' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('REGISTER');
                  setError('');
                }}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  mode === 'REGISTER' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                }`}
              >
                Register
              </button>
            </div>
          )}
        </div>

        {/* Sandbox quick-fill bar in preview mode */}
        {mode === 'LOGIN' && roleMatches.length > 0 && (
          <div className="mt-4 p-3 rounded-xl bg-slate-50 border border-slate-200/80">
            <p className="text-xs text-slate-500 mb-2">Quick-fill test credentials for {selectedRole}:</p>
            <div className="flex flex-wrap gap-2">
              {roleMatches.map((acc) => (
                <button
                  key={acc.email}
                  type="button"
                  onClick={() => {
                    setEmail(acc.email);
                    setPassword(acc.password);
                  }}
                  className="px-2.5 py-1 rounded-md bg-white border border-slate-200 hover:border-emerald-500 text-xs font-medium text-slate-700 transition-colors"
                >
                  {acc.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {error && (
          <div className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-700">
            {error}
          </div>
        )}
        {notice && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-sm text-emerald-800">
            {notice}
          </div>
        )}

        {/* LOGIN FORM */}
        {mode === 'LOGIN' && (
          <form onSubmit={handleLogin} className="mt-5 space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:outline-none focus:border-emerald-600"
              />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-medium text-slate-700">Password</label>
                <button
                  type="button"
                  onClick={() => {
                    setMode('RESET');
                    setResetStep('REQUEST');
                    setError('');
                  }}
                  className="text-xs text-emerald-700 hover:underline"
                >
                  Forgot password?
                </button>
              </div>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:outline-none focus:border-emerald-600"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700 transition-colors disabled:opacity-60"
            >
              {loading ? 'Authenticating...' : `Sign In as ${selectedRole.charAt(0) + selectedRole.slice(1).toLowerCase()}`}
            </button>
          </form>
        )}

        {/* REGISTRATION FORM (Customer / Shopkeeper / Rider) */}
        {mode === 'REGISTER' && selectedRole !== 'ADMIN' && (
          <form onSubmit={handleRegister} className="mt-5 space-y-4">
            {(selectedRole === 'SHOPKEEPER' || selectedRole === 'RIDER') && (
              <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 leading-relaxed">
                <strong>Verification & Admin Approval Policy:</strong> Complete your first-time{' '}
                {selectedRole === 'SHOPKEEPER' ? 'Shopkeeper & Store' : 'Rider & Vehicle'} registration below.
                Your application will be sent to the DELIVOO Admin queue and you will be added to the live marketplace as soon as Admin approves your profile.
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Muhammad Usman"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Phone Number</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+923001234567"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@domain.pk"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Password (min 6 chars)</label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
            </div>

            {selectedRole === 'CUSTOMER' && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">City</label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 mb-1">Delivery Address (Optional)</label>
                  <input
                    type="text"
                    value={addressLine}
                    onChange={(e) => setAddressLine(e.target.value)}
                    placeholder="House / Street / Block"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
              </div>
            )}

            {selectedRole === 'SHOPKEEPER' && (
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Shop Name *</label>
                    <input
                      type="text"
                      required
                      value={shopName}
                      onChange={(e) => setShopName(e.target.value)}
                      placeholder="Al-Barakah Mart"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Primary Category *</label>
                    <select
                      value={categoryName}
                      onChange={(e) => setCategoryName(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                    >
                      {CATEGORIES.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Owner CNIC or NTN *</label>
                    <input
                      type="text"
                      required
                      value={cnicNtn}
                      onChange={(e) => setCnicNtn(e.target.value)}
                      placeholder="35202-1234567-1"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Delivery Fee (PKR)</label>
                    <input
                      type="number"
                      min={0}
                      value={deliveryFee}
                      onChange={(e) => setDeliveryFee(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">City *</label>
                    <input
                      type="text"
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-slate-700 mb-1">Shop Street Address *</label>
                    <input
                      type="text"
                      required
                      value={shopAddress}
                      onChange={(e) => setShopAddress(e.target.value)}
                      placeholder="Shop 14, Main Commercial Market"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Shop Description</label>
                  <input
                    type="text"
                    value={shopDescription}
                    onChange={(e) => setShopDescription(e.target.value)}
                    placeholder="What products do you specialize in?"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>

                <button
                  type="button"
                  onClick={detectBrowserGps}
                  className="text-xs font-medium text-emerald-700 hover:underline"
                >
                  Use current GPS coordinates for shop pin
                </button>
              </div>
            )}

            {selectedRole === 'RIDER' && (
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">CNIC Number *</label>
                    <input
                      type="text"
                      required
                      value={cnic}
                      onChange={(e) => setCnic(e.target.value)}
                      placeholder="35202-7654321-9"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Vehicle Plate Number *</label>
                    <input
                      type="text"
                      required
                      value={vehiclePlate}
                      onChange={(e) => setVehiclePlate(e.target.value)}
                      placeholder="LEP-2045"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm uppercase"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Vehicle Type</label>
                    <select
                      value={vehicleType}
                      onChange={(e) => setVehicleType(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                    >
                      <option value="Motorcycle">Motorcycle</option>
                      <option value="Scooter">Scooter</option>
                      <option value="Bicycle">Bicycle</option>
                      <option value="Car">Car</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">City</label>
                    <input
                      type="text"
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Max Capacity</label>
                    <select
                      value={maxCapacity}
                      onChange={(e) => setMaxCapacity(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                    >
                      <option value="1">1 Order</option>
                      <option value="2">2 Orders</option>
                      <option value="3">3 Orders</option>
                      <option value="4">4 Orders</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700 transition-colors disabled:opacity-60"
            >
              {loading
                ? 'Submitting Registration...'
                : selectedRole === 'CUSTOMER'
                ? 'Create Customer Account'
                : `Submit ${selectedRole.charAt(0) + selectedRole.slice(1).toLowerCase()} Registration for Admin Approval`}
            </button>
          </form>
        )}

        {/* OTP PASSWORD RESET */}
        {mode === 'RESET' && (
          <div className="mt-5">
            {resetStep === 'REQUEST' ? (
              <form onSubmit={handleRequestOtp} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Registered Email</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700"
                >
                  Send 6-Digit Reset OTP
                </button>
              </form>
            ) : (
              <form onSubmit={handleResetPassword} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">6-Digit OTP Code</label>
                  <input
                    type="text"
                    required
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">New Password</label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700"
                >
                  Verify OTP & Update Password
                </button>
              </form>
            )}
            <button
              type="button"
              onClick={() => setMode('LOGIN')}
              className="mt-3 text-xs text-slate-500 hover:text-slate-800"
            >
              Return to Sign In
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
