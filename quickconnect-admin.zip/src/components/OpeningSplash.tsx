import { motion, useReducedMotion } from 'motion/react';
import { useEffect } from 'react';

interface OpeningSplashProps {
  onComplete: () => void;
}

/**
 * Section 3: Opening Screen — Custom Supplied Image with Lightweight Animation
 * Uses ONLY the supplied image (/assets/aistudio/Delivoo_Scooter_Delivery_Logo_73c58518.png).
 * Shows only the essential visual and DELIVOO branding, then automatically transitions to Role Selection.
 */
export function OpeningSplash({ onComplete }: OpeningSplashProps) {
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    const duration = prefersReducedMotion ? 700 : 2350;
    const timer = setTimeout(() => {
      onComplete();
    }, duration);
    return () => clearTimeout(timer);
  }, [onComplete, prefersReducedMotion]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] } }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-white px-6 select-none"
      aria-label="DELIVOO Opening Screen"
    >
      <div className="flex flex-col items-center max-w-sm w-full">
        <motion.div
          initial={
            prefersReducedMotion
              ? { opacity: 0 }
              : { opacity: 0, scale: 0.88, y: 18 }
          }
          animate={
            prefersReducedMotion
              ? { opacity: 1 }
              : { opacity: 1, scale: 1, y: 0 }
          }
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="relative"
        >
          <motion.img
            src="/assets/aistudio/Delivoo_Scooter_Delivery_Logo_73c58518.png"
            alt="DELIVOO Scooter Delivery Mascot and Logo"
            referrerPolicy="no-referrer"
            animate={
              prefersReducedMotion
                ? undefined
                : {
                    x: [0, 5, 0],
                    y: [0, -3, 0],
                  }
            }
            transition={{
              duration: 1.8,
              ease: 'easeInOut',
              repeat: 0,
            }}
            className="w-56 h-56 sm:w-64 sm:h-64 object-contain rounded-3xl shadow-sm"
          />
        </motion.div>

        <motion.div
          initial={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: prefersReducedMotion ? 0.1 : 0.38, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="mt-6 text-center"
        >
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900">
            DELIV<span className="text-emerald-600">OO</span>
          </h1>
          <div className="mt-4 w-36 h-1 bg-slate-100 rounded-full overflow-hidden mx-auto">
            <motion.div
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{
                duration: prefersReducedMotion ? 0.5 : 1.8,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="h-full bg-emerald-600 origin-left"
            />
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
