import { MessageCircle, Send, User, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import React, { useEffect, useRef, useState } from 'react';
import { apiRequest, getSavedAccounts, removeSavedAccount } from '../lib/api';
import type { SavedAccountSlot, SessionData, UserRole } from '../types';

interface GlobalChromeProps {
  session: SessionData | null;
  onLogoClick: () => void;
  onLogout: () => Promise<void>;
  onSwitchSessionToken: (token: string) => Promise<void>;
  onOpenRolePortalForSwitch: (role?: UserRole) => void;
  onSessionRefresh: () => Promise<void>;
  children: React.ReactNode;
}

type LegalDocKey = 'terms' | 'refund' | 'shopkeeper' | 'rider' | 'helpline';

const LEGAL_DOCUMENTS: Record<LegalDocKey, { title: string; sections: { heading: string; body: string }[] }> = {
  terms: {
    title: 'Terms of Service — DELIVOO Pakistan',
    sections: [
      {
        heading: '1. Multi-Vendor Marketplace Scope',
        body: 'DELIVOO operates an electronic marketplace connecting verified retail shops, licensed pharmacies, restaurants, independent delivery riders, and customers across Pakistan. Each shop sub-order constitutes an independent fulfillment transaction.',
      },
      {
        heading: '2. Account Responsibility & Role Authorization',
        body: 'Users may only access dashboards authorized for their verified account role. Shopkeeper and Rider accounts remain non-public until explicitly reviewed and approved by DELIVOO Marketplace Administration.',
      },
      {
        heading: '3. Pricing, Taxes & Order Verification',
        body: 'All product prices, scheduled promotions, stock availability, and applicable taxes are verified server-side during checkout in Pakistan Rupees (PKR).',
      },
    ],
  },
  refund: {
    title: 'Refund & Cancellation Policy',
    sections: [
      {
        heading: '1. Independent Shop-Wise Cancellations',
        body: 'When a parent order includes multiple shops (e.g., DEL-1001-A and DEL-1001-B), cancelling or rejecting one shop sub-order never automatically cancels remaining shop sub-orders.',
      },
      {
        heading: '2. Full & Partial Refund Reconciliation',
        body: 'Customers may request full or partial refunds on any eligible sub-order for missing, damaged, expired, or rejected items. Prepaid online transactions (Easypaisa, JazzCash, Card) are reconciled per sub-order after Admin verification.',
      },
    ],
  },
  shopkeeper: {
    title: 'Shopkeeper Merchant Agreement',
    sections: [
      {
        heading: '1. Registration & Mandatory Admin Approval',
        body: 'Merchants must provide accurate shop identity, street coordinates, and CNIC/NTN details upon registration. Shops remain in PENDING state until approved by DELIVOO Admin.',
      },
      {
        heading: '2. Product Quality, Expiry & Time Schedules',
        body: 'Merchants are responsible for accurate stock counts, fresh batch dates, non-expired goods, and Asia/Karachi availability schedules. Applicable platform commission is deducted upon completed delivery settlement.',
      },
    ],
  },
  rider: {
    title: 'Delivery Rider Partner Agreement',
    sections: [
      {
        heading: '1. Identity & Vehicle Verification',
        body: 'Riders must register with valid CNIC and vehicle registration plate details. Rider dispatch access is unlocked only after DELIVOO Admin approval.',
      },
      {
        heading: '2. Road Safety, Capacity & Real GPS Sharing',
        body: 'Riders agree to comply with traffic regulations, carry orders within their configured capacity limit, and share authentic device geolocation only while actively online and fulfilling deliveries.',
      },
    ],
  },
  helpline: {
    title: 'DELIVOO 24/7 Helpline & Support Desk',
    sections: [
      {
        heading: 'Direct Contact Channels',
        body: 'Phone Helpline: +92-42-111-335-486 · Support Email: support@delivoo.pk · Hours: 24/7 Operations & Dispatch Desk (Pakistan Standard Time, UTC+5).',
      },
      {
        heading: 'In-App Escalation',
        body: 'Use the Help option in the account menu or the bottom-right Support Chat icon to check real-time order statuses or open a tracked human support ticket.',
      },
    ],
  },
};

export function GlobalChrome({
  session,
  onLogoClick,
  onLogout,
  onSwitchSessionToken,
  onOpenRolePortalForSwitch,
  onSessionRefresh,
  children,
}: GlobalChromeProps) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [activeModal, setActiveModal] = useState<'account' | 'switch' | 'feedback' | null>(null);
  const [legalKey, setLegalKey] = useState<LegalDocKey | null>(null);
  const [chatOpen, setChatOpen] = useState(false);

  // Account Info state
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editAddress, setEditAddress] = useState('');
  const [notifications, setNotifications] = useState<any[]>([]);
  const [accountMsg, setAccountMsg] = useState('');

  // Switch Account state
  const [savedAccounts, setSavedAccounts] = useState<SavedAccountSlot[]>([]);
  const [switchError, setSwitchError] = useState('');

  // Feedback state
  const [fbType, setFbType] = useState<'FEEDBACK' | 'COMPLAINT' | 'BUG'>('FEEDBACK');
  const [fbSubject, setFbSubject] = useState('');
  const [fbMessage, setFbMessage] = useState('');
  const [fbStatus, setFbStatus] = useState('');

  // Centralized Help Chatbot state
  const [chatMessages, setChatMessages] = useState<{ id?: number; sender: 'USER' | 'BOT'; message: string }[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [escalateMode, setEscalateMode] = useState(false);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketBody, setTicketBody] = useState('');
  const [ticketNotice, setTicketNotice] = useState('');

  const dropdownRef = useRef<HTMLDivElement | null>(null);
  const chatSessionKeyRef = useRef<string>(`sess-${Math.random().toString(36).slice(2, 10)}`);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const openAccountModal = async () => {
    setDropdownOpen(false);
    setAccountMsg('');
    if (session) {
      setEditName(session.user.name);
      setEditPhone(session.user.phone);
      setEditAddress(session.addresses?.[0]?.address_line || '');
      try {
        const res = await apiRequest<{ notifications: any[] }>('/api/auth/notifications');
        setNotifications(res.notifications || []);
        await apiRequest('/api/auth/notifications/read', { method: 'POST' });
        await onSessionRefresh();
      } catch {
        setNotifications([]);
      }
    }
    setActiveModal('account');
  };

  const openSwitchAccountModal = () => {
    setDropdownOpen(false);
    setSwitchError('');
    setSavedAccounts(getSavedAccounts());
    setActiveModal('switch');
  };

  const openHelpChat = async () => {
    setDropdownOpen(false);
    setChatOpen(true);
    try {
      const res = await apiRequest<{ messages: any[] }>(
        `/api/support/chatbot/history?sessionKey=${encodeURIComponent(chatSessionKeyRef.current)}`
      );
      if (res.messages && res.messages.length > 0) {
        setChatMessages(res.messages);
      } else {
        setChatMessages([
          {
            sender: 'BOT',
            message: session
              ? `Assalam-o-Alaikum ${session.user.name}! Ask me about your orders, approval status, payments, refunds, or platform features.`
              : 'Welcome to DELIVOO Help! Ask any question about ordering, Shopkeeper/Rider registration & approval, or payments.',
          },
        ]);
      }
    } catch {
      // Ignore initial history load error
    }
  };

  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || chatLoading) return;
    const outgoing = chatInput.trim();
    setChatInput('');
    setChatMessages((prev) => [...prev, { sender: 'USER', message: outgoing }]);
    setChatLoading(true);
    try {
      const res = await apiRequest<{ reply: string; messages: any[] }>('/api/support/chatbot/message', {
        method: 'POST',
        body: JSON.stringify({ message: outgoing, sessionKey: chatSessionKeyRef.current }),
      });
      setChatMessages(res.messages);
    } catch (err) {
      setChatMessages((prev) => [
        ...prev,
        { sender: 'BOT', message: err instanceof Error ? err.message : 'Unable to reach support service.' },
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiRequest('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify({ name: editName, phone: editPhone, addressLine: editAddress }),
      });
      await onSessionRefresh();
      setAccountMsg('Account details updated.');
    } catch (err) {
      setAccountMsg(err instanceof Error ? err.message : 'Update failed.');
    }
  };

  const handleSubmitFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    setFbStatus('');
    try {
      await apiRequest('/api/support/tickets', {
        method: 'POST',
        body: JSON.stringify({
          type: fbType,
          subject: fbSubject,
          message: fbMessage,
        }),
      });
      setFbSubject('');
      setFbMessage('');
      setFbStatus('Thank you! Your submission has been recorded for the DELIVOO team.');
    } catch (err) {
      setFbStatus(err instanceof Error ? err.message : 'Could not submit feedback.');
    }
  };

  const handleEscalateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await apiRequest<{ ticketId: number; message: string }>('/api/support/tickets', {
        method: 'POST',
        body: JSON.stringify({
          type: 'SUPPORT',
          subject: ticketSubject,
          message: ticketBody,
        }),
      });
      setTicketNotice(`Ticket #${res.ticketId} created! Admin support will respond in your notifications.`);
      setTicketSubject('');
      setTicketBody('');
      setEscalateMode(false);
    } catch (err) {
      setTicketNotice(err instanceof Error ? err.message : 'Ticket submission failed.');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900">
      {/* SECTION 5 & 23: MINIMAL GLOBAL HEADER (ONLY Left Logo + Right Account Icon) */}
      <header className="sticky top-0 z-30 h-16 bg-white/95 backdrop-blur border-b border-slate-200 px-4 sm:px-8 flex items-center justify-between">
        <button
          type="button"
          onClick={onLogoClick}
          className="flex items-center gap-2.5 focus-visible:outline-2 focus-visible:outline-emerald-600 rounded-lg py-1 whitespace-nowrap shrink-0"
        >
          <img
            src="/assets/aistudio/Delivoo_Scooter_Delivery_Logo_73c58518.png"
            alt="DELIVOO Logo"
            referrerPolicy="no-referrer"
            className="w-9 h-9 object-contain rounded-lg"
          />
          <span className="font-display text-xl font-extrabold tracking-tight text-slate-900">
            DELIV<span className="text-emerald-600">OO</span>
          </span>
        </button>

        <div className="relative shrink-0" ref={dropdownRef}>
          <button
            type="button"
            onClick={() => setDropdownOpen((o) => !o)}
            aria-label="Account Menu"
            aria-expanded={dropdownOpen}
            className="w-10 h-10 rounded-full border border-slate-200 bg-slate-50 hover:bg-emerald-50 hover:border-emerald-300 flex items-center justify-center text-slate-700 hover:text-emerald-700 transition-colors focus-visible:outline-2 focus-visible:outline-emerald-600"
          >
            <User className="w-5 h-5" />
          </button>

          {/* EXACT 5 DROPDOWN ITEMS REQUIRED BY SECTION 5 & 23 */}
          <AnimatePresence>
            {dropdownOpen && (
              <motion.div
                initial={{ opacity: 0, y: 6, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 4, scale: 0.98 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 mt-2 w-56 rounded-xl bg-white border border-slate-200 shadow-lg py-1.5 z-40"
              >
                <button
                  type="button"
                  onClick={openAccountModal}
                  className="w-full text-left px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 hover:text-slate-900 transition-colors whitespace-nowrap"
                >
                  Account Information
                </button>
                <button
                  type="button"
                  onClick={openSwitchAccountModal}
                  className="w-full text-left px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 hover:text-slate-900 transition-colors whitespace-nowrap"
                >
                  Switch Account
                </button>
                <button
                  type="button"
                  onClick={openHelpChat}
                  className="w-full text-left px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 hover:text-slate-900 transition-colors whitespace-nowrap"
                >
                  Help
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDropdownOpen(false);
                    setFbStatus('');
                    setActiveModal('feedback');
                  }}
                  className="w-full text-left px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 hover:text-slate-900 transition-colors whitespace-nowrap"
                >
                  Feedback
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    setDropdownOpen(false);
                    await onLogout();
                  }}
                  className="w-full text-left px-4 py-2.5 text-sm text-rose-600 hover:bg-rose-50 transition-colors border-t border-slate-100 mt-1 whitespace-nowrap"
                >
                  Logout
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </header>

      {/* MAIN VIEWPORT */}
      <main className="flex-1 w-full">{children}</main>

      {/* SECTION 6 & 23: MINIMAL GLOBAL FOOTER (EXACTLY 5 LINKS) */}
      <footer className="border-t border-slate-200 bg-white px-4 sm:px-8 py-4">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-slate-600">
          <button
            type="button"
            onClick={() => setLegalKey('terms')}
            className="hover:text-emerald-700 hover:underline transition-colors whitespace-nowrap"
          >
            Terms
          </button>
          <button
            type="button"
            onClick={() => setLegalKey('refund')}
            className="hover:text-emerald-700 hover:underline transition-colors whitespace-nowrap"
          >
            Refund Policy
          </button>
          <button
            type="button"
            onClick={() => setLegalKey('shopkeeper')}
            className="hover:text-emerald-700 hover:underline transition-colors whitespace-nowrap"
          >
            Shopkeeper Agreement
          </button>
          <button
            type="button"
            onClick={() => setLegalKey('rider')}
            className="hover:text-emerald-700 hover:underline transition-colors whitespace-nowrap"
          >
            Rider Agreement
          </button>
          <button
            type="button"
            onClick={() => setLegalKey('helpline')}
            className="hover:text-emerald-700 hover:underline transition-colors whitespace-nowrap"
          >
            Helpline
          </button>
        </div>
      </footer>

      {/* SECTION 7: ONE CENTRALIZED FLOATING HELP CHATBOT */}
      <div className="fixed bottom-5 right-5 z-40">
        <AnimatePresence>
          {chatOpen && (
            <motion.div
              initial={{ opacity: 0, y: 14, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 12, scale: 0.96 }}
              transition={{ duration: 0.18 }}
              className="mb-3 w-[calc(100vw-2.5rem)] sm:w-96 bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden flex flex-col max-h-[32rem]"
            >
              <div className="px-4 py-3 bg-emerald-600 text-white flex items-center justify-between">
                <div>
                  <h3 className="font-display font-semibold text-sm">DELIVOO Help Desk</h3>
                  <p className="text-xs text-emerald-100">
                    {session ? `Authorized: ${session.user.name} (${session.user.role})` : 'Marketplace Support'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setChatOpen(false)}
                  aria-label="Close Support Chat"
                  className="p-1 rounded-lg hover:bg-emerald-700 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {!escalateMode ? (
                <>
                  <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/60 min-h-[14rem] max-h-72">
                    {chatMessages.map((m, idx) => (
                      <div
                        key={m.id || idx}
                        className={`flex ${m.sender === 'USER' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[85%] rounded-xl px-3.5 py-2.5 text-sm leading-relaxed ${
                            m.sender === 'USER'
                              ? 'bg-emerald-600 text-white'
                              : 'bg-white border border-slate-200 text-slate-800'
                          }`}
                        >
                          {m.message}
                        </div>
                      </div>
                    ))}
                    {chatLoading && (
                      <div className="text-xs text-slate-500">Checking authorized records...</div>
                    )}
                    {ticketNotice && (
                      <div className="text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg p-2.5">
                        {ticketNotice}
                      </div>
                    )}
                  </div>

                  <div className="px-3 py-2 bg-white border-t border-slate-100 flex items-center justify-between gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => setChatInput('Where is my order?')}
                      className="text-slate-600 hover:text-emerald-700 whitespace-nowrap"
                    >
                      Order status
                    </button>
                    <span>·</span>
                    <button
                      type="button"
                      onClick={() => setChatInput('What is my approval status?')}
                      className="text-slate-600 hover:text-emerald-700 whitespace-nowrap"
                    >
                      Approval check
                    </button>
                    <span>·</span>
                    <button
                      type="button"
                      onClick={() => {
                        setTicketNotice('');
                        setEscalateMode(true);
                      }}
                      className="font-medium text-emerald-700 hover:underline whitespace-nowrap"
                    >
                      Human Support
                    </button>
                  </div>

                  <form onSubmit={handleSendChat} className="p-3 bg-white border-t border-slate-200 flex gap-2">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Ask about orders, refunds, approvals..."
                      className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:border-emerald-600"
                    />
                    <button
                      type="submit"
                      disabled={chatLoading}
                      aria-label="Send message"
                      className="px-3 py-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition-colors shrink-0"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </>
              ) : (
                <form onSubmit={handleEscalateTicket} className="p-4 space-y-3 bg-white">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold text-sm text-slate-900">Request Human Support</h4>
                    <button
                      type="button"
                      onClick={() => setEscalateMode(false)}
                      className="text-xs text-slate-500 hover:text-slate-800"
                    >
                      Back to chat
                    </button>
                  </div>
                  <input
                    type="text"
                    required
                    value={ticketSubject}
                    onChange={(e) => setTicketSubject(e.target.value)}
                    placeholder="Issue subject (e.g., Order DEL-1001 item missing)"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                  <textarea
                    required
                    rows={3}
                    value={ticketBody}
                    onChange={(e) => setTicketBody(e.target.value)}
                    placeholder="Describe how our operations team can assist..."
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                  <button
                    type="submit"
                    className="w-full py-2 px-4 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700 transition-colors"
                  >
                    Submit Support Ticket
                  </button>
                </form>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        <button
          type="button"
          onClick={() => (chatOpen ? setChatOpen(false) : openHelpChat())}
          aria-label="Open DELIVOO Help Chatbot"
          className="ml-auto w-12 h-12 rounded-full bg-emerald-600 text-white shadow-md hover:bg-emerald-700 flex items-center justify-center transition-transform active:scale-95 focus-visible:outline-2 focus-visible:outline-emerald-600"
        >
          {chatOpen ? <X className="w-5 h-5" /> : <MessageCircle className="w-5 h-5" />}
        </button>
      </div>

      {/* MODAL: ACCOUNT INFORMATION */}
      {activeModal === 'account' && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full p-6 max-h-[88vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="font-display text-lg font-bold text-slate-900">Account Information</h2>
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {!session ? (
              <div className="py-6 text-center space-y-4">
                <p className="text-sm text-slate-600">You are not currently signed in to a DELIVOO account.</p>
                <button
                  type="button"
                  onClick={() => {
                    setActiveModal(null);
                    onOpenRolePortalForSwitch();
                  }}
                  className="px-5 py-2.5 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700"
                >
                  Select Role & Sign In
                </button>
              </div>
            ) : (
              <div className="mt-4 space-y-5">
                <div className="text-xs text-slate-500 flex flex-wrap items-center gap-2">
                  <span className="font-semibold text-slate-800">{session.user.role}</span>
                  <span>·</span>
                  <span>{session.user.email}</span>
                  {session.shop && (
                    <>
                      <span>·</span>
                      <span>Shop Approval: {session.shop.approval_status}</span>
                    </>
                  )}
                  {session.rider && (
                    <>
                      <span>·</span>
                      <span>Rider Approval: {session.rider.approval_status}</span>
                    </>
                  )}
                </div>

                <form onSubmit={handleSaveProfile} className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Phone Number</label>
                    <input
                      type="text"
                      value={editPhone}
                      onChange={(e) => setEditPhone(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  </div>
                  {session.user.role === 'CUSTOMER' && (
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">Default Delivery Address</label>
                      <input
                        type="text"
                        value={editAddress}
                        onChange={(e) => setEditAddress(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                      />
                    </div>
                  )}
                  {accountMsg && <p className="text-xs text-emerald-700">{accountMsg}</p>}
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700"
                  >
                    Save Changes
                  </button>
                </form>

                <div className="pt-4 border-t border-slate-100">
                  <h3 className="text-sm font-semibold text-slate-900 mb-2">Recent Account Notifications</h3>
                  {notifications.length === 0 ? (
                    <p className="text-xs text-slate-500">No notifications yet.</p>
                  ) : (
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {notifications.slice(0, 10).map((n) => (
                        <div key={n.id} className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs">
                          <div className="font-semibold text-slate-800">{n.title}</div>
                          <div className="text-slate-600 mt-0.5">{n.message}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL: SWITCH ACCOUNT */}
      {activeModal === 'switch' && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="font-display text-lg font-bold text-slate-900">Switch Account</h2>
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Switch between accounts you have authenticated in this browser, or sign in to a different DELIVOO role.
            </p>

            {switchError && (
              <p className="text-xs text-rose-600 bg-rose-50 border border-rose-200 rounded-lg p-2.5">
                {switchError}
              </p>
            )}

            {savedAccounts.length > 0 && (
              <div className="space-y-2">
                {savedAccounts.map((acc) => {
                  const isCurrent = session?.user.id === acc.userId;
                  return (
                    <div
                      key={acc.userId}
                      className="flex items-center justify-between p-3 rounded-xl border border-slate-200"
                    >
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-slate-900 truncate">{acc.name}</div>
                        <div className="text-xs text-slate-500 truncate">
                          {acc.role} · {acc.email}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0 ml-3">
                        {isCurrent ? (
                          <span className="text-xs font-medium text-emerald-700">Active</span>
                        ) : (
                          <button
                            type="button"
                            onClick={async () => {
                              try {
                                await onSwitchSessionToken(acc.token);
                                setActiveModal(null);
                              } catch {
                                removeSavedAccount(acc.userId);
                                setSavedAccounts(getSavedAccounts());
                                setSwitchError('Saved session expired. Please authenticate with your password.');
                              }
                            }}
                            className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-medium hover:bg-emerald-700"
                          >
                            Switch
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
              {(['CUSTOMER', 'SHOPKEEPER', 'RIDER', 'ADMIN'] as UserRole[]).map((role) => (
                <button
                  key={role}
                  type="button"
                  onClick={() => {
                    setActiveModal(null);
                    onOpenRolePortalForSwitch(role);
                  }}
                  className="py-2 px-3 rounded-lg border border-slate-200 hover:border-emerald-500 text-xs font-medium text-slate-700 hover:text-emerald-700 transition-colors"
                >
                  Sign in as {role.charAt(0) + role.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: FEEDBACK */}
      {activeModal === 'feedback' && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="font-display text-lg font-bold text-slate-900">Submit Feedback</h2>
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitFeedback} className="mt-4 space-y-3">
              <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
                {(['FEEDBACK', 'COMPLAINT', 'BUG'] as const).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setFbType(t)}
                    className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors ${
                      fbType === t ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                    }`}
                  >
                    {t === 'FEEDBACK' ? 'Suggestion' : t === 'COMPLAINT' ? 'Complaint' : 'Bug Report'}
                  </button>
                ))}
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Subject</label>
                <input
                  type="text"
                  required
                  value={fbSubject}
                  onChange={(e) => setFbSubject(e.target.value)}
                  placeholder="Brief summary"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Details</label>
                <textarea
                  required
                  rows={4}
                  value={fbMessage}
                  onChange={(e) => setFbMessage(e.target.value)}
                  placeholder="Share your suggestion, complaint, or issue..."
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              {fbStatus && <p className="text-xs text-emerald-700">{fbStatus}</p>}
              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700"
              >
                Send to DELIVOO Team
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: FOOTER LEGAL DOCUMENTS & HELPLINE */}
      {legalKey && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-xl w-full p-6 max-h-[85vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="font-display text-lg font-bold text-slate-900">
                {LEGAL_DOCUMENTS[legalKey].title}
              </h2>
              <button
                type="button"
                onClick={() => setLegalKey(null)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4">
              {LEGAL_DOCUMENTS[legalKey].sections.map((sec, i) => (
                <div key={i}>
                  <h3 className="text-sm font-semibold text-slate-900">{sec.heading}</h3>
                  <p className="text-sm text-slate-600 mt-1 leading-relaxed">{sec.body}</p>
                </div>
              ))}
            </div>
            <p className="pt-3 border-t border-slate-100 text-xs text-slate-500">
              Notice: Policy wording is marked for review by qualified Pakistani legal counsel prior to commercial launch.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
