import type { SavedAccountSlot, SessionData } from '../types';

const TOKEN_STORAGE_KEY = 'delivoo_active_token';
const SAVED_ACCOUNTS_KEY = 'delivoo_authorized_accounts';

export function getActiveToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setActiveToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem(TOKEN_STORAGE_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
    }
  } catch {
    // Ignore storage quota errors
  }
}

export function getSavedAccounts(): SavedAccountSlot[] {
  try {
    const raw = localStorage.getItem(SAVED_ACCOUNTS_KEY);
    return raw ? (JSON.parse(raw) as SavedAccountSlot[]) : [];
  } catch {
    return [];
  }
}

export function saveAuthorizedAccount(session: SessionData): void {
  try {
    const list = getSavedAccounts().filter((a) => a.userId !== session.user.id);
    list.unshift({
      userId: session.user.id,
      name: session.user.name,
      email: session.user.email,
      role: session.user.role,
      token: session.token,
    });
    localStorage.setItem(SAVED_ACCOUNTS_KEY, JSON.stringify(list.slice(0, 6)));
  } catch {
    // Ignore
  }
}

export function removeSavedAccount(userId: number): void {
  try {
    const list = getSavedAccounts().filter((a) => a.userId !== userId);
    localStorage.setItem(SAVED_ACCOUNTS_KEY, JSON.stringify(list));
  } catch {
    // Ignore
  }
}

export async function apiRequest<T = any>(
  path: string,
  options: RequestInit = {},
  overrideToken?: string | null
): Promise<T> {
  const token = overrideToken !== undefined ? overrideToken : getActiveToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) || {}),
  };
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(path, {
    ...options,
    headers,
  });

  const contentType = res.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await res.json() : await res.text();

  if (!res.ok) {
    const msg = typeof data === 'object' && data?.error ? data.error : `Request failed (${res.status})`;
    throw new Error(msg);
  }

  return data as T;
}

export function connectDelivooSocket(
  token: string | null,
  onEvent: (event: { type: string; payload?: any; timestamp?: string }) => void
): () => void {
  let ws: WebSocket | null = null;
  let closedIntentionally = false;
  let retryTimer: ReturnType<typeof setTimeout> | null = null;

  const connect = () => {
    if (closedIntentionally) return;
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    ws = new WebSocket(`${proto}//${window.location.host}/ws`);

    ws.onopen = () => {
      if (token && ws?.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'auth', token }));
      }
    };

    ws.onmessage = (evt) => {
      try {
        const parsed = JSON.parse(evt.data);
        onEvent(parsed);
      } catch {
        // Ignore malformed frame
      }
    };

    ws.onclose = () => {
      if (!closedIntentionally) {
        retryTimer = setTimeout(connect, 2500);
      }
    };
  };

  connect();

  return () => {
    closedIntentionally = true;
    if (retryTimer) clearTimeout(retryTimer);
    if (ws) ws.close();
  };
}
