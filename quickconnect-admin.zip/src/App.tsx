import { AnimatePresence } from 'motion/react';
import { useCallback, useEffect, useState } from 'react';
import { GlobalChrome } from './components/GlobalChrome';
import { OpeningSplash } from './components/OpeningSplash';
import { RoleAuthPortal } from './components/RoleAuthPortal';
import { AdminDashboard } from './dashboards/AdminDashboard';
import { CustomerDashboard } from './dashboards/CustomerDashboard';
import { RiderDashboard } from './dashboards/RiderDashboard';
import { ShopkeeperDashboard } from './dashboards/ShopkeeperDashboard';
import {
  apiRequest,
  connectDelivooSocket,
  getActiveToken,
  saveAuthorizedAccount,
  setActiveToken,
} from './lib/api';
import type { SessionData, UserRole } from './types';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [session, setSession] = useState<SessionData | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [switchRoleTarget, setSwitchRoleTarget] = useState<UserRole | null>(null);
  const [forceRolePortal, setForceRolePortal] = useState(false);
  const [realtimeTick, setRealtimeTick] = useState(0);

  const refreshSession = useCallback(async (overrideToken?: string | null) => {
    const token = overrideToken !== undefined ? overrideToken : getActiveToken();
    if (!token) {
      setSession(null);
      setCheckingAuth(false);
      return;
    }
    try {
      const me = await apiRequest<Omit<SessionData, 'token'>>('/api/auth/me', {}, token);
      const full: SessionData = { token, ...me };
      setActiveToken(token);
      saveAuthorizedAccount(full);
      setSession(full);
    } catch {
      setActiveToken(null);
      setSession(null);
    } finally {
      setCheckingAuth(false);
    }
  }, []);

  useEffect(() => {
    refreshSession();
  }, [refreshSession]);

  // Connect WebSocket for live multi-user updates (approvals, orders, dispatch, GPS, catalog)
  useEffect(() => {
    const disconnect = connectDelivooSocket(session?.token || null, (evt) => {
      if (evt.type === 'approval:updated') {
        refreshSession();
        setRealtimeTick((t) => t + 1);
      } else if (
        [
          'catalog:updated',
          'order:created',
          'order:updated',
          'suborder:created',
          'suborder:updated',
          'rider:dispatch_offer',
          'rider:location',
          'approvals:updated',
          'notification:new',
        ].includes(evt.type)
      ) {
        setRealtimeTick((t) => t + 1);
      }
    });
    return disconnect;
  }, [session?.token, refreshSession]);

  const handleAuthenticated = (newSession: SessionData) => {
    setActiveToken(newSession.token);
    saveAuthorizedAccount(newSession);
    setSession(newSession);
    setForceRolePortal(false);
    setSwitchRoleTarget(null);
  };

  const handleLogout = async () => {
    try {
      if (session?.token) {
        await apiRequest('/api/auth/logout', { method: 'POST' });
      }
    } catch {
      // Ignore logout network error
    } finally {
      setActiveToken(null);
      setSession(null);
      setForceRolePortal(false);
      setSwitchRoleTarget(null);
    }
  };

  const handleSwitchSessionToken = async (targetToken: string) => {
    await refreshSession(targetToken);
    setForceRolePortal(false);
    setRealtimeTick((t) => t + 1);
  };

  return (
    <>
      <AnimatePresence>
        {showSplash && <OpeningSplash onComplete={() => setShowSplash(false)} />}
      </AnimatePresence>

      <GlobalChrome
        session={session}
        onLogoClick={() => {
          if (!session) {
            setSwitchRoleTarget(null);
          } else {
            setForceRolePortal(false);
          }
        }}
        onLogout={handleLogout}
        onSwitchSessionToken={handleSwitchSessionToken}
        onOpenRolePortalForSwitch={(role) => {
          setSwitchRoleTarget(role || null);
          setForceRolePortal(true);
        }}
        onSessionRefresh={() => refreshSession()}
      >
        {checkingAuth ? (
          <div className="max-w-5xl mx-auto p-10 text-center text-sm text-slate-500">
            Initializing DELIVOO session...
          </div>
        ) : !session || forceRolePortal ? (
          <RoleAuthPortal
            initialSelectedRole={switchRoleTarget}
            onAuthenticated={handleAuthenticated}
          />
        ) : session.user.role === 'CUSTOMER' ? (
          <CustomerDashboard session={session} refreshTick={realtimeTick} />
        ) : session.user.role === 'SHOPKEEPER' ? (
          <ShopkeeperDashboard
            session={session}
            refreshTick={realtimeTick}
            onSessionRefresh={() => refreshSession()}
          />
        ) : session.user.role === 'RIDER' ? (
          <RiderDashboard
            session={session}
            refreshTick={realtimeTick}
            onSessionRefresh={() => refreshSession()}
          />
        ) : (
          <AdminDashboard session={session} refreshTick={realtimeTick} />
        )}
      </GlobalChrome>
    </>
  );
}
